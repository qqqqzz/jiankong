import React, { useState } from 'react';
import { 
  Filter, Layers, AlertCircle, AlertTriangle, CheckCircle2, Clock, 
  ChevronRight, ChevronDown, Play, StopCircle, RefreshCw, Bot, User, 
  ShieldAlert, Server, Database, ArrowRight, Check, X, FileText, 
  CornerDownRight, Zap, ListFilter, Search, ExternalLink
} from 'lucide-react';

export default function AlertConvergence() {
  // 分组收敛数据模型
  const [alertGroups, setAlertGroups] = useState([
    {
      id: 'GRP-2026-0881',
      title: 'Doris 数仓计算集群内存超限与节点级联告警',
      domain: '大数据中台域',
      convergenceRule: '同集群 (Doris-Prod) & 5分钟时间滑窗聚合',
      level: '紧急告警',
      levelColor: 'bg-red-50 text-red-700 border-red-200',
      groupStatus: '协同处置中', // '未处理' | '协同处置中' | '部分恢复' | '全部恢复' | '已忽略'
      firstOccurTime: '2026-06-12 10:15:20',
      duration: '42分钟',
      handlers: ['穆工 (250993)', '章工 (250994)'],
      recoveredCount: 3,
      totalCount: 5,
      items: [
        {
          itemId: 'ITEM-101',
          target: 'doris-fe-master (172.18.11.101)',
          metric: 'JVM Heap使用率 > 92%',
          occurTime: '10:15:20',
          itemStatus: '已自愈恢复',
          statusColor: 'bg-green-50 text-green-700 border-green-200',
          autoScript: '重启Doris FE垃圾回收与死锁清理',
          scriptResult: '成功 (耗时 3.2s)'
        },
        {
          itemId: 'ITEM-102',
          target: 'doris-be-worker01 (172.18.11.105)',
          metric: 'MemLimitExceeded (内存使用率 98%)',
          occurTime: '10:16:04',
          itemStatus: '已自愈恢复',
          statusColor: 'bg-green-50 text-green-700 border-green-200',
          autoScript: '杀掉长时间大查询SQL',
          scriptResult: '成功 (Kill query #98821)'
        },
        {
          itemId: 'ITEM-103',
          target: 'doris-be-worker02 (172.18.11.106)',
          metric: '磁盘IO使用率 > 95%',
          occurTime: '10:16:45',
          itemStatus: '持续告警',
          statusColor: 'bg-red-50 text-red-700 border-red-200 animate-pulse',
          autoScript: '清理临时落盘Spill文件',
          scriptResult: '执行中...'
        },
        {
          itemId: 'ITEM-104',
          target: 'doris-be-worker03 (172.18.11.107)',
          metric: 'Compaction Score积压 > 120',
          occurTime: '10:17:12',
          itemStatus: '持续告警',
          statusColor: 'bg-red-50 text-red-700 border-red-200 animate-pulse',
          autoScript: null,
          scriptResult: '等待人工介入'
        },
        {
          itemId: 'ITEM-105',
          target: 'doris-broker-01 (172.18.11.110)',
          metric: 'RPC心跳短暂延迟 (250ms)',
          occurTime: '10:18:00',
          itemStatus: '已自愈恢复',
          statusColor: 'bg-green-50 text-green-700 border-green-200',
          autoScript: '轻量探测复检',
          scriptResult: '指标恢复正常'
        }
      ]
    },
    {
      id: 'GRP-2026-0882',
      title: '智能制造-洗碗机智能装配线 PLC 网关通信丢包',
      domain: '智能制造域',
      convergenceRule: '产线标签 (Line-04) & 拓扑根因收敛',
      level: '严重告警',
      levelColor: 'bg-orange-50 text-orange-700 border-orange-200',
      groupStatus: '未处理',
      firstOccurTime: '2026-06-12 10:40:11',
      duration: '18分钟',
      handlers: ['章工 (250994)'],
      recoveredCount: 0,
      totalCount: 3,
      items: [
        {
          itemId: 'ITEM-201',
          target: 'edge-gateway-plc01 (10.20.4.15)',
          metric: 'Ping丢包率 > 30%',
          occurTime: '10:40:11',
          itemStatus: '持续告警',
          statusColor: 'bg-red-50 text-red-700 border-red-200 animate-pulse',
          autoScript: '重启边缘网关网络服务',
          scriptResult: '待触发'
        },
        {
          itemId: 'ITEM-202',
          target: 'mes-collector-node2 (10.20.4.22)',
          metric: 'OPC-UA 数据采集连接超时',
          occurTime: '10:41:05',
          itemStatus: '持续告警',
          statusColor: 'bg-red-50 text-red-700 border-red-200 animate-pulse',
          autoScript: null,
          scriptResult: '根因受上游网关影响'
        },
        {
          itemId: 'ITEM-203',
          target: 'vision-check-cam03 (10.20.4.50)',
          metric: '视觉检测图像帧接收队列堆积',
          occurTime: '10:42:30',
          itemStatus: '持续告警',
          statusColor: 'bg-red-50 text-red-700 border-red-200 animate-pulse',
          autoScript: null,
          scriptResult: '受级联网络影响'
        }
      ]
    },
    {
      id: 'GRP-2026-0883',
      title: '电商零售-全网订单交易中台微服务并发陡增',
      domain: '电商零售域',
      convergenceRule: '应用服务名 (order-center) & HTTP 5xx 错误收敛',
      level: '警告告警',
      levelColor: 'bg-yellow-50 text-yellow-700 border-yellow-200',
      groupStatus: '全部恢复',
      firstOccurTime: '2026-06-12 09:05:00',
      duration: '已恢复 (总历时 15分钟)',
      handlers: ['陈工 (250997)', '王工 (250998)'],
      recoveredCount: 4,
      totalCount: 4,
      items: [
        {
          itemId: 'ITEM-301',
          target: 'order-api-pod-89a (K8s)',
          metric: '接口响应耗时 > 1200ms',
          occurTime: '09:05:00',
          itemStatus: '已自愈恢复',
          statusColor: 'bg-green-50 text-green-700 border-green-200',
          autoScript: '自动弹性扩容 2 个副本',
          scriptResult: '扩容成功'
        },
        {
          itemId: 'ITEM-302',
          target: 'order-api-pod-99c (K8s)',
          metric: '线程池满负载 (Active 200/200)',
          occurTime: '09:06:10',
          itemStatus: '已自愈恢复',
          statusColor: 'bg-green-50 text-green-700 border-green-200',
          autoScript: '动态调整最大并发数',
          scriptResult: '执行成功'
        },
        {
          itemId: 'ITEM-303',
          target: 'order-db-proxy-01',
          metric: '连接等待队列 > 50',
          occurTime: '09:07:00',
          itemStatus: '已自愈恢复',
          statusColor: 'bg-green-50 text-green-700 border-green-200',
          autoScript: '清理空闲连接',
          scriptResult: '已清理 80 个连接'
        },
        {
          itemId: 'ITEM-304',
          target: 'order-mq-consumer',
          metric: 'RocketMQ 消费延迟 > 2000 条',
          occurTime: '09:08:22',
          itemStatus: '已自愈恢复',
          statusColor: 'bg-green-50 text-green-700 border-green-200',
          autoScript: '增加消费线程',
          scriptResult: '消费已追平'
        }
      ]
    }
  ]);

  // 展开折叠的组ID
  const [expandedGroupId, setExpandedGroupId] = useState<string>('GRP-2026-0881');
  const [filterDomain, setFilterDomain] = useState('全部');
  const [filterStatus, setFilterStatus] = useState('全部');

  // 单条明细状态变更（模拟自愈修复单个实例）
  const handleRecoverItem = (groupId: string, itemId: string) => {
    setAlertGroups(groups => groups.map(g => {
      if (g.id !== groupId) return g;
      
      const newItems = g.items.map(item => {
        if (item.itemId === itemId) {
          return {
            ...item,
            itemStatus: '已自愈恢复',
            statusColor: 'bg-green-50 text-green-700 border-green-200',
            scriptResult: '人工触发脚本修复成功'
          };
        }
        return item;
      });

      const recoveredCount = newItems.filter(i => i.itemStatus === '已自愈恢复').length;
      let newGroupStatus = g.groupStatus;
      if (recoveredCount === newItems.length) {
        newGroupStatus = '全部恢复';
      } else if (recoveredCount > 0) {
        newGroupStatus = '部分恢复';
      }

      return {
        ...g,
        recoveredCount,
        groupStatus: newGroupStatus,
        items: newItems
      };
    }));
  };

  // 组级一键操作（批量自愈所有子项）
  const handleBatchAutoFixGroup = (groupId: string) => {
    setAlertGroups(groups => groups.map(g => {
      if (g.id !== groupId) return g;
      const newItems = g.items.map(item => ({
        ...item,
        itemStatus: '已自愈恢复',
        statusColor: 'bg-green-50 text-green-700 border-green-200',
        scriptResult: '组级批量执行自愈脚本成功'
      }));
      return {
        ...g,
        recoveredCount: newItems.length,
        groupStatus: '全部恢复',
        items: newItems
      };
    }));
  };

  // 组级接管/认领
  const handleTakeoverGroup = (groupId: string) => {
    setAlertGroups(groups => groups.map(g => {
      if (g.id !== groupId) return g;
      return {
        ...g,
        groupStatus: '协同处置中',
        handlers: Array.from(new Set([...g.handlers, '当前用户 (雷秋子)']))
      };
    }));
  };

  const filteredGroups = alertGroups.filter(g => {
    const matchDomain = filterDomain === '全部' || g.domain === filterDomain;
    const matchStatus = filterStatus === '全部' || g.groupStatus === filterStatus;
    return matchDomain && matchStatus;
  });

  return (
    <div className="w-full h-full flex flex-col bg-white overflow-hidden text-[13px]">
      
      {/* 顶部标题栏与设计解答 */}
      <div className="px-6 py-4 border-b border-gray-100 bg-[#FAFAFA] shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-gray-800 text-sm font-bold">
            <Filter size={18} className="text-[#3b82f6]" />
            告警分组收敛 (Alert Convergence) 与明细联动
            <span className="text-gray-300 mx-2">|</span>
            <span className="text-gray-500 font-normal text-xs">通过滑动时间窗与拓扑规则抑制告警风暴，实现组状态与明细状态层级联动</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="bg-purple-50 text-purple-700 border border-purple-200 px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1">
              <Zap size={13} /> 今日累计压缩收敛 482 次告警 (收敛比 86.4%)
            </span>
          </div>
        </div>

        {/* 核心问题解答条: 组状态 vs 明细状态区分说明 */}
        <div className="mt-3 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-3 text-xs text-gray-700 flex items-start gap-3">
          <div className="w-6 h-6 rounded bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5 font-bold">
            ?
          </div>
          <div className="flex-1 space-y-1">
            <div className="font-bold text-blue-900">
              架构解答：怎么查看组内不同的告警明细？组状态和明细状态怎么区分与联动？
            </div>
            <div className="grid grid-cols-2 gap-3 text-gray-600 leading-relaxed pt-1">
              <div className="bg-white/80 p-2 rounded border border-blue-100">
                <strong className="text-blue-800">1. 组状态 (Group State - 聚合级)：</strong>
                表示整个故障事件的宏观态，分为 <code>未处理</code>、<code>协同处置中</code>、<code>部分恢复(X/Y)</code>、<code>全部恢复</code>。由组内所有明细状态自动计算汇聚，支持组级一键派发、一键协同自愈。
              </div>
              <div className="bg-white/80 p-2 rounded border border-blue-100">
                <strong className="text-blue-800">2. 明细状态 (Item State - 实例级)：</strong>
                点击展开组即可查看组内每个独立组件/实例的微观态：<code>持续告警</code>、<code>自愈中</code>、<code>已自愈恢复</code>、<code>已人工确认</code>。支持单节点独立重启或排查，单节点恢复实时反馈至组进度条。
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 筛选过滤与列表 */}
      <div className="flex-1 overflow-auto bg-gray-50/50 p-5 flex flex-col space-y-4">
        
        <div className="flex justify-between items-center bg-white p-3 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-gray-600">筛选维度：</span>
            <select 
              value={filterDomain} 
              onChange={e => setFilterDomain(e.target.value)}
              className="border border-gray-200 rounded px-2.5 h-[30px] text-xs focus:outline-none focus:border-blue-500 bg-white"
            >
              <option value="全部">全部业务域</option>
              <option value="大数据中台域">大数据中台域</option>
              <option value="智能制造域">智能制造域</option>
              <option value="电商零售域">电商零售域</option>
            </select>

            <select 
              value={filterStatus} 
              onChange={e => setFilterStatus(e.target.value)}
              className="border border-gray-200 rounded px-2.5 h-[30px] text-xs focus:outline-none focus:border-blue-500 bg-white"
            >
              <option value="全部">全部组状态</option>
              <option value="未处理">未处理</option>
              <option value="协同处置中">协同处置中</option>
              <option value="部分恢复">部分恢复</option>
              <option value="全部恢复">全部恢复</option>
            </select>
          </div>

          <div className="text-xs text-gray-500">
            共计收敛聚合 <strong>{filteredGroups.length}</strong> 个告警事件组
          </div>
        </div>

        {/* 告警收敛组列表 */}
        <div className="space-y-4">
          {filteredGroups.map(group => {
            const isExpanded = expandedGroupId === group.id;
            const progressPercent = Math.round((group.recoveredCount / group.totalCount) * 100);

            return (
              <div 
                key={group.id} 
                className={`bg-white border rounded-xl overflow-hidden transition-all shadow-sm ${
                  isExpanded ? 'border-blue-400 ring-2 ring-blue-50' : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                {/* 组卡片 Header */}
                <div 
                  onClick={() => setExpandedGroupId(isExpanded ? '' : group.id)}
                  className="p-4 cursor-pointer hover:bg-gray-50/50 transition-colors flex items-center justify-between select-none"
                >
                  <div className="flex items-start gap-3">
                    <button className="mt-1 text-gray-400 hover:text-blue-600 transition-colors">
                      {isExpanded ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
                    </button>

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs font-bold text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded">
                          {group.id}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-xs font-bold border ${group.levelColor}`}>
                          {group.level}
                        </span>
                        <span className="text-sm font-bold text-gray-800">
                          {group.title}
                        </span>
                        <span className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-200 font-medium">
                          {group.domain}
                        </span>
                      </div>

                      <div className="flex items-center gap-4 text-xs text-gray-500 mt-2 flex-wrap">
                        <span className="flex items-center gap-1">
                          <Filter size={12} className="text-blue-500" /> 收敛规则: {group.convergenceRule}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock size={12} /> 首次触发: {group.firstOccurTime} ({group.duration})
                        </span>
                        <span className="flex items-center gap-1">
                          <User size={12} /> 处理人: <strong className="text-gray-700">{group.handlers.join(', ')}</strong>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 组状态徽标与恢复进度 */}
                  <div className="flex items-center gap-4 shrink-0">
                    <div className="flex flex-col items-end gap-1 w-36">
                      <div className="flex justify-between w-full text-[11px] font-medium text-gray-500">
                        <span>恢复进度</span>
                        <span className="font-mono font-bold text-gray-700">{group.recoveredCount}/{group.totalCount} ({progressPercent}%)</span>
                      </div>
                      <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className={`h-full transition-all duration-300 ${
                            progressPercent === 100 ? 'bg-green-500' : progressPercent > 0 ? 'bg-blue-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${progressPercent}%` }}
                        ></div>
                      </div>
                    </div>

                    <div className="w-24 text-center">
                      {group.groupStatus === '未处理' && (
                        <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-red-100 text-red-700 border border-red-200 block">
                          未处理
                        </span>
                      )}
                      {group.groupStatus === '协同处置中' && (
                        <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-700 border border-blue-200 block">
                          协同处置中
                        </span>
                      )}
                      {group.groupStatus === '部分恢复' && (
                        <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200 block">
                          部分恢复 ({group.recoveredCount}/{group.totalCount})
                        </span>
                      )}
                      {group.groupStatus === '全部恢复' && (
                        <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-green-100 text-green-700 border border-green-200 block">
                          全部恢复
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* 组内明细清单 (Item Details Table) */}
                {isExpanded && (
                  <div className="border-t border-gray-100 bg-[#FAFBFC] p-4 animate-in fade-in duration-150">
                    
                    {/* 组级快捷操作条 */}
                    <div className="flex justify-between items-center mb-3 bg-white p-2.5 rounded border border-gray-200">
                      <div className="flex items-center gap-2 text-xs text-gray-600">
                        <Layers size={14} className="text-blue-600" />
                        <span>组内聚合了 <strong>{group.items.length}</strong> 条关联告警明细 (可针对单实例单独处置，亦可整组协同自愈)</span>
                      </div>

                      <div className="flex items-center gap-2">
                        {group.groupStatus !== '协同处置中' && group.groupStatus !== '全部恢复' && (
                          <button 
                            onClick={() => handleTakeoverGroup(group.id)}
                            className="bg-blue-50 text-blue-700 border border-blue-200 px-3 py-1 rounded text-xs font-medium hover:bg-blue-100 transition"
                          >
                            协同接管该组
                          </button>
                        )}
                        {group.groupStatus !== '全部恢复' && (
                          <button 
                            onClick={() => handleBatchAutoFixGroup(group.id)}
                            className="bg-emerald-600 text-white px-3 py-1 rounded text-xs font-medium hover:bg-emerald-700 shadow-sm flex items-center gap-1 transition"
                          >
                            <Bot size={13} /> 组级一键自愈 (批量修复剩余子项)
                          </button>
                        )}
                      </div>
                    </div>

                    {/* 明细子表格 */}
                    <table className="w-full text-left text-xs bg-white rounded border border-gray-200 overflow-hidden">
                      <thead>
                        <tr className="bg-gray-50 text-gray-600 border-b border-gray-200 font-bold">
                          <th className="py-2.5 px-3">子项编号</th>
                          <th className="py-2.5 px-3">受影响目标与实例</th>
                          <th className="py-2.5 px-3">触发异常指标</th>
                          <th className="py-2.5 px-3">发生时间</th>
                          <th className="py-2.5 px-3">绑定自愈脚本 / 状态</th>
                          <th className="py-2.5 px-3">明细状态 (Item Status)</th>
                          <th className="py-2.5 px-3 text-right pr-4">操作</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {group.items.map(item => (
                          <tr key={item.itemId} className="hover:bg-blue-50/20 transition-colors">
                            <td className="py-3 px-3 font-mono text-gray-500 font-medium">
                              <span className="flex items-center gap-1">
                                <CornerDownRight size={12} className="text-gray-400" />
                                {item.itemId}
                              </span>
                            </td>
                            <td className="py-3 px-3 font-medium text-gray-800">
                              {item.target}
                            </td>
                            <td className="py-3 px-3 text-red-600 font-mono">
                              {item.metric}
                            </td>
                            <td className="py-3 px-3 text-gray-500 font-mono">
                              {item.occurTime}
                            </td>
                            <td className="py-3 px-3">
                              {item.autoScript ? (
                                <div>
                                  <div className="flex items-center gap-1 text-blue-700 font-medium">
                                    <Bot size={12} /> {item.autoScript}
                                  </div>
                                  <div className="text-[10px] text-gray-500 font-mono">{item.scriptResult}</div>
                                </div>
                              ) : (
                                <span className="text-gray-400">无预置自愈脚本</span>
                              )}
                            </td>
                            <td className="py-3 px-3">
                              <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${item.statusColor}`}>
                                {item.itemStatus}
                              </span>
                            </td>
                            <td className="py-3 px-3 text-right pr-4 space-x-2 whitespace-nowrap">
                              {item.itemStatus !== '已自愈恢复' ? (
                                <button 
                                  onClick={() => handleRecoverItem(group.id, item.itemId)}
                                  className="bg-blue-600 text-white px-2 py-1 rounded text-[11px] hover:bg-blue-700 font-medium"
                                  title="针对该单节点执行修复动作"
                                >
                                  执行单项自愈
                                </button>
                              ) : (
                                <span className="text-green-600 text-[11px] font-medium flex items-center gap-1 justify-end">
                                  <CheckCircle2 size={12} /> 状态正常
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
}
