import React from 'react';
import { 
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend, LineChart, Line
} from 'recharts';
import { 
  Clock, Box, Database, AlertCircle, FileText, Bell, Calendar, CalendarDays, Key, Activity, User, Server
} from 'lucide-react';

// Left Top: 监控总览
const OVERVIEW_PIE_DATA = [
  { name: 'SpringBoot3.0', value: 31, fill: '#3b82f6' },
  { name: 'Apache Hive 1', value: 1, fill: '#f97316' },
  { name: 'Oracle数据库', value: 1, fill: '#64748b' },
  { name: 'Redis数据库', value: 3, fill: '#10b981' },
  { name: 'Apache Doris FE', value: 3, fill: '#8b5cf6' },
  { name: '网站监测', value: 5, fill: '#ef4444' },
  { name: 'Linux操作系统', value: 15, fill: '#f59e0b' },
  { name: 'OS Linux', value: 8, fill: '#10b981' }, 
];

// Left Bottom: 最近告警列表
const RECENT_ALARMS = [
  { time: '2026-04-22 06:57:35', level: '严重告警', desc: '[大数据调度-dolphin1] 挂载点: /data, 可用量: 19854.0 (MB)', color: '#ea580c' },
  { time: '2026-04-22 10:50:14', level: '严重告警', desc: '[大数据调度-dolphin1] 挂载点: /data, 可用量: 19908.0 (MB)', color: '#ea580c' },
  { time: '2026-04-22 09:50:08', level: '严重告警', desc: '[大数据调度-dolphin1] 挂载点: /data, 可用量: 19932.0 (MB)', color: '#ea580c' },
  { time: '2026-04-22 08:50:02', level: '严重告警', desc: '[大数据调度-dolphin1] 挂载点: /data, 可用量: 19873.0 (MB)', color: '#ea580c' },
  { time: '2026-04-22 07:39:55', level: '严重告警', desc: '[大数据调度-dolphin1] 挂载点: /data, 可用量: 19878.0 (MB)', color: '#ea580c' },
  { time: '2026-04-22 07:07:41', level: '紧急告警', desc: '[DORIS FE 172.18.11.105] doris fe monitoring availability alert. code is...', color: '#ef4444' },
];

// Center Bottom: 告警与自愈趋势
const TREND_DATA = [
  { time: '00:00', alarm: 120, recovery: 110 },
  { time: '04:00', alarm: 155, recovery: 140 },
  { time: '08:00', alarm: 340, recovery: 300 },
  { time: '12:00', alarm: 280, recovery: 265 },
  { time: '16:00', alarm: 450, recovery: 410 },
  { time: '20:00', alarm: 215, recovery: 195 },
  { time: '24:00', alarm: 140, recovery: 135 },
];

// Right Middle: 告警分类
const ALARM_CLASS_DATA = [
  { name: '警告告警', count: 0, fill: '#3b82f6' },
  { name: '严重告警', count: 2000, fill: '#ea580c' },
  { name: '紧急告警', count: 4000, fill: '#ef4444' },
];

// Right Bottom: 处理专家 Top5
const EXPERT_DATA = [
  { name: '章工', score: 145, pct: 100 },
  { name: '穆工', score: 128, pct: 88 },
  { name: '赵工', score: 96, pct: 66 },
  { name: '李工', score: 83, pct: 57 },
  { name: '陈工', score: 65, pct: 44 },
];

const InterfaceIcon = (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="4" y="4" width="16" height="16" rx="2" ry="2" />
    <rect x="9" y="9" width="6" height="6" />
    <line x1="9" y1="1" x2="9" y2="4" />
    <line x1="15" y1="1" x2="15" y2="4" />
    <line x1="9" y1="20" x2="9" y2="23" />
    <line x1="15" y1="20" x2="15" y2="23" />
    <line x1="20" y1="9" x2="23" y2="9" />
    <line x1="20" y1="14" x2="23" y2="14" />
    <line x1="1" y1="9" x2="4" y2="9" />
    <line x1="1" y1="14" x2="4" y2="14" />
  </svg>
);

const MetricsIcon = (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 3v18h18" />
    <path d="M18 17V9" />
    <path d="M13 17V5" />
    <path d="M8 17v-3" />
  </svg>
);

const CodeIcon = (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="16 18 22 12 16 6"></polyline>
    <polyline points="8 6 2 12 8 18"></polyline>
  </svg>
);

const ScheduleIcon = (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"></circle>
    <polyline points="12 6 12 12 16 14"></polyline>
  </svg>
);

const SciFiPanel = ({ title, children, className }: any) => (
  <div className={`relative border border-[#0A3D7A] bg-[#020B1A]/80 shadow-[0_0_15px_rgba(0,180,255,0.1)] p-4 flex flex-col ${className}`}>
     <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-[#00B4FF]"></div>
     <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-[#00B4FF]"></div>
     <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-[#00B4FF]"></div>
     <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-[#00B4FF]"></div>
     {title && (
       <div className="text-[#00B4FF] text-[13px] font-bold tracking-widest mb-4 flex items-center justify-center relative shrink-0">
          <span className="relative z-10 px-4 flex items-center gap-2">
            <span className="w-12 h-[1px] bg-gradient-to-l from-[#00B4FF] to-transparent"></span>
            {title}
            <span className="w-12 h-[1px] bg-gradient-to-r from-[#00B4FF] to-transparent"></span>
          </span>
       </div>
     )}
     <div className="flex-1 w-full relative min-h-0 flex flex-col">
        {children}
     </div>
  </div>
);

const FloatingNode = ({ title, total, warning, icon, delay="0s", warningColor, onClick, customColor, customDarkerColor, warningDetails }: any) => {
  const isWarn = warning > 0 || warningColor || warningDetails;
  const color = customColor || (isWarn ? '#f59e0b' : '#00F0FF');
  const darkerColor = customDarkerColor || (isWarn ? '#f59e0b' : '#00B4FF');

  return (
    <div onClick={onClick} className={`relative flex flex-col items-center justify-end z-30 transition-transform ${onClick ? 'cursor-pointer hover:scale-105' : ''}`} style={{ animation: `floatNode 4s ease-in-out infinite ${delay}` }}>
       <div className={`relative w-[130px] border shadow-[0_0_15px_rgba(0,180,255,0.2)] flex flex-col z-10 px-4 py-2`} style={{ borderColor: darkerColor, backgroundColor: '#020B1A', opacity: 0.9 }}>
           <div className="absolute top-[-1px] left-[-1px] w-2 h-2 border-t-[1.5px] border-l-[1.5px]" style={{ borderColor: color }}></div>
           <div className="absolute top-[-1px] right-[-1px] w-2 h-2 border-t-[1.5px] border-r-[1.5px]" style={{ borderColor: color }}></div>
           <div className="absolute bottom-[-1px] left-[-1px] w-2 h-2 border-b-[1.5px] border-l-[1.5px]" style={{ borderColor: color }}></div>
           <div className="absolute bottom-[-1px] right-[-1px] w-2 h-2 border-b-[1.5px] border-r-[1.5px]" style={{ borderColor: color }}></div>

           <div className="flex justify-between items-center text-[11px] mb-1 font-medium text-white">
              <span className="tracking-widest">监测总数</span>
              <span className="font-mono font-bold text-[14px]">{total}</span>
           </div>
           <div className="flex justify-between items-center text-[11px] font-medium text-white">
              <span className="tracking-widest">正在告警</span>
              {warningDetails ? null : <span className={`font-mono font-bold text-[14px] ${(warning > 0 || isWarn) ? 'animate-pulse' : ''}`}>{warning}</span>}
           </div>
           {warningDetails && (
               <div className="flex flex-col mt-0.5 w-full gap-[2px]">
                   {warningDetails.map((detail: any, idx: number) => (
                       <div key={idx} className="flex justify-between items-center text-[10px] text-white/90">
                           <span style={{ color: detail.color || 'white' }}>{detail.label}</span>
                           <span className="font-mono" style={{ color: detail.color || 'white' }}>{detail.count}个</span>
                       </div>
                   ))}
               </div>
           )}
       </div>

       <div className="relative w-full h-[35px] overflow-hidden flex justify-center z-0 -mt-[1px]">
           <div className="w-[80px] h-[50px] pointer-events-none transform origin-top" 
                style={{ 
                   clipPath: 'polygon(0 0, 100% 0, 70% 100%, 30% 100%)',
                   background: `linear-gradient(to bottom, ${darkerColor}66, transparent)` 
                }}>
           </div>
       </div>
       
       <div className="relative flex flex-col items-center">
           <div className="relative z-10 mb-2 drop-shadow-md" style={{ color: color }}>
              {icon}
           </div>
           <div className="relative z-10 text-[11px] tracking-widest text-[#e2e8f0] font-bold border px-4 py-1 rounded-full whitespace-nowrap overflow-hidden" style={{ borderColor: darkerColor, backgroundColor: '#020B1A' }}>
                <div className="absolute inset-0 opacity-30" style={{ background: `linear-gradient(to right, transparent, ${color}, transparent)` }}></div>
                <span className="relative z-10">{title}</span>
           </div>
           <div className="w-2 h-2 rounded-full mt-2 shadow-[0_0_8px_currentColor]" style={{ backgroundColor: color, color: color }}></div>
       </div>
    </div>
  );
};

interface DashboardProps {
  onNavigate?: (id: string, context?: any) => void;
  standalone?: boolean;
  onEnterApp?: () => void;
}

export default function Dashboard({ standalone, onEnterApp, onNavigate }: DashboardProps) {
  return (
    <div className={`w-full h-full flex flex-col gap-4 text-gray-200 relative bg-[#010611] overflow-hidden p-4`}>
       <style>{`
          @keyframes floatUp {
            0% { transform: translateY(20px) scale(0.8); opacity: 0; }
            30% { opacity: 1; }
            70% { opacity: 1; }
            100% { transform: translateY(-160px) scale(1.1); opacity: 0; }
          }
          @keyframes floatNode {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
          }
          @keyframes scrollVertically {
            0% { transform: translateY(0); }
            100% { transform: translateY(max(-100%, -400px)); }
          }
          .animate-scroll {
            animation: scrollVertically 20s linear infinite;
          }
          .animate-scroll:hover {
            animation-play-state: paused;
          }
          .scrollbar-hide::-webkit-scrollbar {
            display: none;
          }
          .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
          }
       `}</style>
      {/* 顶部标题区 (Removed text per user request, but keeping layout spacing and button if needed) */}
      {standalone && (
          <div className="flex justify-end items-center mb-1 shrink-0">
             <button 
                 onClick={() => { onEnterApp?.(); onNavigate?.('alert-center'); }}
                 className="flex items-center gap-1.5 px-4 py-1.5 bg-[#00B4FF]/10 hover:bg-[#00B4FF]/20 text-[#00B4FF] rounded border border-[#00B4FF]/40 transition-colors font-medium text-xs tracking-wider"
             >
                 <Activity size={14} />
                 进入告警中心
             </button>
          </div>
      )}

      {/* Grid Layout */}
      <div className="grid grid-cols-12 grid-rows-[3fr_2fr] gap-4 flex-1 min-h-0">
         
         {/* -- 第一列 -- */}
         <div className="col-span-3 flex flex-col gap-4 min-h-0 row-span-2">
             {/* 左上: 监控总览 */}
             <SciFiPanel className="flex-[3]">
                <div className="flex flex-col items-start pt-2 pl-2">
                   <h2 className="text-white text-[15px] font-bold tracking-widest">监控总览</h2>
                </div>
                <div className="flex-1 w-full h-[220px] relative mt-2">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={OVERVIEW_PIE_DATA}
                            cx="50%"
                            cy="50%"
                            innerRadius="45%"
                            outerRadius="65%"
                            dataKey="value"
                            stroke="none"
                            labelLine={{ stroke: '#475569', strokeWidth: 1 }}
                            label={({ cx, cy, midAngle, innerRadius, outerRadius, value, name, percent, fill }) => {
                               const RADIAN = Math.PI / 180;
                               const radius = innerRadius + (outerRadius - innerRadius) + 15;
                               const x = cx + radius * Math.cos(-midAngle * RADIAN);
                               const y = cy + radius * Math.sin(-midAngle * RADIAN);
                               const textAnchor = x > cx ? 'start' : 'end';
                               return (
                                  <text x={x + (x > cx ? 5 : -5)} y={y} fill={fill} textAnchor={textAnchor} dominantBaseline="central" fontSize={10}>
                                    {name} {(percent * 100).toFixed(2)}%
                                  </text>
                               );
                            }}
                          >
                            {OVERVIEW_PIE_DATA.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.fill} />
                            ))}
                          </Pie>
                        </PieChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none pb-2 mt-4 text-[#00F0FF]">
                        <span className="text-[32px] font-bold font-mono text-white leading-none">67</span>
                    </div>
                </div>
             </SciFiPanel>

             {/* 左下: 最近告警列表 */}
             <SciFiPanel className="flex-[2] overflow-hidden flex flex-col">
                <div className="flex justify-between items-center mb-3 shrink-0">
                    <h3 className="text-white font-bold text-[13px] tracking-wider relative pl-2 before:content-[''] before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-[3px] before:h-3.5 before:bg-[#00B4FF]">最近告警列表</h3>
                    <button onClick={() => { onEnterApp?.(); onNavigate?.('alert-center'); }} className="text-[#3b82f6] relative z-20 text-[11px] hover:text-[#00F0FF] transition-colors cursor-pointer">进入列表</button>
                </div>
                <div className="flex-1 overflow-hidden relative group">
                    <div className="absolute inset-x-0 top-0 pr-1 space-y-2 animate-scroll group-hover:[animation-play-state:paused]">
                        {[...RECENT_ALARMS, ...RECENT_ALARMS, ...RECENT_ALARMS].map((alarm, idx) => (
                            <div key={idx} className="flex gap-2 text-[11px] leading-4 items-start pb-2 border-b border-white/5">
                                <span className="text-slate-400 font-mono shrink-0 whitespace-nowrap mt-0.5">{alarm.time}</span>
                                <span className={`px-1 rounded border whitespace-nowrap shrink-0`} style={{ color: alarm.color, borderColor: alarm.color, backgroundColor: alarm.color + '1a' }}>
                                     <Bell size={10} className="inline-block mr-1 -mt-0.5" />{alarm.level}
                                </span>
                                <span className="text-slate-200">{alarm.desc}</span>
                            </div>
                        ))}
                    </div>
                </div>
             </SciFiPanel>
         </div>

         {/* -- 第二列 -- */}
         <div className="col-span-6 flex flex-col gap-4 min-h-0 row-span-2">
             {/* 中上：网络图 */}
             <SciFiPanel title="平台状态监测" className="flex-[3] overflow-hidden relative">
                 <div className="absolute inset-0 flex items-center justify-center pointer-events-none p-4">
                     {/* SVG Connective Lines and Radar */}
                     <svg className="absolute inset-x-0 w-full h-[120%] z-0 pointer-events-none top-[-10%]">
                        {/* 接口平台 -> green #10b981 */}
                        <path d="M 50% 50% L 35% 50% L 20% 25%" stroke="#10b981" strokeWidth="1.5" fill="none" opacity="0.4" />
                        <path d="M 50% 50% L 35% 50% L 20% 25%" stroke="#10b981" strokeWidth="3" fill="none" opacity="0.9" strokeDasharray="20 150" strokeLinecap="round" style={{ filter: 'drop-shadow(0 0 5px #10b981)' }}>
                            <animate attributeName="stroke-dashoffset" from="170" to="-170" dur="2s" repeatCount="indefinite" />
                        </path>

                        {/* 代码平台 -> green #10b981 */}
                        <path d="M 50% 50% L 35% 50% L 20% 75%" stroke="#10b981" strokeWidth="1.5" fill="none" opacity="0.4" />
                        <path d="M 50% 50% L 35% 50% L 20% 75%" stroke="#10b981" strokeWidth="3" fill="none" opacity="0.9" strokeDasharray="20 150" strokeLinecap="round" style={{ filter: 'drop-shadow(0 0 5px #10b981)' }}>
                            <animate attributeName="stroke-dashoffset" from="170" to="-170" dur="2.3s" repeatCount="indefinite" />
                        </path>

                        {/* 指标平台 -> red #ef4444 */}
                        <path d="M 50% 50% L 65% 50% L 80% 25%" stroke="#ef4444" strokeWidth="1.5" fill="none" opacity="0.4" />
                        <path d="M 50% 50% L 65% 50% L 80% 25%" stroke="#ef4444" strokeWidth="3" fill="none" opacity="0.9" strokeDasharray="20 150" strokeLinecap="round" style={{ filter: 'drop-shadow(0 0 5px #ef4444)' }}>
                            <animate attributeName="stroke-dashoffset" from="170" to="-170" dur="2.1s" repeatCount="indefinite" />
                        </path>

                        {/* 调度平台 -> yellow #f59e0b */}
                        <path d="M 50% 50% L 65% 50% L 80% 75%" stroke="#f59e0b" strokeWidth="1.5" fill="none" opacity="0.4" />
                        <path d="M 50% 50% L 65% 50% L 80% 75%" stroke="#f59e0b" strokeWidth="3" fill="none" opacity="0.9" strokeDasharray="20 150" strokeLinecap="round" style={{ filter: 'drop-shadow(0 0 5px #f59e0b)' }}>
                            <animate attributeName="stroke-dashoffset" from="170" to="-170" dur="2.4s" repeatCount="indefinite" />
                        </path>
                        
                        {/* Concentric rings */}
                        <circle cx="50%" cy="50%" r="30%" stroke="#00B4FF" strokeWidth="1" fill="none" strokeDasharray="4 12" opacity="0.3" className="animate-[spin_60s_linear_infinite] origin-center" style={{ transformOrigin: '50% 50%' }} />
                        <circle cx="50%" cy="50%" r="38%" stroke="#00B4FF" strokeWidth="1" fill="none" strokeDasharray="2 20" opacity="0.15" className="animate-[spin_40s_reverse_linear_infinite] origin-center" style={{ transformOrigin: '50% 50%' }} />
                     </svg>
                     
                     <div className="relative w-full h-full">
                         {/* Central Core */}
                         <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center justify-center pointer-events-none mt-4">
                             {/* Base Circles (3D projection) */}
                             <div className="absolute w-[220px] h-[220px] rounded-full border border-[#00B4FF]/30 top-1/2 mt-[-10px] left-1/2 -ml-[110px] shadow-[0_0_50px_rgba(0,180,255,0.3)] pointer-events-none" style={{ transform: 'rotateX(70deg)' }}></div>
                             <div className="absolute w-[180px] h-[180px] rounded-full border border-[#00B4FF]/50 bg-[#00B4FF]/10 top-1/2 mt-[10px] left-1/2 -ml-[90px] shadow-[inset_0_0_30px_rgba(0,180,255,0.4)] pointer-events-none" style={{ transform: 'rotateX(70deg)' }}></div>
                             
                             {/* Glowing Glass Box / Bouncing Circle */}
                             <div className="relative w-[140px] h-[140px] rounded-full border border-[#00B4FF]/80 bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-white/30 via-[#3b82f6]/60 to-[#0A3D7A]/80 flex flex-col items-center justify-center backdrop-blur-md shadow-[inset_0_0_40px_rgba(0,180,255,0.6),0_0_30px_rgba(0,180,255,0.5)] pointer-events-auto mt-[-40px] animate-[bounce_4s_infinite]">
                                 <div className="flex items-baseline gap-1 text-white font-bold font-mono tracking-tighter drop-shadow-[0_0_15px_#00F0FF] leading-none z-10 transition-transform hover:scale-110 cursor-pointer">
                                     <span className="text-[36px] text-white">80</span>
                                     <span className="text-[20px] text-white/80">/</span>
                                     <span className="text-[20px] text-white">112</span>
                                 </div>
                                 <div className="text-[11px] tracking-widest mt-2 drop-shadow-[0_0_8px_#00F0FF] z-10 flex gap-1">
                                    <span className="text-white">告警数</span>
                                    <span className="text-white/60">/</span>
                                    <span className="text-white">监测总数</span>
                                 </div>
                                 <div className="absolute top-[10%] left-[20%] w-[35px] h-[15px] rounded-[100%] bg-white/40 blur-[2px] transform -rotate-[20deg] mix-blend-overlay"></div>
                                 <div className="absolute inset-0 rounded-full border-[1px] border-white/20"></div>
                             </div>
                         </div>

                         {/* Peripheral Nodes */}
                         <div className="absolute left-[20%] top-[18%] transform -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center justify-center pointer-events-auto mt-2">
                              <div className="absolute w-[120px] h-[120px] rounded-full border border-[#10b981]/40 mt-6 left-1/2 -ml-[60px] shadow-[inset_0_0_20px_rgba(16,185,129,0.4)] bg-[#10b981]/5 pointer-events-none" style={{ transform: 'rotateX(70deg)' }}></div>
                              <FloatingNode title="接口平台" total={27} warning={0} icon={InterfaceIcon} delay="0s" connectPosition="right" warningColor={false} customColor="#10b981" customDarkerColor="#059669" onClick={() => onNavigate?.('secondary-dashboard', { platform: '接口平台' })} />
                         </div>

                         <div className="absolute left-[20%] top-[82%] transform -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center justify-center pointer-events-auto mt-4">
                              <div className="absolute w-[120px] h-[120px] rounded-full border border-[#10b981]/40 mt-6 left-1/2 -ml-[60px] shadow-[inset_0_0_20px_rgba(16,185,129,0.4)] bg-[#10b981]/5 pointer-events-none" style={{ transform: 'rotateX(70deg)' }}></div>
                              <FloatingNode title="代码平台" total={27} warning={0} icon={CodeIcon} delay="1s" connectPosition="right" warningColor={false} customColor="#10b981" customDarkerColor="#059669" onClick={() => onNavigate?.('secondary-dashboard', { platform: '代码平台' })} />
                         </div>

                         <div className="absolute left-[80%] top-[18%] transform -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center justify-center pointer-events-auto mt-2">
                              <div className="absolute w-[120px] h-[120px] rounded-full border border-[#ef4444]/40 mt-6 left-1/2 -ml-[60px] shadow-[inset_0_0_20px_rgba(239,68,68,0.4)] bg-[#ef4444]/5 pointer-events-none" style={{ transform: 'rotateX(70deg)' }}></div>
                              <FloatingNode title="指标平台" total={27} warning={0} warningDetails={[{ label: '紧急告警', count: 2, color: '#ef4444' }]} icon={MetricsIcon} delay="2s" connectPosition="left" warningColor={true} customColor="#ef4444" customDarkerColor="#dc2626" onClick={() => onNavigate?.('secondary-dashboard', { platform: '指标平台' })} />
                         </div>

                         <div className="absolute left-[80%] top-[82%] transform -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center justify-center pointer-events-auto mt-4">
                              <div className="absolute w-[120px] h-[120px] rounded-full border border-[#f59e0b]/40 mt-6 left-1/2 -ml-[60px] shadow-[inset_0_0_20px_rgba(245,158,11,0.4)] bg-[#f59e0b]/5 pointer-events-none" style={{ transform: 'rotateX(70deg)' }}></div>
                              <FloatingNode title="调度平台" total={27} warning={0} warningDetails={[{ label: '严重告警', count: 2, color: '#f59e0b' }, { label: '警告告警', count: 2, color: '#fcd34d' }]} icon={ScheduleIcon} delay="3s" connectPosition="left" warningColor={true} customColor="#f59e0b" customDarkerColor="#d97706" onClick={() => onNavigate?.('secondary-dashboard', { platform: '调度平台' })} />
                         </div>
                     </div>
                 </div>
             </SciFiPanel>

             {/* 中下：折线图 告警与自愈趋势 */}
             <SciFiPanel className="flex-[2] flex flex-col">
                 <div className="flex items-center gap-2 mb-2 shrink-0">
                     <Activity size={14} className="text-slate-300" />
                     <h3 className="text-white font-bold tracking-wider text-[13px]">告警与自愈趋势</h3>
                 </div>
                 <div className="w-full flex-1 min-h-0 pr-4">
                     <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={TREND_DATA} margin={{ top: 20, right: 10, left: -10, bottom: 0 }}>
                           <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                           <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} tickMargin={10} />
                           <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} tickMargin={10} domain={[0, 600]} ticks={[0, 150, 300, 450, 600]} />
                           <Tooltip 
                             contentStyle={{ backgroundColor: '#020B1A', borderColor: '#3b82f6', color: '#fff', fontSize: '12px' }}
                           />
                           <Legend verticalAlign="bottom" height={20} content={(props: any) => {
                               const { payload } = props;
                               return (
                                 <ul className="flex justify-center gap-6 text-[11px] text-[#cbd5e1] mt-2">
                                   {payload.map((entry: any, index: number) => (
                                     <li key={`item-${index}`} className="flex items-center gap-1.5 cursor-pointer">
                                       <div className="flex items-center w-5 h-px" style={{ backgroundColor: entry.color }}>
                                         <div className="w-2 h-2 rounded-full border-[1.5px] bg-[#010611] mx-auto" style={{ borderColor: entry.color }}></div>
                                       </div>
                                       <span>{entry.value}</span>
                                     </li>
                                   ))}
                                 </ul>
                               );
                           }} />
                           <Line type="monotone" dataKey="alarm" name="监控告警量" stroke="#f59e0b" strokeWidth={2} dot={{ r: 4, fill: '#010611', stroke: '#f59e0b', strokeWidth: 2 }} activeDot={{ r: 6 }} />
                           <Line type="monotone" dataKey="recovery" name="自动恢复量" stroke="#3b82f6" strokeWidth={2} dot={{ r: 4, fill: '#010611', stroke: '#3b82f6', strokeWidth: 2 }} activeDot={{ r: 6 }} />
                        </LineChart>
                     </ResponsiveContainer>
                 </div>
             </SciFiPanel>
         </div>

         {/* -- 第三列 -- */}
         <div className="col-span-3 flex flex-col gap-4 min-h-0 row-span-2">
             
             {/* 采集器节点状态 */}
             <SciFiPanel className="flex-none relative mt-4 lg:mt-0 !overflow-hidden flex flex-col h-[220px]">
                 <div className="flex items-center gap-2 mb-3 mt-1 shrink-0 px-2 text-white">
                     <Server size={14} className="text-slate-300" />
                     <h3 className="font-bold text-[13px] tracking-wider">采集器节点状态</h3>
                 </div>
                 <div className="flex-1 w-full flex flex-col overflow-y-auto items-center scrollbar-hide">
                     <div className="flex flex-col gap-6 pb-2 px-2 w-full mt-2">
                         {[
                             { name: 'main-default-collector' },
                             { name: 'main-default-collector2' }
                         ].map(col => (
                             <div key={col.name} className="flex flex-col">
                                 <h4 className="text-white font-bold text-[14px] mb-3">{col.name}</h4>
                                 <div className="grid grid-cols-4 gap-2 mb-2 text-[10px] text-slate-400">
                                     <span className="col-span-1">运行状态</span>
                                     <span className="col-span-1 text-center">总任务数量</span>
                                     <span className="col-span-1 text-center">启动时间</span>
                                     <span className="col-span-1 text-right">节点名称</span>
                                 </div>
                                 <div className="grid grid-cols-4 gap-2 mb-3 text-[12px] font-mono items-center">
                                     <span className="col-span-1 text-[#10b981] flex items-center gap-1.5 font-bold whitespace-nowrap"><span className="w-1.5 h-1.5 rounded-full bg-[#10b981]"></span> Running</span>
                                     <span className="col-span-1 text-center text-white font-semibold">1,245</span>
                                     <span className="col-span-1 text-center text-white flex justify-center items-baseline whitespace-nowrap font-medium">12<span className="text-[10px] text-slate-400 mx-[2px] font-sans">h</span>45<span className="text-[10px] text-slate-400 ml-[2px] font-sans">m</span></span>
                                     <span className="col-span-1 text-right text-slate-100">node-01</span>
                                 </div>
                                 <div className="w-full bg-[#052e25] border border-[#10b981]/30 rounded py-1.5 flex items-center justify-center text-[#10b981] text-[11px] tracking-widest font-bold shadow-[0_0_10px_rgba(16,185,129,0.1)]">
                                     在线
                                 </div>
                             </div>
                         ))}
                     </div>
                 </div>
             </SciFiPanel>

             {/* 自动处理恢复 */}
             <SciFiPanel className="flex-none">
                 <div className="flex items-center justify-between mb-3 mt-1">
                     <div className="flex items-center gap-2">
                         <Activity size={14} className="text-[#3b82f6]" />
                         <h3 className="text-white font-bold text-[13px] tracking-wider">自动处理恢复 (今日)</h3>
                     </div>
                 </div>
                 <div className="flex justify-between items-end mb-2">
                     <div>
                         <div className="text-[28px] font-mono font-bold text-white leading-none">92.4<span className="text-xs font-sans text-slate-400 ml-1">%</span></div>
                         <div className="text-[10px] text-slate-400 mt-1">综合成功率</div>
                     </div>
                     <div className="flex flex-col items-end gap-1">
                         <div className="text-lg font-mono font-bold text-white leading-none tracking-tight">1,240 <span className="text-[10px] font-sans text-slate-400 font-normal">次告警</span></div>
                     </div>
                 </div>
                 <div className="w-full h-1.5 rounded bg-[#1e293b] flex overflow-hidden mb-1">
                     <div className="h-full bg-[#3b82f6] w-[90%]"></div>
                     <div className="h-full bg-[#ef4444] w-[10%]"></div>
                 </div>
             </SciFiPanel>

             {/* 告警分类 */}
             <SciFiPanel className="flex-[1.2] flex flex-col">
                 <div className="flex items-center justify-start pl-2 mb-1 shrink-0 mt-1">
                     <h3 className="text-white font-bold tracking-wider text-[12px]">告警分类</h3>
                 </div>
                 <div className="w-full flex-1 min-h-0">
                     <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={ALARM_CLASS_DATA} margin={{ top: 20, right: 0, left: -5, bottom: 0 }} barCategoryGap="15%">
                           <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                           <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} tickMargin={10} />
                           <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} tickMargin={10} domain={[0, 4000]} ticks={[0, 2000, 4000]} />
                           <Tooltip cursor={{ fill: 'rgba(255,255,255,0.05)' }} contentStyle={{ backgroundColor: '#020B1A', borderColor: '#334155', color: '#fff', fontSize: '11px' }} />
                           <Bar dataKey="count">
                              {ALARM_CLASS_DATA.map((entry, index) => (
                                 <Cell key={`cell-${index}`} fill={entry.fill} />
                              ))}
                           </Bar>
                        </BarChart>
                     </ResponsiveContainer>
                 </div>
             </SciFiPanel>

             {/* 处理专家 Top5 */}
             <SciFiPanel className="flex-[1.2] flex flex-col">
                 <div className="flex items-center justify-between mb-3 border-b border-[#1e293b] pb-2 shrink-0 mt-1">
                     <div className="flex items-center gap-2">
                         <User size={13} className="text-slate-300" />
                         <h3 className="text-white font-bold tracking-wider text-[12px]">处理专家 Top5</h3>
                     </div>
                     <span className="text-[10px] text-slate-400">本周贡献</span>
                 </div>
                 <div className="flex flex-col justify-around flex-1 pb-1">
                     {EXPERT_DATA.map((expert, idx) => (
                         <div key={idx} className="flex items-center justify-between text-[11px]">
                             <div className="flex items-center gap-2 w-14 shrink-0">
                                 <span className="text-[#3b82f6] font-mono font-bold">{idx + 1}.</span>
                                 <span className="text-slate-300">{expert.name}</span>
                             </div>
                             <div className="flex-1 flex items-center mx-2 gap-1">
                                 <div className="w-full h-1 bg-[#1e293b] rounded overflow-hidden flex">
                                     <div className="h-full bg-[#3b82f6]" style={{ width: `${expert.pct}%` }}></div>
                                 </div>
                             </div>
                             <span className="w-6 flex justify-end text-slate-300 font-mono text-[10px]">{expert.score}</span>
                         </div>
                     ))}
                 </div>
             </SciFiPanel>
         </div>

      </div>

    </div>
  );
}

