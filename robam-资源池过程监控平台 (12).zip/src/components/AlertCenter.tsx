import React, { useState } from 'react';
import { 
  HelpCircle, FileText, Settings, Play, Ban, RefreshCw, ChevronDown, ListFilter, 
  Search, Clock, ShieldAlert, Tag, User, ChevronRight, X, History, Activity, 
  Info, Edit, Layers, Lock, ShieldCheck, Check 
} from 'lucide-react';

// 模拟告警数据 (包含所属业务域)
const INITIAL_ALARM_DATA = [
  {
    id: 1,
    name: 'linux操作系统 / CPU 信息 / 使用率-Alert Resolved Notice : usage > 60',
    domain: '调度平台',
    alertState: '告警中',
    status: '未处理',
    statusColor: 'bg-red-100 text-red-600',
    level: '严重告警',
    levelColor: 'text-[#ea580c] border-[#ea580c] bg-orange-50',
    type: '公共告警',
    tags: ['大数据', '磁盘'],
    handler: '穆工',
    processTime: '-',
    createTime: '2026-03-30 09:04:56',
    autoScript: {
      name: '清理临时文件',
      status: '执行失败',
      logs: '执行超时, error code 124...'
    },
    processResult: '',
    history: [
      { step: '告警推送', operator: '系统自动', time: '2026-03-30 09:04:56' },
      { step: '自动处理失败', operator: 'Auto-Fix-Agent', time: '2026-03-30 09:05:12' }
    ]
  },
  {
    id: 2,
    name: 'linux操作系统 / CPU 信息 / 使用率-Alert Resolved Notice : usage > 60',
    domain: '资源池平台',
    alertState: '告警中',
    status: '处理中',
    statusColor: 'bg-blue-100 text-blue-600',
    level: '紧急告警',
    levelColor: 'text-[#dc2626] border-[#dc2626] bg-red-50',
    type: '定制化告警',
    tags: ['Doris', '节点状态'],
    handler: '章工',
    processTime: '2026-03-30 09:12:00',
    createTime: '2026-03-30 09:10:00',
    history: [
      { step: '告警推送', operator: '系统自动', time: '2026-03-30 09:10:00' },
      { step: '开始处理', operator: '章工', time: '2026-03-30 09:12:00' }
    ]
  },
  {
    id: 3,
    name: 'linux操作系统 / CPU 信息 / 使用率-Alert Resolved Notice : usage > 60',
    domain: '调度平台',
    alertState: '已恢复',
    status: '已处理',
    statusColor: 'bg-green-100 text-green-600',
    level: '警告告警',
    levelColor: 'text-[#f59e0b] border-[#f59e0b] bg-yellow-50',
    type: '公共告警',
    tags: ['网站监测', '可用性'],
    handler: '穆工',
    processTime: '2026-03-30 08:30:00',
    createTime: '2026-03-30 08:25:00',
    autoScript: null,
    processResult: '已通过重启服务解决',
    history: [
      { step: '告警推送', operator: '系统自动', time: '2026-03-30 08:25:00' },
      { step: '开始处理', operator: '穆工', time: '2026-03-30 08:26:00' },
      { step: '撰写处理结果', operator: '穆工', time: '2026-03-30 08:29:00' },
      { step: '处理完成', operator: '穆工', time: '2026-03-30 08:30:00' }
    ]
  },
  {
    id: 4,
    name: 'linux操作系统 / CPU 信息 / 使用率-Alert Resolved Notice : usage > 60',
    domain: '运维平台',
    alertState: '告警中',
    status: '已忽略',
    statusColor: 'bg-gray-100 text-gray-600',
    level: '警告告警',
    levelColor: 'text-[#f59e0b] border-[#f59e0b] bg-yellow-50',
    type: '公共告警',
    tags: ['测试', 'CPU'],
    handler: '李工',
    processTime: '2026-03-30 08:05:00',
    createTime: '2026-03-30 08:00:00',
    history: [
      { step: '告警推送', operator: '系统自动', time: '2026-03-30 08:00:00' },
      { step: '标记忽略', operator: '李工', time: '2026-03-30 08:05:00' }
    ]
  },
  {
    id: 5,
    name: 'linux操作系统 / CPU 信息 / 使用率-Alert Resolved Notice : usage > 60',
    domain: '资源池平台',
    alertState: '告警中',
    status: '未处理',
    statusColor: 'bg-red-100 text-red-600',
    level: '紧急告警',
    levelColor: 'text-[#dc2626] border-[#dc2626] bg-red-50',
    type: '公共告警',
    tags: ['Redis', '内存'],
    handler: '章工',
    processTime: '-',
    createTime: '2026-03-30 09:30:45',
    history: [
      { step: '告警推送', operator: '系统自动', time: '2026-03-30 09:30:45' }
    ]
  }
];

interface AlertCenterProps {
  key?: React.Key;
  initialDomain?: string;
}

export default function AlertCenter({ initialDomain }: AlertCenterProps) {
  const [alarms, setAlarms] = useState(INITIAL_ALARM_DATA);
  const [selectedRecord, setSelectedRecord] = useState<any>(null);
  const [detailRecord, setDetailRecord] = useState<any>(null);
  const [isLogExpanded, setIsLogExpanded] = useState(false);

  // 业务域状态管理 (支持非管理员在页面创建)
  const [domains, setDomains] = useState([
    { id: 'all', name: '全部业务域' },
    { id: 'domain-scheduler', name: '调度平台' },
    { id: 'domain-resource', name: '资源池平台' },
    { id: 'domain-ops', name: '运维平台' }
  ]);
  const [selectedDomain, setSelectedDomain] = useState<string>(initialDomain || '全部业务域');

  // 当前模拟登录用户 (非管理员或者普通研发/运维人员，如: 雷秋子 / 穆工)
  const currentUser = {
    name: '雷秋子',
    empId: '250992',
    role: '运维开发工程师',
    email: 'leiqz@robam.com'
  };

  // 新建业务域模态框
  const [isCreateDomainModalOpen, setIsCreateDomainModalOpen] = useState(false);
  const [newDomainForm, setNewDomainForm] = useState({
    name: '',
    tags: 'production, core',
    desc: ''
  });
  const [domainCreatedNotice, setDomainCreatedNotice] = useState<string | null>(null);

  // 处理创建业务域 (非管理员默认负责人与处理人为当前用户)
  const handleCreateDomain = () => {
    if (!newDomainForm.name.trim()) {
      alert('请填写业务域名称');
      return;
    }
    const domainName = newDomainForm.name.trim();
    if (domains.some(d => d.name === domainName)) {
      alert('已存在同名业务域，请修改名称');
      return;
    }

    const newId = `domain-custom-${Date.now()}`;
    const newDom = { id: newId, name: domainName };
    setDomains([...domains, newDom]);
    setSelectedDomain(domainName);
    setIsCreateDomainModalOpen(false);
    setNewDomainForm({ name: '', tags: '', desc: '' });

    setDomainCreatedNotice(`🎉 业务域「${domainName}」创建成功！负责人与默认处理人已自动设定为当前用户【${currentUser.name}】。`);
    setTimeout(() => setDomainCreatedNotice(null), 4000);
  };

  // 根据所选业务域过滤告警
  const filteredAlarms = alarms.filter(alarm => {
    if (selectedDomain === '全部业务域') return true;
    return alarm.domain === selectedDomain;
  });

  const handleTakeover = (id: number) => {
      if (window.confirm('确定要接管此告警吗？接管后您将成为此告警的处理人。')) {
          const now = new Date();
          const timeStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
          
          setAlarms(alarms.map(alarm => {
              if (alarm.id === id) {
                  return {
                      ...alarm,
                      status: '处理中',
                      statusColor: 'bg-blue-100 text-blue-600',
                      handler: currentUser.name,
                      processTime: timeStr,
                      history: [
                          ...alarm.history,
                          { step: '接管处理', operator: currentUser.name, time: timeStr }
                      ]
                  }
              }
              return alarm;
          }));
      }
  };

  return (
    <div className="w-full h-full flex flex-col bg-white">
      {/* 顶部标题与描述 */}
      <div className="px-5 py-4 border-b border-gray-100 bg-[#FAFAFA]">
        <div className="flex items-center gap-2 text-gray-800 text-sm font-bold mb-3">
          <ShieldAlert size={18} className="text-[#3b82f6]" />
          告警中心
          <span className="text-gray-300 mx-2">|</span>
          <span className="text-gray-500 font-normal flex items-center gap-1 cursor-pointer hover:text-[#3b82f6] transition-colors"><FileText size={14} /> 告警规则</span>
        </div>
        <p className="text-xs text-gray-500 leading-relaxed mb-3">
          告警中心是集中展示与处理系统告警的统一入口，以列表的形式展示当前触发的所有告警项，支持按告警状态、标签、时间段等条件进行过滤查询。<br />
          您可以对告警进行接手处理、标记忽略、查看处理记录、批量操作等。
        </p>
        <div className="flex gap-4 text-xs text-blue-500">
          <a href="#" className="flex items-center gap-1 hover:underline"><HelpCircle size={14} /> 常见问题</a>
          <a href="#" className="flex items-center gap-1 hover:underline"><FileText size={14} /> 使用指南</a>
        </div>
      </div>

      {/* 业务域选择栏 (支持仪表盘联动与非管理员创建) */}
      <div className="px-5 py-2.5 bg-gradient-to-r from-slate-50 via-blue-50/30 to-slate-50 border-b border-gray-200 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-blue-600"></span>
            当前业务域:
          </span>
          <div className="flex items-center gap-1.5 bg-white p-1 rounded-lg border border-gray-200 shadow-xs">
            {domains.map(dom => {
              const isSelected = selectedDomain === dom.name;
              const count = dom.name === '全部业务域' 
                ? alarms.length 
                : alarms.filter(a => a.domain === dom.name).length;

              return (
                <button
                  key={dom.id}
                  onClick={() => setSelectedDomain(dom.name)}
                  className={`px-3 py-1 rounded text-xs font-medium transition-all flex items-center gap-1.5 ${
                    isSelected 
                      ? 'bg-blue-600 text-white font-bold shadow-xs' 
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <span>{dom.name}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsCreateDomainModalOpen(true)}
            className="bg-white border border-blue-500 text-blue-600 hover:bg-blue-50 px-3 py-1.5 rounded text-xs font-medium transition flex items-center gap-1.5 shadow-xs"
            title="非管理员也可创建所属业务域，创建后自动成为负责人与默认处理人"
          >
            <span className="font-bold text-sm leading-none">+</span>
            新建业务域
            <span className="bg-blue-100 text-blue-700 text-[10px] px-1.5 py-0.2 rounded font-normal">
              非管理员可用
            </span>
          </button>
        </div>
      </div>

      {/* 创建成功提示通知 */}
      {domainCreatedNotice && (
        <div className="mx-5 mt-3 p-3 bg-green-50 border border-green-200 rounded-lg text-xs text-green-800 flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-ping"></span>
            <span>{domainCreatedNotice}</span>
          </div>
          <button onClick={() => setDomainCreatedNotice(null)} className="text-gray-400 hover:text-gray-600 font-bold">✕</button>
        </div>
      )}

      {/* 工具栏 */}
      <div className="px-5 py-3 border-b border-gray-100 flex items-center justify-between bg-white">
        {/* 左侧操作按钮 */}
        <div className="flex items-center gap-2">
          <button className="bg-[#3b82f6] text-white px-3 py-1.5 rounded flex items-center gap-1.5 text-xs font-medium hover:bg-blue-600 transition-colors shadow-sm">
            <RefreshCw size={13} /> 刷新数据
          </button>
          <button className="bg-white border border-gray-200 text-gray-700 px-3 py-1.5 rounded flex items-center gap-1.5 text-xs font-medium hover:bg-gray-50 transition-colors">
            <Play size={13} className="text-blue-500" /> 批量处理
          </button>
          <button className="bg-white border border-gray-200 text-gray-700 px-3 py-1.5 rounded flex items-center gap-1.5 text-xs font-medium hover:bg-gray-50 transition-colors text-red-500">
            <Ban size={13} /> 批量忽略
          </button>
        </div>

        {/* 右侧筛选搜索 */}
        <div className="flex items-center gap-3">
          {/* 时间段筛选 */}
          <button className="h-[30px] border border-gray-200 rounded text-xs px-3 bg-white text-gray-600 flex items-center gap-1.5 hover:border-blue-400 transition-colors">
            <Clock size={13} className="text-gray-400" /> 时间段
          </button>

          {/* 告警状态筛选 */}
          <select className="h-[30px] border border-gray-200 rounded text-xs px-2 bg-white text-gray-600 focus:outline-none focus:border-blue-500 hover:border-blue-400 transition-colors">
            <option>全部告警状态</option>
            <option>告警中</option>
            <option>已恢复</option>
          </select>

          {/* 处理状态筛选 */}
          <select className="h-[30px] border border-gray-200 rounded text-xs px-2 bg-white text-gray-600 focus:outline-none focus:border-blue-500 hover:border-blue-400 transition-colors">
            <option>全部处理状态</option>
            <option>未处理</option>
            <option>处理中</option>
            <option>已处理</option>
            <option>已忽略</option>
          </select>
          
          {/* 标签筛选 */}
          <select className="h-[30px] border border-gray-200 rounded text-xs px-2 bg-white text-gray-600 focus:outline-none focus:border-blue-500 hover:border-blue-400 transition-colors">
            <option>过滤标签</option>
            <option>alertname</option>
            <option>defineid</option>
            <option>instance</option>
            <option>severity</option>
          </select>

          {/* 搜索框 */}
          <div className="h-[30px] border border-gray-200 rounded flex items-center overflow-hidden w-60 focus-within:border-blue-500 transition-colors">
             <input type="text" placeholder="搜索告警对象/内容..." className="text-xs px-3 w-full h-full focus:outline-none placeholder:text-gray-400" />
          </div>
          <button className="h-[30px] bg-[#3b82f6] text-white px-4 rounded text-xs font-medium hover:bg-blue-600 transition-colors">
            搜索
          </button>
        </div>
      </div>

      {/* 数据表格区 */}
      <div className="flex-1 overflow-auto bg-white p-4">
        <table className="w-full text-left text-[13px] border-collapse">
          <thead>
            <tr className="border-b border-gray-100 text-gray-500 bg-gray-50/50">
              <th className="py-3 px-4 font-medium w-10 text-center"><input type="checkbox" className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" /></th>
              <th className="py-3 px-4 font-medium font-bold text-gray-700">告警对象/内容</th>
              <th className="py-3 px-4 font-medium">所属业务域</th>
              <th className="py-3 px-4 font-medium">告警级别</th>
              <th className="py-3 px-4 font-medium text-center">告警状态</th>
              <th className="py-3 px-4 font-medium text-center">处理状态</th>
              <th className="py-3 px-4 font-medium">告警类型</th>
              <th className="py-3 px-4 font-medium">标签</th>
              <th className="py-3 px-4 font-medium">处理人 / 时间</th>
              <th className="py-3 px-4 font-medium">最早开始时间</th>
              <th className="py-3 px-4 font-medium text-right pr-6">操作</th>
            </tr>
          </thead>
          <tbody>
            {filteredAlarms.length === 0 ? (
              <tr>
                <td colSpan={11} className="py-12 text-center text-gray-400 text-xs">
                  当前业务域「{selectedDomain}」暂无相关告警记录
                </td>
              </tr>
            ) : filteredAlarms.map((item) => (
              <tr key={item.id} className="border-b border-gray-50 hover:bg-blue-50/30 transition-colors group">
                <td className="py-4 px-4 text-center"><input type="checkbox" className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" /></td>
                <td className="py-4 px-4">
                    <div className="font-medium text-blue-700 hover:underline cursor-pointer flex flex-col justify-center">
                       <div className="tracking-wide">{item.name.split('-')[0]}</div>
                       {item.name.split('-')[1] && <div className="text-gray-500 font-normal text-xs mt-0.5">{item.name.split('-').slice(1).join('-')}</div>}
                    </div>
                </td>
                <td className="py-4 px-4">
                  <span className={`text-[11px] px-2 py-0.5 rounded font-medium border ${
                    item.domain.includes('调度') ? 'bg-amber-50 text-amber-700 border-amber-200' :
                    item.domain.includes('资源池') ? 'bg-blue-50 text-blue-700 border-blue-200' :
                    'bg-emerald-50 text-emerald-700 border-emerald-200'
                  }`}>
                    {item.domain}
                  </span>
                </td>
                <td className="py-4 px-4">
                    <div className={`inline-block px-1.5 py-0.5 border rounded-sm text-[11px] font-bold ${item.levelColor}`}>
                       {item.level}
                    </div>
                </td>
                <td className="py-4 px-4 text-center">
                    <span className={`inline-flex px-2 py-0.5 rounded text-xs font-bold ${item.alertState === '告警中' ? 'bg-red-100 text-red-600 border border-red-200' : 'bg-green-100 text-green-600 border border-green-200'}`}>
                       {item.alertState === '告警中' ? <Activity size={12} className="mr-1 mt-0.5" /> : null}
                       {item.alertState}
                    </span>
                </td>
                <td className="py-4 px-4 text-center">
                    <span className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${item.statusColor}`}>
                       {item.status === '已处理' && <span className="w-1.5 h-1.5 rounded-full bg-green-500 mr-1.5"></span>}
                       {item.status === '未处理' && <span className="w-1.5 h-1.5 rounded-full bg-red-500 mr-1.5"></span>}
                       {item.status === '处理中' && <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-1.5"></span>}
                       {item.status === '已忽略' && <span className="w-1.5 h-1.5 rounded-full bg-gray-500 mr-1.5"></span>}
                       {item.status}
                    </span>
                </td>
                <td className="py-4 px-4 text-gray-600">
                    <span className="flex items-center gap-1 opacity-90"><ShieldAlert size={14} className="text-gray-400"/> {item.type}</span>
                </td>
                <td className="py-4 px-4">
                    <div className="flex gap-1.5 flex-wrap">
                      {item.tags.map(tag => (
                        <span key={tag} className="border border-green-200 bg-green-50 text-green-700 text-[11px] px-1.5 py-0.5 rounded flex items-center gap-1">
                           {tag === 'Doris' && <span className="bg-green-600 text-white rounded-[2px] px-0.5 text-[9px]">Doris</span>}
                           {tag !== 'Doris' ? tag : ''}
                        </span>
                      ))}
                    </div>
                </td>
                <td className="py-4 px-4 text-gray-500 text-xs">
                    <div className="flex items-center gap-1 text-gray-800 font-medium mb-1"><User size={13} className="text-gray-400"/> {item.handler}</div>
                    <div className="flex items-center gap-1 text-gray-400"><Clock size={12}/> {item.processTime}</div>
                </td>
                <td className="py-4 px-4 text-gray-500 text-xs font-mono">{item.createTime}</td>
                <td className="py-4 px-4 text-right pr-6 space-x-2">
                    <button 
                        onClick={() => setSelectedRecord(item)}
                        className="bg-purple-100 text-purple-700 hover:bg-purple-200 px-2.5 py-1 rounded text-xs font-medium transition-colors flex items-center gap-1 inline-flex"
                    >
                        <History size={13} /> 日志
                    </button>
                    <button 
                        onClick={() => setDetailRecord(item)}
                        className="bg-indigo-50 text-indigo-700 hover:bg-indigo-100 px-2.5 py-1 rounded text-xs font-medium transition-colors flex items-center gap-1 inline-flex"
                    >
                        <Edit size={13} /> 详情
                    </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* 分页组件 (静态展示) */}
        <div className="flex justify-between items-center mt-6 text-xs text-gray-500 px-2 pb-6">
            <div>共 5 条数据</div>
            <div className="flex items-center gap-1">
                <button className="px-2 py-1 border border-gray-200 rounded hover:bg-gray-50 disabled:opacity-50" disabled>&lt;</button>
                <button className="px-2.5 py-1 border border-blue-500 bg-blue-50 text-blue-600 rounded">1</button>
                <button className="px-2 py-1 border border-gray-200 rounded hover:bg-gray-50">&gt;</button>
                <select className="ml-2 border border-gray-200 rounded py-1 px-2 outline-none">
                    <option>10 条/页</option>
                </select>
            </div>
        </div>
      </div>

      {/* 处理记录大弹窗 (Centered Modal) */}
      {selectedRecord && (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-6">
              <div className="bg-white rounded-lg shadow-2xl w-[500px] max-h-[80vh] flex flex-col overflow-hidden">
                  <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 shrink-0">
                     <h3 className="font-bold text-gray-800 flex items-center gap-2 text-base">
                        <History size={18} className="text-purple-600" />
                        处理记录
                     </h3>
                     <button onClick={() => setSelectedRecord(null)} className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-200 rounded transition-colors">
                        <X size={18} />
                     </button>
                  </div>
                  
                  <div className="p-6 flex flex-col gap-5 overflow-y-auto w-full bg-white flex-1">
                      
                      <div className="bg-gray-50 p-4 rounded border border-gray-100 mb-2">
                          <div className="text-xs text-gray-400 mb-1">告警事件</div>
                          <div className="text-[13px] font-bold text-gray-800 leading-tight">{selectedRecord.name}</div>
                      </div>

                      <div className="relative border-l-2 border-gray-100 ml-4 pl-6 py-2 space-y-6">
                          {selectedRecord.history.map((hist: any, index: number) => {
                              const isLast = index === selectedRecord.history.length - 1;
                              let pointColor = 'bg-gray-300 border-white';
                              let textColor = 'text-gray-600';

                              return (
                                  <div key={index} className="relative">
                                      {/* 节点点 */}
                                      <div className={`absolute -left-[31px] top-1 w-3 h-3 rounded-full border-2 box-content ${pointColor}`}></div>
                                      
                                      <div className={`text-[13px] mb-1.5 ${textColor}`}>
                                          {hist.step}
                                      </div>
                                      <div className="text-[11px] text-gray-500 flex items-center gap-3 bg-white">
                                          <span className="flex items-center gap-1 font-medium bg-gray-50 px-1.5 py-0.5 rounded border border-gray-100">
                                              {hist.operator === '系统自动' || hist.operator.includes('Agent') ? <Settings size={11} className="text-gray-400"/> : <User size={11} className="text-blue-400"/>}
                                              {hist.operator}
                                          </span>
                                          <span className="text-gray-400 font-mono tracking-wide">{hist.time}</span>
                                      </div>
                                  </div>
                              );
                          })}
                      </div>

                  </div>
                  
                  {/* 底部按钮 */}
                  <div className="px-6 py-4 border-t border-gray-200 bg-gray-50 flex justify-end gap-3 shrink-0">
                      <button onClick={() => setSelectedRecord(null)} className="px-5 py-2 border border-gray-300 text-gray-700 text-sm font-medium rounded hover:bg-gray-100 transition-colors">
                          关闭
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* 告警详情大弹窗 */}
      {detailRecord && (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-6">
              <div className="bg-white rounded-lg shadow-2xl w-full max-w-4xl max-h-full flex flex-col overflow-hidden">
                  <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 shrink-0">
                      <div className="flex items-center gap-3">
                          <ShieldAlert size={20} className="text-red-500" />
                          <h3 className="font-bold text-gray-800 text-base">告警详情信息</h3>
                          <span className={`inline-flex px-2 py-0.5 rounded text-xs font-bold ml-2 ${detailRecord.alertState === '告警中' ? 'bg-red-100 text-red-600 border border-red-200' : 'bg-green-100 text-green-600 border border-green-200'}`}>
                             {detailRecord.alertState}
                          </span>
                      </div>
                      <button onClick={() => setDetailRecord(null)} className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-200 rounded transition-colors"><X size={20} /></button>
                  </div>
                  
                  <div className="p-6 flex-1 overflow-y-auto bg-white flex flex-col gap-6">
                      {/* Section 1: Overview */}
                      <div className="grid grid-cols-4 gap-4">
                          <div className="col-span-4 mb-2 pb-2 border-b border-gray-100 font-bold text-gray-700 flex items-center gap-2">
                              <Info size={16} className="text-blue-500" /> 基本信息
                          </div>
                          
                          {/* Row 1 */}
                          <div className="col-span-4 flex flex-col gap-1.5">
                              <span className="text-xs text-gray-500">告警对象/内容</span>
                              <span className="font-medium text-gray-900 text-[13px] break-words">{detailRecord.name.replace('-', '——')}</span>
                          </div>
                          
                          {/* Row 2 */}
                          <div className="flex flex-col gap-1.5">
                              <span className="text-xs text-gray-500">告警级别</span>
                              <span className={`inline-flex w-max px-2 py-0.5 border rounded-sm text-[11px] font-bold ${detailRecord.levelColor}`}>{detailRecord.level}</span>
                          </div>
                          <div className="flex flex-col gap-1.5">
                              <span className="text-xs text-gray-500">告警状态</span>
                              <span className={`inline-flex w-max px-2 py-0.5 border rounded-sm text-[11px] font-bold ${detailRecord.alertState === '告警中' ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                                  {detailRecord.alertState || '未恢复'}
                              </span>
                          </div>
                          <div className="flex flex-col gap-1.5">
                              <span className="text-xs text-gray-500">标签</span>
                              <div className="flex gap-1.5 flex-wrap">
                                  {detailRecord.tags.map((tag: string) => (
                                    <span key={tag} className="border border-green-200 bg-green-50 text-green-700 text-[11px] px-1.5 py-0.5 rounded flex items-center gap-1">{tag}</span>
                                  ))}
                              </div>
                          </div>

                          {/* Row 3 */}
                          <div className="flex flex-col gap-1.5">
                              <span className="text-xs text-gray-500">告警类型</span>
                              <span className="font-medium text-gray-900 text-[13px]">公共告警</span>
                          </div>
                          <div className="flex flex-col gap-1.5">
                              <span className="text-xs text-gray-500">处理人 / 时间</span>
                              <span className="font-medium text-gray-900 text-[13px]">{detailRecord.handler || '未分配'}</span>
                          </div>
                          <div className="col-span-2 flex flex-col gap-1.5">
                              <span className="text-xs text-gray-500">监控对象</span>
                              <span className="font-medium text-gray-900 text-[13px] font-mono">MON-1096</span>
                          </div>
                      </div>

                      {/* Section: Alert Stats Summary */}
                      <div className="flex flex-wrap items-center gap-6 justify-between text-[13px] text-gray-600 mb-2">
                          <div><span className="text-gray-400 mr-2">首次告警时间:</span>{detailRecord.createTime}</div>
                          <div><span className="text-gray-400 mr-2">最新告警时间:</span>{detailRecord.createTime}</div>
                          <div>此告警区间累计触发<span className="font-bold text-gray-800 mx-1">1</span>次告警</div>
                      </div>

                      {/* Section: Tags and Annotations */}
                      <div className="flex flex-col gap-4">
                          <div className="flex flex-col gap-2">
                              <div className="text-xs font-bold text-gray-500 mb-1">标记</div>
                              <div className="flex gap-2 flex-wrap">
                                  <span className="border border-gray-200 bg-white text-gray-700 text-xs px-2 py-1 rounded">alertname:端口可用性</span>
                                  <span className="border border-gray-200 bg-white text-gray-700 text-xs px-2 py-1 rounded">defineid:1</span>
                                  <span className="border border-gray-200 bg-white text-gray-700 text-xs px-2 py-1 rounded">instance:172.18.11.186:8088</span>
                                  <span className="border border-gray-200 bg-white text-gray-700 text-xs px-2 py-1 rounded">instancename:测试端口1</span>
                                  <span className="border border-gray-200 bg-white text-gray-700 text-xs px-2 py-1 rounded">severity:emergency</span>
                              </div>
                          </div>
                          <div className="flex flex-col gap-2">
                              <div className="text-xs font-bold text-gray-500 mb-1">注解</div>
                              <div className="flex gap-2 flex-wrap">
                                  {detailRecord.annotation ? (
                                      <span className="border border-gray-200 bg-white text-gray-700 text-xs px-2 py-1 rounded">{detailRecord.annotation}</span>
                                  ) : (
                                      <>
                                          <span className="border border-gray-200 bg-white text-gray-700 text-xs px-2 py-1 rounded">alertname:端口可用性</span>
                                          <span className="border border-gray-200 bg-white text-gray-700 text-xs px-2 py-1 rounded">defineid:1</span>
                                      </>
                                  )}
                              </div>
                          </div>
                      </div>
                      
                      {/* Status Selector */}
                      <div className="flex flex-col gap-2">
                          <label className="text-[13px] font-bold text-gray-700">处理状态设置</label>
                          <select 
                              value={detailRecord.status}
                              onChange={e => setDetailRecord({...detailRecord, status: e.target.value})}
                              className="border border-gray-300 rounded px-3 py-2 w-full max-w-[200px] focus:outline-none focus:border-blue-500 bg-white text-[13px]"
                          >
                              <option value="未处理">未处理</option>
                              <option value="处理中">处理中</option>
                              <option value="已处理">已处理</option>
                              <option value="已忽略">已忽略</option>
                          </select>
                      </div>

                      {/* Section 2: Auto Script */}
                      <div className="flex flex-col gap-4">
                          <div className="mb-2 pb-2 border-b border-gray-100 font-bold text-gray-700 flex items-center gap-2">
                              <FileText size={16} className="text-purple-500" /> 自动脚本执行情况:&nbsp;
                              <span 
                                  className="font-normal text-[13px] text-blue-600 hover:underline cursor-pointer flex items-center gap-1"
                                  onClick={() => setIsLogExpanded(!isLogExpanded)}
                              >
                                  {isLogExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />} 脚本（清理临时文件）成功 2026/5/27 09:47:54
                              </span>
                          </div>
                          {isLogExpanded && (
                              <div className="bg-gray-900 rounded p-4 text-xs font-mono text-gray-300 overflow-x-auto whitespace-pre">
{`[2026-05-20 17:39:17] Last login: Wed May 20 17:35:09 2026 from 172.16.72.175

[admin@productpool_tst01 ~]$ cd /data/
[admin@productpool_tst01 data]$ rm -rf access_log.2024-10-14.log
rm: cannot remove ‘access_log.2024-10-14.log’: Permission denied
[admin@productpool_tst01 data]$ ls
access_log.2024-10-13.log  application	arthas-boot.jar  logs	web
access_log.2024-10-14.log  applogs	docker_nginx	 shell	zyc
[admin@productpool_tst01 data]$ 
脚本执行完成`}
                              </div>
                          )}
                      </div>

                      {/* Section 3: Process Result */}
                      <div className="flex flex-col gap-4">
                          <div className="mb-2 pb-2 border-b border-gray-100 font-bold text-gray-700 flex items-center gap-2">
                              <History size={16} className="text-green-500" /> 处理结果
                          </div>
                          <textarea 
                              value={detailRecord.processResult || ''} 
                              onChange={e => setDetailRecord({...detailRecord, processResult: e.target.value})}
                              placeholder="暂无处理结果，可点击此处填写..."
                              className="bg-white rounded p-3 border border-gray-200 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-gray-800 min-h-[80px] resize-none outline-none transition-all"
                          />
                      </div>
                  </div>
                  
                  <div className="px-6 py-4 border-t border-gray-200 bg-gray-50 flex justify-end gap-3 shrink-0">
                      <button 
                          onClick={() => {
                              const now = new Date();
                              const timeStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
                              setAlarms(alarms.map(alarm => {
                                  if (alarm.id === detailRecord.id) {
                                      return {
                                          ...alarm,
                                          annotation: detailRecord.annotation,
                                          processResult: detailRecord.processResult,
                                          status: '已处理',
                                          statusColor: 'bg-green-100 text-green-600',
                                          handler: 'lqz030912@gmail.com',
                                          processTime: timeStr,
                                          history: [
                                              ...alarm.history,
                                              { step: '完成处理', operator: 'lqz030912@gmail.com', time: timeStr }
                                          ]
                                      };
                                  }
                                  return alarm;
                              }));
                              setDetailRecord(null);
                          }} 
                          className="px-5 py-2 bg-blue-600 text-white text-sm font-medium rounded hover:bg-blue-700 transition-colors shadow-sm"
                      >
                          提交
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* 新建业务域模态框 (非管理员自主创建，负责人和处理人默认当前用户) */}
      {isCreateDomainModalOpen && (
        <div className="fixed inset-0 bg-black/45 z-[130] flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-[520px] max-w-full overflow-hidden border border-gray-100 animate-in fade-in zoom-in-95 duration-150">
            {/* 模态框头部 */}
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                  <Layers size={18} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                    创建新业务域
                    <span className="text-[11px] bg-green-50 text-green-700 border border-green-200 px-2 py-0.5 rounded-full font-normal">
                      全员可用 / 非管理员自助建域
                    </span>
                  </h3>
                  <p className="text-[11px] text-gray-500 mt-0.5">创建属于本团队的监控与告警业务隔离空间</p>
                </div>
              </div>
              <button 
                onClick={() => setIsCreateDomainModalOpen(false)} 
                className="text-gray-400 hover:text-gray-600 text-base p-1 rounded-md hover:bg-gray-200/60"
              >
                ✕
              </button>
            </div>

            {/* 模态框内容 */}
            <div className="p-6 space-y-4 text-xs">
              {/* 关键规则提示 */}
              <div className="bg-blue-50/70 border border-blue-200 rounded-lg p-3 text-blue-900 leading-relaxed flex items-start gap-2">
                <Info size={15} className="text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">负责人与处理人自动联动绑定：</span>
                  根据平台规范，由您自主创建的新业务域，负责人与默认处理人将<strong>自动默认设置为当前登录用户</strong>（无需管理员审批介入）。
                </div>
              </div>

              {/* 业务域名称 */}
              <div>
                <label className="font-bold text-gray-700 block mb-1">
                  业务域名称 <span className="text-red-500">*</span>
                </label>
                <input 
                  type="text" 
                  value={newDomainForm.name}
                  onChange={e => setNewDomainForm({...newDomainForm, name: e.target.value})}
                  placeholder="例如：微服务API平台、智能仓储调度平台..."
                  className="w-full border border-gray-300 rounded px-3 py-2 text-xs focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* 负责人 (默认当前用户，自动锁定) */}
              <div>
                <label className="font-bold text-gray-700 flex items-center justify-between mb-1">
                  <span>业务域负责人 <span className="text-red-500">*</span></span>
                  <span className="text-[11px] text-gray-400 font-normal">默认当前创建者</span>
                </label>
                <div className="flex items-center gap-2 border border-blue-200 bg-blue-50/40 rounded px-3 py-2 text-gray-800">
                  <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-[10px]">
                    {currentUser.name.charAt(0)}
                  </div>
                  <span className="font-bold">{currentUser.name}</span>
                  <span className="text-gray-400 font-mono">({currentUser.empId})</span>
                  <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded ml-auto flex items-center gap-1">
                    <Lock size={10} /> 当前用户 (自动锁定)
                  </span>
                </div>
              </div>

              {/* 默认处理人 (默认当前用户，自动联动) */}
              <div>
                <label className="font-bold text-gray-700 flex items-center justify-between mb-1">
                  <span>默认处理人 (兜底) <span className="text-red-500">*</span></span>
                  <span className="text-[11px] text-gray-400 font-normal">告警未匹配特定标签时兜底推送</span>
                </label>
                <div className="flex items-center gap-2 border border-emerald-200 bg-emerald-50/40 rounded px-3 py-2 text-gray-800">
                  <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-[10px]">
                    {currentUser.name.charAt(0)}
                  </div>
                  <span className="font-bold">{currentUser.name}</span>
                  <span className="text-gray-400 font-mono">({currentUser.empId})</span>
                  <span className="text-[10px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded ml-auto flex items-center gap-1">
                    <ShieldCheck size={11} /> 默认处理人 (与负责人联动)
                  </span>
                </div>
              </div>

              {/* 业务域标签 */}
              <div>
                <label className="font-bold text-gray-700 block mb-1">
                  业务域标签标识 <span className="text-gray-400 font-normal">(用于告警自动划域路由，不同业务域标签不可重复)</span>
                </label>
                <input 
                  type="text" 
                  value={newDomainForm.tags}
                  onChange={e => setNewDomainForm({...newDomainForm, tags: e.target.value})}
                  placeholder="例如：api-gateway, microservice"
                  className="w-full border border-gray-300 rounded px-3 py-2 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* 业务域描述 */}
              <div>
                <label className="font-bold text-gray-700 block mb-1">业务域定位描述 (选填)</label>
                <textarea 
                  value={newDomainForm.desc}
                  onChange={e => setNewDomainForm({...newDomainForm, desc: e.target.value})}
                  placeholder="简要说明该业务域纳管的集群、应用或生产流水线边界..."
                  rows={2}
                  className="w-full border border-gray-300 rounded p-2.5 text-xs focus:outline-none focus:border-blue-500 resize-none"
                />
              </div>
            </div>

            {/* 模态框底部操作 */}
            <div className="px-6 py-3.5 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
              <button 
                onClick={() => setIsCreateDomainModalOpen(false)}
                className="px-4 py-1.5 border border-gray-300 rounded text-gray-600 hover:bg-gray-100 text-xs font-medium transition"
              >
                取消
              </button>
              <button 
                onClick={handleCreateDomain}
                className="px-5 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 text-xs font-medium transition shadow-sm flex items-center gap-1.5"
              >
                <Check size={14} /> 确认创建并接入业务域
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
