import React, { useState } from 'react';
import { 
  UserCog, Plus, Edit, Trash2, Tag, ShieldCheck, 
  MessageSquare, Smartphone, Lock, Check, X, Info, 
  AlertCircle, Users, BellDot, CheckCircle2, ChevronRight, Layers
} from 'lucide-react';

interface DomainHandlerItem {
  id: string;
  isDefault: boolean; // 第一行必须为默认处理人 (只能修改不能删除)
  userName: string;
  empId: string;
  role: string;
  tags: string[]; // 默认处理人为兜底所有，其他处理人多选标签
  dingtalkAt: boolean; // 钉钉群消息 @处理人
  dingtalkPrivate: boolean; // 钉钉个人推送工作通知
  note?: string;
  updatedAt: string;
}

interface DomainUser {
  id: number;
  name: string;
  empId: string;
  role: string;
  phone: string;
  email: string;
}

export default function HandlerConfig() {
  // 当前选择的业务域 (系统处理人只能设置当前业务域的处理人)
  const [currentDomain, setCurrentDomain] = useState<'调度平台' | '资源池平台' | '运维平台'>('调度平台');

  // 各业务域具备权限的账号人员 (只能选择有此业务域权限的人员)
  const DOMAIN_AUTHORIZED_USERS: Record<string, DomainUser[]> = {
    '调度平台': [
      { id: 2, name: '穆工', empId: '250993', role: '调度平台负责人', phone: '13900139002', email: 'mug@robam.com' },
      { id: 3, name: '赵工', empId: '250995', role: '调度平台运维工程师', phone: '13711114444', email: 'zhaog@robam.com' },
      { id: 1, name: '雷秋子', empId: '250992', role: '超级管理员 (全局权限)', phone: '13800138001', email: 'leiqz@robam.com' }
    ],
    '资源池平台': [
      { id: 4, name: '章工', empId: '250994', role: '资源池平台负责人', phone: '13811112222', email: 'zhangg@robam.com' },
      { id: 5, name: '李工', empId: '250996', role: '资源池平台运维工程师', phone: '13611115555', email: 'lig@robam.com' },
      { id: 1, name: '雷秋子', empId: '250992', role: '超级管理员 (全局权限)', phone: '13800138001', email: 'leiqz@robam.com' }
    ],
    '运维平台': [
      { id: 6, name: '陈工', empId: '250997', role: '运维平台负责人', phone: '13511116666', email: 'cheng@robam.com' },
      { id: 7, name: '王工', empId: '250998', role: '运维平台告警处理人', phone: '13411117777', email: 'wangg@robam.com' },
      { id: 1, name: '雷秋子', empId: '250992', role: '超级管理员 (全局权限)', phone: '13800138001', email: 'leiqz@robam.com' }
    ]
  };

  // 各业务域的处理人列表：第一行展示默认处理人 (只能修改不能删除)，后续为新增的处理人 (可多选标签，可删除)
  const [handlersMap, setHandlersMap] = useState<Record<string, DomainHandlerItem[]>>({
    '调度平台': [
      {
        id: 'h-scheduler-default',
        isDefault: true,
        userName: '穆工',
        empId: '250993',
        role: '调度平台负责人',
        tags: ['业务域全量兜底 / 无标签匹配时默认生效'],
        dingtalkAt: true,
        dingtalkPrivate: true,
        note: '业务域主处理人，当告警未命中其他特定标签时接收全部告警推送',
        updatedAt: '2026-06-12 10:30'
      },
      {
        id: 'h-scheduler-custom-1',
        isDefault: false,
        userName: '赵工',
        empId: '250995',
        role: '调度平台运维工程师',
        tags: ['DAG调度任务', 'ETL增量作业', 'Doris', 'P0紧急'],
        dingtalkAt: true,
        dingtalkPrivate: true,
        note: '专门处置大数据ETL及离线计算调度延迟异常',
        updatedAt: '2026-06-12 09:15'
      }
    ],
    '资源池平台': [
      {
        id: 'h-resource-default',
        isDefault: true,
        userName: '章工',
        empId: '250994',
        role: '资源池平台负责人',
        tags: ['业务域全量兜底 / 无标签匹配时默认生效'],
        dingtalkAt: true,
        dingtalkPrivate: true,
        note: '资源池主负责人，默认全量兜底接收',
        updatedAt: '2026-06-11 16:20'
      },
      {
        id: 'h-resource-custom-1',
        isDefault: false,
        userName: '李工',
        empId: '250996',
        role: '资源池平台运维工程师',
        tags: ['K8s节点', '母机硬件', '网络设备', 'CPU告警'],
        dingtalkAt: true,
        dingtalkPrivate: false,
        note: '负责母机宕机与生产容器池物理故障排查',
        updatedAt: '2026-06-11 14:00'
      }
    ],
    '运维平台': [
      {
        id: 'h-ops-default',
        isDefault: true,
        userName: '陈工',
        empId: '250997',
        role: '运维平台负责人',
        tags: ['业务域全量兜底 / 无标签匹配时默认生效'],
        dingtalkAt: true,
        dingtalkPrivate: true,
        note: '自动化运维与自愈平台兜底接收人',
        updatedAt: '2026-06-10 11:00'
      },
      {
        id: 'h-ops-custom-1',
        isDefault: false,
        userName: '王工',
        empId: '250998',
        role: '运维平台告警处理人',
        tags: ['巡检探针', '自愈超时', 'API接口', '内存告警'],
        dingtalkAt: true,
        dingtalkPrivate: true,
        note: '负责自动化脚本异常及工单分派',
        updatedAt: '2026-06-10 09:40'
      }
    ]
  });

  // 弹窗表单状态
  const [modalOpen, setModalOpen] = useState(false);
  const [editingHandler, setEditingHandler] = useState<DomainHandlerItem | null>(null);
  const [formUserName, setFormUserName] = useState('');
  const [formSelectedTags, setFormSelectedTags] = useState<string[]>([]);
  const [formDingtalkAt, setFormDingtalkAt] = useState(true);
  const [formDingtalkPrivate, setFormDingtalkPrivate] = useState(true);
  const [formNote, setFormNote] = useState('');
  const [customTagInput, setCustomTagInput] = useState('');

  // 预设常用标签池
  const PRESET_TAGS = [
    'P0紧急', 'CPU告警', '内存告警', '磁盘空间', 
    'Doris', 'DAG调度任务', '网络延迟', 'API接口', 
    'K8s容器', '巡检探针', '自愈超时'
  ];

  // 当前业务域下的处理人列表
  const currentHandlers = handlersMap[currentDomain] || [];
  // 当前业务域下有权限的人员名单
  const authorizedUsers = DOMAIN_AUTHORIZED_USERS[currentDomain] || [];

  // 打开新增/编辑弹窗
  const handleOpenModal = (item: DomainHandlerItem | null = null) => {
    if (item) {
      setEditingHandler(item);
      setFormUserName(item.userName);
      setFormSelectedTags(item.isDefault ? [] : [...item.tags]);
      setFormDingtalkAt(item.dingtalkAt);
      setFormDingtalkPrivate(item.dingtalkPrivate);
      setFormNote(item.note || '');
    } else {
      // 新增其他处理人，默认选第一个有权限人员（如果还有非默认的）
      const candidate = authorizedUsers.find(u => u.name !== currentHandlers[0]?.userName) || authorizedUsers[0];
      setEditingHandler(null);
      setFormUserName(candidate ? candidate.name : authorizedUsers[0]?.name || '');
      setFormSelectedTags(['P0紧急']);
      setFormDingtalkAt(true);
      setFormDingtalkPrivate(true);
      setFormNote('');
    }
    setCustomTagInput('');
    setModalOpen(true);
  };

  // 保存处理人设置
  const handleSaveHandler = () => {
    if (!formUserName) {
      alert('请选择有此业务域权限的处理人员');
      return;
    }

    const selectedUserObj = authorizedUsers.find(u => u.name === formUserName);
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;

    if (editingHandler) {
      // 修改现有处理人 (包括默认处理人)
      const updatedList = currentHandlers.map(h => {
        if (h.id === editingHandler.id) {
          return {
            ...h,
            userName: formUserName,
            empId: selectedUserObj?.empId || h.empId,
            role: selectedUserObj?.role || h.role,
            tags: h.isDefault ? h.tags : (formSelectedTags.length > 0 ? formSelectedTags : ['默认']),
            dingtalkAt: formDingtalkAt,
            dingtalkPrivate: formDingtalkPrivate,
            note: formNote,
            updatedAt: dateStr
          };
        }
        return h;
      });

      setHandlersMap({
        ...handlersMap,
        [currentDomain]: updatedList
      });
    } else {
      // 新增其他处理人 (允许被删除)
      if (formSelectedTags.length === 0) {
        alert('请至少勾选一个匹配标签');
        return;
      }
      const newItem: DomainHandlerItem = {
        id: `h-${currentDomain}-${Date.now()}`,
        isDefault: false,
        userName: formUserName,
        empId: selectedUserObj?.empId || '000000',
        role: selectedUserObj?.role || '运维工程师',
        tags: formSelectedTags,
        dingtalkAt: formDingtalkAt,
        dingtalkPrivate: formDingtalkPrivate,
        note: formNote,
        updatedAt: dateStr
      };

      setHandlersMap({
        ...handlersMap,
        [currentDomain]: [...currentHandlers, newItem]
      });
    }

    setModalOpen(false);
  };

  // 删除新增的处理人 (第一行默认处理人不允许删除)
  const handleDeleteHandler = (id: string) => {
    const target = currentHandlers.find(h => h.id === id);
    if (target?.isDefault) {
      alert('默认处理人为业务域兜底接收人，只能修改不能删除！');
      return;
    }

    if (window.confirm(`确定要删除处理人「${target?.userName}」的标签路由配置吗？`)) {
      setHandlersMap({
        ...handlersMap,
        [currentDomain]: currentHandlers.filter(h => h.id !== id)
      });
    }
  };

  // 标签多选切换
  const toggleTagSelection = (tag: string) => {
    if (formSelectedTags.includes(tag)) {
      setFormSelectedTags(formSelectedTags.filter(t => t !== tag));
    } else {
      setFormSelectedTags([...formSelectedTags, tag]);
    }
  };

  const handleAddCustomTag = () => {
    if (customTagInput.trim() && !formSelectedTags.includes(customTagInput.trim())) {
      setFormSelectedTags([...formSelectedTags, customTagInput.trim()]);
      setCustomTagInput('');
    }
  };

  return (
    <div className="w-full h-full flex flex-col bg-white overflow-hidden text-[13px]">
      
      {/* 顶部标题栏 */}
      <div className="px-6 py-4 border-b border-gray-100 bg-[#FAFAFA] shrink-0">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2 text-gray-800 text-sm font-bold">
            <UserCog size={18} className="text-[#3b82f6]" />
            系统处理人配置 (业务域隔离)
          </div>
          <div className="text-xs text-gray-500 font-mono">
            当前业务域授权人员：<strong>{authorizedUsers.length}</strong> 人
          </div>
        </div>

        {/* 关键职能架构说明 Banner */}
        <div className="bg-gradient-to-r from-blue-50/90 via-indigo-50/60 to-slate-50 border border-blue-200 rounded-lg p-3 text-xs text-gray-700 leading-relaxed">
          <div className="flex items-start gap-2">
            <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
              钉
            </div>
            <div>
              <span className="font-bold text-gray-900">处理人通知机制说明：</span>
              系统处理人严格在当前业务域内隔离生效，其唯一作用为<strong>钉钉消息路由目标</strong>：
              <span className="inline-block mx-1 font-semibold text-blue-800">
                ① 告警推送至钉钉群时，根据匹配标签在群消息中精准 @处理人；
              </span>
              <span className="inline-block mx-1 font-semibold text-indigo-800">
                ② 开启钉钉个人工作通知时，确定推送给哪些人员。
              </span>
              列表第一行固定为<strong>默认处理人（只能修改不能删除）</strong>，未命中特定标签时由其兜底接收。
            </div>
          </div>
        </div>

        {/* 业务域切换 (只能设置当前业务域的处理人) */}
        <div className="flex items-center justify-between mt-4 pt-1">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
              <Layers size={14} className="text-blue-600" />
              当前业务域:
            </span>
            <div className="flex items-center gap-1.5 bg-gray-200/60 p-1 rounded-lg">
              {(['调度平台', '资源池平台', '运维平台'] as const).map(dom => {
                const isSelected = currentDomain === dom;
                return (
                  <button
                    key={dom}
                    onClick={() => setCurrentDomain(dom)}
                    className={`px-3.5 py-1.5 rounded-md text-xs font-medium transition-all ${
                      isSelected 
                        ? 'bg-blue-600 text-white shadow-xs font-bold' 
                        : 'text-gray-600 hover:text-gray-900 hover:bg-white/60'
                    }`}
                  >
                    {dom}
                  </button>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => handleOpenModal(null)}
            className="bg-blue-600 text-white px-3.5 py-1.5 rounded text-xs font-medium hover:bg-blue-700 transition flex items-center gap-1.5 shadow-sm"
          >
            <Plus size={14} /> 新增其他处理人 (多选标签)
          </button>
        </div>
      </div>

      {/* 处理人列表表格 */}
      <div className="flex-1 overflow-auto bg-white p-5 flex flex-col">
        <div className="border border-gray-100 rounded-lg overflow-hidden shadow-sm flex-1">
          <table className="w-full text-left text-[13px] border-collapse">
            <thead>
              <tr className="border-b border-gray-200 text-gray-500 bg-gray-50/70">
                <th className="py-3 px-4 font-bold text-gray-700 w-36">处理人身份</th>
                <th className="py-3 px-4 font-bold text-gray-700">处理人姓名 / 账号</th>
                <th className="py-3 px-4 font-bold text-gray-700 w-2/5">匹配标签 (多选路由)</th>
                <th className="py-3 px-4 font-bold text-gray-700">钉钉推送作用</th>
                <th className="py-3 px-4 font-bold text-gray-700">最近修改时间</th>
                <th className="py-3 px-4 font-bold text-gray-700 text-right pr-6">操作</th>
              </tr>
            </thead>
            <tbody>
              {currentHandlers.map((item, index) => {
                const isFirstRowDefault = index === 0 && item.isDefault;

                return (
                  <tr 
                    key={item.id} 
                    className={`border-b border-gray-100 hover:bg-blue-50/20 transition-colors ${
                      isFirstRowDefault ? 'bg-amber-50/30' : ''
                    }`}
                  >
                    {/* 处理人身份 */}
                    <td className="py-3.5 px-4">
                      {isFirstRowDefault ? (
                        <div className="flex items-center gap-1.5">
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-amber-100/80 border border-amber-300 text-amber-800 text-xs font-bold">
                            <ShieldCheck size={13} className="text-amber-600" />
                            默认处理人
                          </span>
                        </div>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-50 border border-blue-200 text-blue-700 text-xs font-medium">
                          扩展处理人
                        </span>
                      )}
                    </td>

                    {/* 处理人姓名 / 账号 (仅限本业务域权限人员) */}
                    <td className="py-3.5 px-4 font-medium text-gray-800">
                      <div className="flex items-center gap-2">
                        <div className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                          isFirstRowDefault 
                            ? 'bg-amber-200 text-amber-800' 
                            : 'bg-blue-100 text-blue-700'
                        }`}>
                          {item.userName.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold flex items-center gap-1.5">
                            {item.userName}
                            <span className="text-[11px] text-gray-400 font-mono">({item.empId})</span>
                          </div>
                          <div className="text-[11px] text-gray-500">{item.role}</div>
                        </div>
                      </div>
                    </td>

                    {/* 匹配标签 */}
                    <td className="py-3.5 px-4">
                      {isFirstRowDefault ? (
                        <div>
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 text-xs font-mono font-medium">
                            ★ 全量未匹配告警兜底 (默认接收)
                          </span>
                          <div className="text-[11px] text-gray-400 mt-1">
                            当告警未命中下方指定的多选标签时，由此默认处理人兜底接收通知。
                          </div>
                        </div>
                      ) : (
                        <div>
                          <div className="flex flex-wrap gap-1.5">
                            {item.tags.map((tag, tIdx) => (
                              <span 
                                key={tIdx} 
                                className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded font-medium bg-blue-50 text-blue-700 border border-blue-200"
                              >
                                <Tag size={10} className="text-blue-500" />
                                {tag}
                              </span>
                            ))}
                          </div>
                          {item.note && (
                            <div className="text-[11px] text-gray-400 mt-1">
                              备注: {item.note}
                            </div>
                          )}
                        </div>
                      )}
                    </td>

                    {/* 钉钉推送作用 */}
                    <td className="py-3.5 px-4 text-xs">
                      <div className="space-y-1">
                        {item.dingtalkAt && (
                          <div className="flex items-center gap-1.5 text-blue-700">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                            <span>钉钉群推送时 <strong>@{item.userName}</strong></span>
                          </div>
                        )}
                        {item.dingtalkPrivate && (
                          <div className="flex items-center gap-1.5 text-indigo-700">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                            <span>推送钉钉<strong>个人工作通知</strong></span>
                          </div>
                        )}
                        {!item.dingtalkAt && !item.dingtalkPrivate && (
                          <span className="text-gray-400">未启用钉钉推送</span>
                        )}
                      </div>
                    </td>

                    {/* 最近修改时间 */}
                    <td className="py-3.5 px-4 text-xs font-mono text-gray-500">
                      {item.updatedAt}
                    </td>

                    {/* 操作列: 默认处理人只能修改不能删除，新增的可以删除 */}
                    <td className="py-3.5 px-4 text-right pr-6 space-x-2 whitespace-nowrap">
                      <button 
                        onClick={() => handleOpenModal(item)}
                        className="text-blue-600 hover:text-blue-800 p-1 rounded hover:bg-blue-50 transition inline-flex items-center gap-1 text-xs font-medium" 
                        title="修改处理人配置"
                      >
                        <Edit size={14} /> 修改
                      </button>

                      {isFirstRowDefault ? (
                        <span 
                          className="text-gray-300 inline-flex items-center gap-0.5 text-xs cursor-not-allowed pl-1 select-none"
                          title="默认处理人是业务域兜底接收人，只能修改不能删除"
                        >
                          <Lock size={12} className="text-gray-300" />
                          不可删除
                        </span>
                      ) : (
                        <button 
                          onClick={() => handleDeleteHandler(item.id)}
                          className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition inline-flex items-center gap-1 text-xs font-medium" 
                          title="删除处理人配置"
                        >
                          <Trash2 size={14} /> 删除
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between items-center mt-3 text-xs text-gray-500 px-2">
          <div>
            【{currentDomain}】共配置 <strong>{currentHandlers.length}</strong> 位系统处理人
          </div>
          <div className="text-gray-400">
            提示：第一行默认处理人只能修改人员与通知方式，不能被删除；新增的处理人支持多选标签并可按需删除。
          </div>
        </div>
      </div>

      {/* 处理人编辑 / 新增模态框 */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black/45 z-[130] flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-[520px] max-w-full overflow-hidden border border-gray-100 animate-in fade-in zoom-in-95 duration-150">
            {/* 模态框头部 */}
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                  <UserCog size={18} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                    {editingHandler?.isDefault 
                      ? `修改【${currentDomain}】默认处理人` 
                      : (editingHandler ? `修改【${currentDomain}】处理人配置` : `新增【${currentDomain}】处理人`)}
                  </h3>
                  <p className="text-[11px] text-gray-500 mt-0.5">
                    仅限选择具备【{currentDomain}】权限的账号人员
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setModalOpen(false)} 
                className="text-gray-400 hover:text-gray-600 text-base p-1 rounded-md hover:bg-gray-200/60"
              >
                ✕
              </button>
            </div>

            {/* 模态框表单 */}
            <div className="p-6 space-y-4 text-xs">
              
              {/* 人员选择 (只能选择有此业务域权限的人员) */}
              <div>
                <label className="font-bold text-gray-700 block mb-1">
                  选择处理人 <span className="text-red-500">*</span>
                  <span className="text-gray-400 font-normal ml-1">
                    (系统已自动过滤，仅展示拥有【{currentDomain}】授权的账号)
                  </span>
                </label>
                <select
                  value={formUserName}
                  onChange={e => setFormUserName(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2 text-xs focus:outline-none focus:border-blue-500 bg-white"
                >
                  {authorizedUsers.map(user => (
                    <option key={user.id} value={user.name}>
                      {user.name} ({user.empId}) - {user.role} [{user.phone}]
                    </option>
                  ))}
                </select>
              </div>

              {/* 标签配置 (若为默认处理人，则固定为全量兜底；否则为多选标签) */}
              {editingHandler?.isDefault ? (
                <div className="bg-amber-50 border border-amber-200 rounded p-3 text-amber-900">
                  <div className="font-bold mb-1 flex items-center gap-1">
                    <ShieldCheck size={14} className="text-amber-600" />
                    默认处理人路由范围：业务域全量兜底
                  </div>
                  <div className="text-[11px] text-amber-700 leading-relaxed">
                    默认处理人无需设置具体标签。当产生未匹配到任何其他指定处理人标签的告警时，均由此人兜底接收。
                  </div>
                </div>
              ) : (
                <div>
                  <label className="font-bold text-gray-700 flex items-center justify-between mb-1.5">
                    <span>关联匹配标签 (多选) <span className="text-red-500">*</span></span>
                    <span className="text-[11px] text-gray-400">已选 {formSelectedTags.length} 个标签</span>
                  </label>
                  
                  {/* 预设多选标签按钮 */}
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {PRESET_TAGS.map(tag => {
                      const isSelected = formSelectedTags.includes(tag);
                      return (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => toggleTagSelection(tag)}
                          className={`px-2.5 py-1 rounded text-xs transition border flex items-center gap-1 ${
                            isSelected 
                              ? 'bg-blue-600 text-white border-blue-600 font-bold' 
                              : 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-gray-100'
                          }`}
                        >
                          {isSelected && <Check size={12} />}
                          {tag}
                        </button>
                      );
                    })}
                  </div>

                  {/* 自定义添加标签 */}
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={customTagInput}
                      onChange={e => setCustomTagInput(e.target.value)}
                      placeholder="输入自定义标签后点击添加..."
                      className="flex-1 border border-gray-300 rounded px-2.5 py-1.5 text-xs focus:outline-none focus:border-blue-500"
                    />
                    <button 
                      type="button"
                      onClick={handleAddCustomTag}
                      className="px-3 py-1.5 border border-gray-300 rounded bg-gray-50 hover:bg-gray-100 text-gray-700"
                    >
                      添加标签
                    </button>
                  </div>
                </div>
              )}

              {/* 钉钉推送作用方式 */}
              <div className="border border-gray-200 rounded-lg p-3 bg-gray-50/60 space-y-2">
                <label className="font-bold text-gray-700 block text-xs">
                  钉钉消息通知生效配置 (核心作用)
                </label>
                <div className="space-y-2 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={formDingtalkAt}
                      onChange={e => setFormDingtalkAt(e.target.checked)}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                    />
                    <span className="text-gray-800">
                      <strong>钉钉群告警卡片 @处理人</strong> (在群消息中高亮提示并提醒认领)
                    </span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={formDingtalkPrivate}
                      onChange={e => setFormDingtalkPrivate(e.target.checked)}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                    />
                    <span className="text-gray-800">
                      <strong>钉钉推送个人工作通知</strong> (通过钉钉企业应用直接推给该处理人单聊)
                    </span>
                  </label>
                </div>
              </div>

              {/* 备注 */}
              {!editingHandler?.isDefault && (
                <div>
                  <label className="font-bold text-gray-700 block mb-1">职责场景备注 (选填)</label>
                  <input 
                    type="text" 
                    value={formNote}
                    onChange={e => setFormNote(e.target.value)}
                    placeholder="如：负责Doris FE主从同步延迟排查..."
                    className="w-full border border-gray-300 rounded px-3 py-1.5 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
              )}
            </div>

            {/* 模态框底部 */}
            <div className="px-6 py-3.5 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
              <button 
                onClick={() => setModalOpen(false)}
                className="px-4 py-1.5 border border-gray-300 rounded text-gray-600 hover:bg-gray-100 text-xs font-medium transition"
              >
                取消
              </button>
              <button 
                onClick={handleSaveHandler}
                className="px-5 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 text-xs font-medium transition shadow-sm flex items-center gap-1.5"
              >
                <Check size={14} /> 保存配置
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
