import React, { useState } from 'react';
import { 
  Tags, Plus, Search, Filter, Edit2, Trash2, CheckCircle2, 
  Layers, Database, Server, Cpu, Shield, AlertTriangle, ArrowRight,
  FolderTree, Info, Sparkles
} from 'lucide-react';

interface TagItem {
  id: string;
  name: string;
  category: 'business' | 'env' | 'tier' | 'infra';
  categoryLabel: string;
  color: string;
  desc: string;
  resourceCount: number;
  bindDomain: string;
  mappingRule: string;
}

const INITIAL_TAGS: TagItem[] = [
  {
    id: 'tag-1',
    name: 'domain:kitchen-iot',
    category: 'business',
    categoryLabel: '业务域标签',
    color: 'bg-blue-100 text-blue-700 border-blue-300',
    desc: '厨房智能物联业务域，包含烟机、灶具、蒸烤箱上报链路',
    resourceCount: 42,
    bindDomain: '智能厨房物联域',
    mappingRule: '按设备上报协议与网关ID自动关联'
  },
  {
    id: 'tag-2',
    name: 'domain:supply-chain',
    category: 'business',
    categoryLabel: '业务域标签',
    color: 'bg-emerald-100 text-emerald-700 border-emerald-300',
    desc: '制造供应链域，覆盖ERP、MES、仓储WMS与调度任务',
    resourceCount: 28,
    bindDomain: '智能制造与供应链域',
    mappingRule: '按主机名前缀 sz-mes-* 与数据库实例名关联'
  },
  {
    id: 'tag-3',
    name: 'domain:marketing-crm',
    category: 'business',
    categoryLabel: '业务域标签',
    color: 'bg-purple-100 text-purple-700 border-purple-300',
    desc: '营销运营与会员域，处理电商订单、会员中心及活动推送',
    resourceCount: 35,
    bindDomain: '全渠道营销域',
    mappingRule: '按API路由前缀 /api/crm/* 与消息队列Topic标记'
  },
  {
    id: 'tag-4',
    name: 'tier:underlying-middleware',
    category: 'tier',
    categoryLabel: '系统层级',
    color: 'bg-amber-100 text-amber-700 border-amber-300',
    desc: '底层看不见的技术中台（Kafka/RocketMQ/Redis集群/微服务注册中心）',
    resourceCount: 19,
    bindDomain: '底层技术中台域',
    mappingRule: '按RPC调用拓扑与链路追踪TraceID自动打标'
  },
  {
    id: 'tag-5',
    name: 'env:production',
    category: 'env',
    categoryLabel: '环境标识',
    color: 'bg-rose-100 text-rose-700 border-rose-300',
    desc: '核心生产环境，告警立即触发钉钉/语音通知',
    resourceCount: 68,
    bindDomain: '全域通用',
    mappingRule: '按CMDB环境字段环境值 prod 匹配'
  },
  {
    id: 'tag-6',
    name: 'infra:bastion-secured',
    category: 'infra',
    categoryLabel: '资产安全',
    color: 'bg-indigo-100 text-indigo-700 border-indigo-300',
    desc: '纳管于堡垒机的高安全等级数据库与执行节点',
    resourceCount: 15,
    bindDomain: '安全管控域',
    mappingRule: '自动同步齐治/Jumpserver堡垒机授权池'
  }
];

export default function TagManagement() {
  const [tags, setTags] = useState<TagItem[]>(INITIAL_TAGS);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'list' | 'mapping'>('list');

  const filteredTags = tags.filter(t => {
    const matchesSearch = t.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          t.desc.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          t.bindDomain.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'all' || t.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="h-full flex flex-col space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-200 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <Tags className="w-5 h-5 text-blue-600" />
            <h1 className="text-[17px] font-bold text-gray-800">标签体系与业务域映射管理</h1>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            支持基于标签的细粒度业务域划分，支持全业务关联与底层技术组件链路自动拓扑打标
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-gray-100 p-0.5 rounded-md flex text-xs">
            <button
              onClick={() => setActiveTab('list')}
              className={`px-3 py-1.5 rounded transition ${activeTab === 'list' ? 'bg-white shadow text-blue-600 font-medium' : 'text-gray-600'}`}
            >
              标签字典列表
            </button>
            <button
              onClick={() => setActiveTab('mapping')}
              className={`px-3 py-1.5 rounded transition ${activeTab === 'mapping' ? 'bg-white shadow text-blue-600 font-medium' : 'text-gray-600'}`}
            >
              业务域与底层逻辑划分方案
            </button>
          </div>

          <button className="flex items-center gap-1.5 bg-blue-600 text-white text-xs px-3.5 py-1.5 rounded-md hover:bg-blue-700 transition">
            <Plus size={14} />
            <span>新建标签</span>
          </button>
        </div>
      </div>

      {activeTab === 'list' ? (
        <>
          {/* Filters */}
          <div className="flex items-center justify-between bg-gray-50 p-3 rounded border border-gray-200 text-xs">
            <div className="flex items-center gap-2">
              <div className="relative w-64">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-gray-400" />
                <input
                  type="text"
                  placeholder="搜索标签名、业务域、描述..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-white border border-gray-300 rounded focus:outline-none focus:border-blue-500 text-xs"
                />
              </div>

              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-white border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none focus:border-blue-500 text-xs text-gray-700"
              >
                <option value="all">全部分类</option>
                <option value="business">业务域标签 (Domain)</option>
                <option value="tier">系统层级 (Tier)</option>
                <option value="env">运行环境 (Env)</option>
                <option value="infra">资产管控 (Infra)</option>
              </select>
            </div>

            <div className="text-gray-500">
              共 <span className="font-semibold text-blue-600">{filteredTags.length}</span> 个标签项
            </div>
          </div>

          {/* Tags Table */}
          <div className="flex-1 overflow-auto border border-gray-200 rounded">
            <table className="w-full text-left text-xs text-gray-700">
              <thead className="bg-gray-100/80 text-gray-600 sticky top-0 border-b border-gray-200 uppercase font-medium">
                <tr>
                  <th className="py-2.5 px-4">标签标识 (Key:Value)</th>
                  <th className="py-2.5 px-3">标签类别</th>
                  <th className="py-2.5 px-3">关联业务域</th>
                  <th className="py-2.5 px-4">底层自动映射逻辑</th>
                  <th className="py-2.5 px-3 text-center">关联监控/资产数</th>
                  <th className="py-2.5 px-4 text-center">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredTags.map((tag) => (
                  <tr key={tag.id} className="hover:bg-blue-50/30 transition">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-mono border ${tag.color}`}>
                          {tag.name}
                        </span>
                      </div>
                      <div className="text-[11px] text-gray-400 mt-1">{tag.desc}</div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="bg-gray-100 text-gray-700 px-2 py-0.5 rounded text-[11px]">
                        {tag.categoryLabel}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-medium text-gray-800">
                      {tag.bindDomain}
                    </td>
                    <td className="py-3 px-4 text-gray-600 font-mono text-[11px]">
                      {tag.mappingRule}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                        {tag.resourceCount}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-2 text-gray-400">
                        <button className="hover:text-blue-600 p-1 rounded hover:bg-gray-100">
                          <Edit2 size={13} />
                        </button>
                        <button className="hover:text-red-600 p-1 rounded hover:bg-gray-100">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        /* Architecture / Mapping view addressing the prompt's question:
           (1)按业务域划分数据
           (2)怎么实现业务域，通过标签划分还是全业务关联业务域？
           (3)看不见的底层业务逻辑怎么划分业务域？
        */
        <div className="flex-1 overflow-auto space-y-4">
          <div className="bg-blue-50 border border-blue-200 p-4 rounded-md">
            <h3 className="text-sm font-bold text-blue-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-600" />
              业务域划分架构方案（标签 + 实体拓扑全业务双模方案）
            </h3>
            <p className="text-xs text-blue-800 mt-1 leading-relaxed">
              针对监控平台业务域划分的痛点，平台采用<strong>“基础数据全业务关联 + 灵活资产多维标签 + 底层隐式链路拓扑推导”</strong>三位一体的设计方案。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border border-gray-200 rounded-md p-4 bg-white shadow-sm flex flex-col justify-between">
              <div>
                <div className="w-8 h-8 rounded bg-blue-100 text-blue-600 flex items-center justify-center mb-2">
                  <Database size={18} />
                </div>
                <h4 className="text-sm font-bold text-gray-800">1. 全业务直接关联 (实体基准)</h4>
                <p className="text-xs text-gray-600 mt-2 leading-relaxed">
                  每个监控任务、采集器节点在创建时<strong>必选主属业务域</strong>（如智能厨房物联域）。
                  保证数据底座具备明确的归属责任人，告警发生时能够精准路由至该域的处理人。
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-gray-100 text-[11px] text-gray-500">
                适用：显式业务系统、微服务API、调度任务
              </div>
            </div>

            <div className="border border-gray-200 rounded-md p-4 bg-white shadow-sm flex flex-col justify-between">
              <div>
                <div className="w-8 h-8 rounded bg-emerald-100 text-emerald-600 flex items-center justify-center mb-2">
                  <Tags size={18} />
                </div>
                <h4 className="text-sm font-bold text-gray-800">2. 标签多维打标 (透视聚合)</h4>
                <p className="text-xs text-gray-600 mt-2 leading-relaxed">
                  业务往往存在交叉（如一个Redis集群为营销与制造共同使用）。
                  通过附加 <code className="bg-gray-100 px-1 py-0.5 rounded text-blue-600">domain:*</code> 标签，支持一个指标或资产隶属于多个业务视角。
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-gray-100 text-[11px] text-gray-500">
                适用：共享数据库、基础中间件、公用采集器
              </div>
            </div>

            <div className="border border-gray-200 rounded-md p-4 bg-white shadow-sm flex flex-col justify-between">
              <div>
                <div className="w-8 h-8 rounded bg-purple-100 text-purple-600 flex items-center justify-center mb-2">
                  <FolderTree size={18} />
                </div>
                <h4 className="text-sm font-bold text-gray-800">3. 看不见的底层逻辑划分</h4>
                <p className="text-xs text-gray-600 mt-2 leading-relaxed">
                  底层存储过程、消息队列中间件、DNS等无法直接人工打标的资产，
                  通过<strong>调用链 Trace 上游服务继承法</strong>与<strong>网络端口/规则匹配引擎</strong>自动推导业务域。
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-gray-100 text-[11px] text-gray-500">
                适用：RPC底层框架、消息总线、无头调度脚本
              </div>
            </div>
          </div>

          {/* Detailed rule matching card */}
          <div className="border border-gray-200 rounded-md p-4 bg-white">
            <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider mb-3">
              底层业务逻辑业务域自动归集规则表 (自动染色机制)
            </h4>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded border border-gray-100">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  <span className="font-mono text-gray-700">规则 01: 上游Trace继承机制</span>
                  <span className="text-gray-400">|</span>
                  <span className="text-gray-600">数据库慢查询无域标识时，提取其最近5分钟Caller微服务业务域进行继承染色</span>
                </div>
                <span className="text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded font-medium text-[11px]">已启用</span>
              </div>

              <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded border border-gray-100">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span className="font-mono text-gray-700">规则 02: 堡垒机授权账号隔离</span>
                  <span className="text-gray-400">|</span>
                  <span className="text-gray-600">执行自动脚本时，若选用「堡垒机导入账号」，自动带入堡垒机绑定的业务分组</span>
                </div>
                <span className="text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded font-medium text-[11px]">已启用</span>
              </div>

              <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded border border-gray-100">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                  <span className="font-mono text-gray-700">规则 03: 兜底通用域分配</span>
                  <span className="text-gray-400">|</span>
                  <span className="text-gray-600">无任何业务关联的底层基础设施指标（如宿主机网卡跑满），默认分流至「底层技术中台域」由平台SRE统管</span>
                </div>
                <span className="text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded font-medium text-[11px]">已启用</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
