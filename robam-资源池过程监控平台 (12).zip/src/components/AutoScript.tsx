import React, { useState } from 'react';
import { 
  Bot, Plus, Play, StopCircle, Edit, Trash2, Database, Terminal, 
  Link, Clock, FileText, CheckCircle2, ChevronRight, ChevronDown, X, ShieldAlert,
  Server, Wifi, Search, AlertCircle, RefreshCw, Filter, Lock, ShieldCheck, Cpu, Zap
} from 'lucide-react';

export default function AutoScript() {
  const [activeTab, setActiveTab] = useState<'scripts' | 'credentials' | 'associations' | 'records'>('scripts');

  // 模拟员工在企业堡垒机中已获得授权开通的服务器与数据库资产
  const BASTION_AUTHORIZED_ASSETS = [
    { id: 'bastion-1', name: '大数据计算节点01 (生产)', type: '服务器', ip: '192.168.1.100', port: '22', account: 'root', defaultMode: '直连服务器 (推荐)' },
    { id: 'bastion-2', name: 'Doris FE 生产节点', type: '服务器', ip: '172.18.11.105', port: '22', account: 'admin', defaultMode: '直连服务器 (推荐)' },
    { id: 'bastion-3', name: 'MySQL订单交易主库 (生产)', type: '数据库', ip: '192.168.2.50', port: '3306', account: 'db_order_rw', dbName: 'order_db', defaultMode: '直连服务器 (推荐)' },
    { id: 'bastion-4', name: '智能制造PLC边缘采集机', type: '服务器', ip: '10.20.4.15', port: '22', account: 'edge_admin', defaultMode: '直连服务器 (推荐)' }
  ];
  
  // Tab 1 Data State
  const [scripts, setScripts] = useState([
    { id: 1, name: '清理 /data 磁盘空间', type: 'shell', creator: '雷秋子', updated: '2026-04-20 10:00:00', content: '#!/bin/bash\n\n# 定义日志目录和保留天数\nLOG_DIR1="/root/logs/rocketmqlogs/"\nLOG_DIR2="/root/logs/csp/"\nDAYS_TO_KEEP=30\n\n# 删除指定目录下超过保留天数的.log文件\nfind "$LOG_DIR1" -name "*.log*" -mtime +$DAYS_TO_KEEP -exec rm -rf {} \\;\n\n# 删除指定目录下超过保留天数的所有文件\nfind "$LOG_DIR2"  -mtime +$DAYS_TO_KEEP -exec rm -rf {} \\;' },
    { id: 2, name: '重启 Doris FE 节点', type: 'shell', creator: '穆工', updated: '2026-04-21 15:30:00', content: '# 重启 \nsystemctl restart doris-fe' },
    { id: 3, name: '杀掉长时间死锁会话', type: 'sql', creator: '章工', updated: '2026-04-18 09:12:00', content: ' -- 语句分隔符为 ;\n -- 删除日志数据\nTRUNCATE TABLE tab_info_log ;\nTRUNCATE TABLE tab_user_log ;' }
  ]);
  const [scriptModal, setScriptModal] = useState<{show: boolean, editing: any}>({show: false, editing: null});
  const [scriptForm, setScriptForm] = useState({ name: '', type: 'shell', content: '' });

  // Tab 1.5 Data State (Credentials) - 支持堡垒机同步与直连/转发模式
  const [credentials, setCredentials] = useState([
    { 
      id: 1, 
      name: '大数据集群节点01', 
      creator: '雷秋子',
      ip: '192.168.1.100', 
      port: '22',
      account: 'root', 
      password: '***', 
      source: '堡垒机授权同步',
      connectMode: '直连服务器 (推荐)',
      bastionAsset: '大数据计算节点01 (生产)',
      updated: '2026-06-12 10:00:00' 
    },
    { 
      id: 2, 
      name: 'Doris FE 生产节点', 
      creator: '穆工',
      ip: '172.18.11.105', 
      port: '22',
      account: 'admin', 
      password: '***', 
      source: '堡垒机授权同步',
      connectMode: '直连服务器 (推荐)',
      bastionAsset: 'Doris FE 生产节点',
      updated: '2026-06-12 10:30:00' 
    },
    { 
      id: 3, 
      name: '生产MySQL订单主库', 
      creator: '陈工',
      ip: '192.168.2.50', 
      port: '3306',
      account: 'db_order_rw', 
      password: '***', 
      source: '堡垒机授权同步',
      connectMode: '直连服务器 (推荐)',
      bastionAsset: 'MySQL订单交易主库 (生产)',
      updated: '2026-06-11 16:20:00' 
    }
  ]);
  const [credModal, setCredModal] = useState<{show: boolean, editing: any}>({show: false, editing: null});
  const [credForm, setCredForm] = useState({ 
    name: '', 
    source: '堡垒机授权同步', // '堡垒机授权同步' | '自定义录入'
    bastionAssetId: '',
    connectMode: '直连服务器 (推荐)', // '直连服务器 (推荐)' | '堡垒机中继代理'
    targetType: '服务器', 
    targetSub: '', 
    port: '22', 
    dbName: '', 
    ip: '', 
    account: '', 
    password: '' 
  });

  // Tab 2 Data State
  const [associations, setAssociations] = useState([
    { 
      id: 1, 
      name: '磁盘空间自愈方案', 
      conditions: '标签:磁盘 & 级别:严重', 
      scripts: ['清理 /data 磁盘空间'], 
      mode: '立即执行', 
      interval: '30分钟', 
      status: true,
      raw: {
          name: '磁盘空间自愈方案', tags: ['磁盘'], level: '严重', monitorId: 'MON-1004',
          scriptId: '清理 /data 磁盘空间', mode: '立即执行 (自动触发)', ip: '127.0.0.1',
          account: 'root', password: '***', interval: '30分钟'
      }
    },
    { 
      id: 2, 
      name: '数据库死锁自动释放', 
      conditions: '标签:数据底座-RDBMS & 级别:全部', 
      scripts: ['杀掉长时间死锁会话'], 
      mode: '手动执行', 
      interval: '5分钟', 
      status: false,
      raw: {
          name: '数据库死锁自动释放', tags: ['数据底座-RDBMS'], level: '全部', monitorId: 'MON-1001',
          scriptId: '杀掉长时间死锁会话', mode: '手动执行 (需人工确认)', ip: '192.168.1.100',
          account: 'admin', password: '***', interval: '5分钟'
      }
    }
  ]);
  const [assocModal, setAssocModal] = useState<{show: boolean, editing: any}>({show: false, editing: null});
  const [assocForm, setAssocForm] = useState({
      name: '', tags: [] as Array<{tag: string, id: string}>, level: '全部', monitorId: '',
      monitorObjects: [] as string[],
      scriptId: '', mode: '立即执行 (自动触发)',
      credentialId: '', interval: '30分钟', status: '启动中'
  });

  const [focusedTagRow, setFocusedTagRow] = useState<number | null>(null);
  const [monitorObjectsDropdownOpen, setMonitorObjectsDropdownOpen] = useState(false);

  const PREDEFINED_TAGS = [
    { tag: 'b1', monitorId: 'd1' },
    { tag: 'b2', monitorId: 'd2' },
    { tag: 'b3', monitorId: 'd3' },
    { tag: 'b4', monitorId: 'd4' },
    { tag: 'b5', monitorId: 'd5' },
    { tag: '数据底座-RDBMS', monitorId: 'MON-1001' },
    { tag: '数据底座-dolphin调度', monitorId: 'MON-1002' },
    { tag: '数据底座-hadoop集群', monitorId: 'MON-1003' },
    { tag: '业务系统-数据库:', monitorId: 'MON-1004' },
    { tag: 'Doris', monitorId: 'MON-1005' },
  ];

  const [testStatus, setTestStatus] = useState<'none' | 'testing' | 'success' | 'fail'>('none');
  const [targetTypeDropdownOpen, setTargetTypeDropdownOpen] = useState(false);
  const [hoveredTargetType, setHoveredTargetType] = useState('服务器');
  const [logModalShow, setLogModalShow] = useState(false);

  // 告警关联测试执行弹窗状态
  const [testExecModal, setTestExecModal] = useState<{
    show: boolean;
    assocName: string;
    scriptName: string;
    targetCred: string;
    running: boolean;
    result: any;
  }>({
    show: false,
    assocName: '',
    scriptName: '',
    targetCred: '',
    running: false,
    result: null
  });

  const handleTestExecution = (assoc: any) => {
    setTestExecModal({
      show: true,
      assocName: assoc.name,
      scriptName: assoc.scripts[0] || '预置自愈脚本',
      targetCred: '大数据集群节点01 (生产凭据)',
      running: true,
      result: null
    });

    setTimeout(() => {
      setTestExecModal(prev => ({
        ...prev,
        running: false,
        result: {
          success: true,
          exitCode: 0,
          output: `[2026-06-12 ${new Date().toLocaleTimeString()}] 触发告警自愈模拟测试 -> [${assoc.name}]\n[AUTH] 校验执行凭证 [大数据集群节点01 (生产凭据)] 成功\n[CONNECT] 直连目标机器 192.168.1.100:22 通畅 (RTT: 2.1ms)\n[RUN] 执行预置指令: ${assoc.scripts.join(' && ')}\n[INFO] 任务执行完成，状态码 0，自愈规则联调成功！`,
          time: new Date().toLocaleString()
        }
      }));
    }, 850);
  };

  const records = [
    { id: 1, scriptName: '清理 /data 磁盘空间', alertName: '[大数据调度-dolphin1] 挂载点：/data...', start: '2026-04-22 10:50:14', end: '2026-04-22 10:50:20', status: 'success', credentialName: '大数据集群节点01 (凭据1)' },
    { id: 2, scriptName: '杀掉长时间死锁会话', alertName: '[业务系统-DB] 检测到行级锁等待超时', start: '2026-04-22 09:15:00', end: '2026-04-22 09:15:05', status: 'success', credentialName: '生产MySQL订单主库 (凭据2)' },
    { id: 3, scriptName: '重启 Doris FE 节点', alertName: 'DORIS_FE_172.18.11.105 节点离线', start: '2026-04-22 07:07:41', end: '2026-04-22 07:08:12', status: 'fail', credentialName: 'Doris FE 生产节点 (凭据3)' },
  ];

  /* ------------------ Script Handlers ------------------ */
  const openScriptModal = (editingObj: any = null) => {
      if (editingObj) {
          setScriptForm({ name: editingObj.name, type: editingObj.type, content: editingObj.content || '' });
      } else {
          setScriptForm({ name: '', type: 'shell', content: '' });
      }
      setScriptModal({ show: true, editing: editingObj });
  };

  const handleSaveScript = () => {
      if (!scriptForm.name.trim()) return;
      const now = new Date().toLocaleString();
      if (scriptModal.editing) {
          setScripts(scripts.map(s => s.id === scriptModal.editing.id ? { ...s, name: scriptForm.name, type: scriptForm.type, content: scriptForm.content, updated: now } : s));
      } else {
          setScripts([...scripts, { id: Date.now(), name: scriptForm.name, type: scriptForm.type, content: scriptForm.content, updated: now }]);
      }
      setScriptModal({ show: false, editing: null });
  };

  const handleDeleteScript = (id: number) => {
      if(window.confirm('确定要删除这个脚本吗？')) {
          setScripts(scripts.filter(s => s.id !== id));
      }
  };

  /* ------------------ Credential Handlers ------------------ */
  const openCredModal = (editingObj: any = null) => {
      if (editingObj) {
          setCredForm({ 
            source: '堡垒机授权同步',
            connectMode: '直连服务器 (推荐)',
            bastionAssetId: '',
            targetType: '服务器', 
            targetSub: '', 
            port: '22', 
            dbName: '', 
            ...editingObj 
          });
      } else {
          setCredForm({ 
            name: '大数据集群节点01 (自动填充)', 
            source: '堡垒机授权同步',
            connectMode: '直连服务器 (推荐)',
            bastionAssetId: 'bastion-1',
            targetType: '服务器', 
            targetSub: '大数据计算节点01 (生产)', 
            port: '22', 
            dbName: '', 
            ip: '192.168.1.100', 
            account: 'root', 
            password: '***' 
          });
      }
      setTestStatus('none');
      setCredModal({ show: true, editing: editingObj });
  };

  const handleSaveCred = () => {
      if (!credForm.name.trim() || !credForm.ip.trim()) return;
      const now = new Date().toLocaleString();
      const newCred = {
        ...credForm,
        password: '***',
        updated: now
      };
      if (credModal.editing) {
          setCredentials(credentials.map(c => c.id === credModal.editing.id ? { ...credModal.editing, ...newCred } : c));
      } else {
          setCredentials([...credentials, { id: Date.now(), ...newCred }]);
      }
      setCredModal({ show: false, editing: null });
  };

  const handleDeleteCred = (id: number) => {
      if(window.confirm('确定要删除这个凭证吗？')) {
          setCredentials(credentials.filter(c => c.id !== id));
      }
  };

  /* ------------------ Association Handlers ------------------ */
  const openAssocModal = (editingObj: any = null) => {
      if (editingObj && editingObj.raw) {
          // Normalize old string tags if any
          const tags = (editingObj.raw.tags || []).length > 0 ? (editingObj.raw.tags || []).map((t: any) => typeof t === 'string' ? {tag: t, id: ''} : t) : [{tag: '', id: ''}];
          setAssocForm({ monitorObjects: [], status: '启动中', ...editingObj.raw, tags });
      } else {
          setAssocForm({
              name: '', tags: [{tag: '', id: ''}], level: '全部', monitorId: '',
              monitorObjects: [],
              scriptId: '', mode: '立即执行 (自动触发)',
              credentialId: '', interval: '30分钟', status: '启动中'
          });
      }
      setTestStatus('none');
      setFocusedTagRow(null);
      setAssocModal({ show: true, editing: editingObj });
  };

  const handleSaveAssoc = () => {
      if (!assocForm.name.trim() || !assocForm.scriptId) return;
      
      const conditionsArray = [];
      const validTags = assocForm.tags.filter(t => t.tag.trim() || t.id.trim());
      if (assocForm.monitorObjects && assocForm.monitorObjects.length > 0) conditionsArray.push(`监控对象:[${assocForm.monitorObjects.join(', ')}]`);
      if (validTags.length > 0) conditionsArray.push(`标签:[${validTags.map(t => `${t.tag}:${t.id}`).join(', ')}]`);
      if (assocForm.level !== '全部') conditionsArray.push(`级别:${assocForm.level}`);
      if (assocForm.monitorId) conditionsArray.push(`ID:${assocForm.monitorId}`);
      if (conditionsArray.length === 0) conditionsArray.push('无');

      const newAssoc = {
          id: assocModal.editing ? assocModal.editing.id : Date.now(),
          name: assocForm.name,
          conditions: conditionsArray.join(' & '),
          scripts: [assocForm.scriptId],
          mode: assocForm.mode.includes('立即') ? '立即执行' : '手动执行',
          interval: assocForm.interval,
          status: assocModal.editing ? assocModal.editing.status : true,
          raw: { ...assocForm }
      };

      if (assocModal.editing) {
          setAssociations(associations.map(a => a.id === assocModal.editing.id ? newAssoc : a));
      } else {
          setAssociations([newAssoc, ...associations]);
      }
      setAssocModal({ show: false, editing: null });
  };



  const handleDeleteAssoc = (id: number) => {
      if(window.confirm('确定要删除这个关联规则吗？')) {
          setAssociations(associations.filter(a => a.id !== id));
      }
  };

  const toggleAssocStatus = (id: number) => {
      setAssociations(associations.map(a => a.id === id ? { ...a, status: !a.status } : a));
  };

  const handleTestConnection = () => {
    if (!credForm.ip || !credForm.account || !credForm.password) {
        alert("请先填写目标IP、账号和密码");
        return;
    }
    setTestStatus('testing');
    setTimeout(() => {
      setTestStatus('success');
    }, 1500);
  };

  return (
    <div className="w-full h-full flex flex-col bg-white">
      {/* 顶部标题与描述 */}
      <div className="px-5 py-4 border-b border-gray-100 bg-[#FAFAFA] shrink-0">
        <div className="flex items-center gap-2 text-gray-800 text-sm font-bold mb-3">
          <Bot size={18} className="text-[#3b82f6]" />
          自动处理脚本
          <span className="text-gray-300 mx-2">|</span>
          <span className="text-gray-500 font-normal text-xs">通过预置 Shell/SQL 脚本，在告警发生时自动或一键触发修复动作</span>
        </div>

        {/* Tabs */}
        <div className="flex gap-6 border-b border-gray-200 mt-4">
          <button 
            onClick={() => setActiveTab('scripts')}
            className={`pb-2 px-1 text-sm font-medium transition-colors border-b-2 ${activeTab === 'scripts' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            自动脚本
          </button>
          <button 
            onClick={() => setActiveTab('credentials')}
            className={`pb-2 px-1 text-sm font-medium transition-colors border-b-2 ${activeTab === 'credentials' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            执行目标凭证
          </button>
          <button 
            onClick={() => setActiveTab('associations')}
            className={`pb-2 px-1 text-sm font-medium transition-colors border-b-2 ${activeTab === 'associations' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            告警关联
          </button>
          <button 
            onClick={() => setActiveTab('records')}
            className={`pb-2 px-1 text-sm font-medium transition-colors border-b-2 ${activeTab === 'records' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            自动执行记录
          </button>
        </div>
      </div>

      {/* Tab 1: 自动脚本 */}
      {activeTab === 'scripts' && (
        <div className="flex-1 overflow-auto bg-white p-4 flex flex-col">
          <div className="flex justify-between items-center mb-4">
            <div className="flex gap-2">
              <button onClick={() => openScriptModal()} className="bg-blue-500 text-white px-3 py-1.5 rounded text-xs font-medium hover:bg-blue-600 transition-colors flex items-center gap-1.5 shadow-sm">
                <Plus size={14} /> 新增脚本
              </button>
            </div>
            <div className="flex items-center border border-gray-200 rounded overflow-hidden h-[30px] w-64 focus-within:border-blue-500 transition-colors">
              <Search size={14} className="text-gray-400 ml-2" />
              <input type="text" placeholder="搜索脚本名称..." className="text-xs px-2 w-full h-full focus:outline-none placeholder:text-gray-400" />
            </div>
          </div>
          {scripts.length === 0 ? (
             <div className="flex-1 flex items-center justify-center text-gray-400 text-sm">暂无脚本数据</div>
          ) : (
          <table className="w-full text-left text-[13px] border-collapse">
            <thead>
              <tr className="border-b border-gray-100 text-gray-500 bg-gray-50/50">
                <th className="py-3 px-4 font-bold text-gray-700">脚本名称</th>
                <th className="py-3 px-4 font-bold text-gray-700">类型</th>
                <th className="py-3 px-4 font-bold text-gray-700">创建人</th>
                <th className="py-3 px-4 font-bold text-gray-700">最后更新</th>
                <th className="py-3 px-4 font-bold text-gray-700 text-right">操作</th>
              </tr>
            </thead>
            <tbody>
              {scripts.map(script => (
                <tr key={script.id} className="border-b border-gray-50 hover:bg-blue-50/30 transition-colors group">
                  <td className="py-3 px-4 font-medium text-gray-800">{script.name}</td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold ${script.type === 'shell' ? 'bg-gray-100 text-gray-700' : 'bg-blue-50 text-blue-700 font-mono'}`}>
                      {script.type === 'shell' ? <Terminal size={12}/> : <Database size={12}/>}
                      {script.type.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-700 font-medium">{script.creator || '雷秋子'}</td>
                  <td className="py-3 px-4 text-gray-500 font-mono text-xs">{script.updated}</td>
                  <td className="py-3 px-4 text-right space-x-2">
                    <button onClick={() => openScriptModal(script)} className="text-blue-500 hover:text-blue-700 p-1 rounded hover:bg-blue-50 transition-colors inline-block" title="修改"><Edit size={16}/></button>
                    <button onClick={() => handleDeleteScript(script.id)} className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition-colors inline-block" title="删除"><Trash2 size={16}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          )}
        </div>
      )}

      {/* Tab 1.5: 执行目标凭证 */}
      {activeTab === 'credentials' && (
        <div className="flex-1 overflow-auto bg-white p-4 flex flex-col">
          <div className="flex justify-between items-center mb-4">
            <div className="flex gap-2">
              <button 
                onClick={() => openCredModal()} 
                className="bg-blue-500 text-white px-3 py-1.5 rounded text-xs font-medium hover:bg-blue-600 transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Plus size={14} /> 新增凭证
              </button>
            </div>
            <div className="flex items-center border border-gray-200 rounded overflow-hidden h-[30px] w-64 focus-within:border-blue-500 transition-colors">
              <Search size={14} className="text-gray-400 ml-2" />
              <input type="text" placeholder="搜索凭证名称或IP..." className="text-xs px-2 w-full h-full focus:outline-none placeholder:text-gray-400" />
            </div>
          </div>
          {credentials.length === 0 ? (
              <div className="flex-1 flex items-center justify-center text-gray-400 text-sm">暂无凭证数据</div>
          ) : (
          <table className="w-full text-left text-[13px] border-collapse">
            <thead>
              <tr className="border-b border-gray-200 text-gray-600 bg-gray-50/70">
                <th className="py-3 px-4 font-bold text-gray-700">凭证名称 / 来源</th>
                <th className="py-3 px-4 font-bold text-gray-700">目标地址 / 端口</th>
                <th className="py-3 px-4 font-bold text-gray-700">执行账号 (KMS密文库)</th>
                <th className="py-3 px-4 font-bold text-gray-700">执行连接方式</th>
                <th className="py-3 px-4 font-bold text-gray-700">创建人</th>
                <th className="py-3 px-4 font-bold text-gray-700">最后更新</th>
                <th className="py-3 px-4 font-bold text-gray-700 text-right pr-6">操作</th>
              </tr>
            </thead>
            <tbody>
              {credentials.map(cred => (
                <tr key={cred.id} className="border-b border-gray-100 hover:bg-blue-50/30 transition-colors group">
                  <td className="py-3 px-4 font-medium text-gray-800">
                    <div className="flex items-center gap-2">
                      <div className="font-bold text-gray-800">{cred.name}</div>
                      <span className={`px-1.5 py-0.2 rounded text-[10px] font-medium border ${
                        cred.source === '堡垒机授权同步' 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                          : 'bg-gray-100 text-gray-600 border-gray-200'
                      }`}>
                        {cred.source || '堡垒机授权同步'}
                      </span>
                    </div>
                    {cred.bastionAsset && cred.bastionAsset !== '-' && (
                      <div className="text-[11px] text-gray-400 mt-0.5">资产: {cred.bastionAsset}</div>
                    )}
                  </td>
                  <td className="py-3 px-4 font-mono text-xs">
                    <span className="text-blue-600 font-bold">{cred.ip}</span>
                    <span className="text-gray-400">:{cred.port || 22}</span>
                  </td>
                  <td className="py-3 px-4 text-xs font-mono">
                    <div className="flex items-center gap-1.5">
                      <Lock size={12} className="text-emerald-600" />
                      <span className="bg-gray-100 px-1.5 py-0.5 rounded text-gray-700 font-bold">{cred.account}</span>
                      <span className="text-gray-400 text-[10px]">(已加密直存)</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-xs">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded font-medium border ${
                      cred.connectMode?.includes('直连') 
                        ? 'bg-blue-50 text-blue-700 border-blue-200' 
                        : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}>
                      <Zap size={11} /> {cred.connectMode || '直连服务器 (推荐)'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-700 font-medium text-xs">{cred.creator || '雷秋子'}</td>
                  <td className="py-3 px-4 text-gray-500 font-mono text-xs">{cred.updated}</td>
                  <td className="py-3 px-4 text-right pr-6 space-x-2">
                    <button onClick={() => openCredModal(cred)} className="text-blue-500 hover:text-blue-700 p-1 rounded hover:bg-blue-50 transition inline-block" title="修改"><Edit size={16}/></button>
                    <button onClick={() => handleDeleteCred(cred.id)} className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition inline-block" title="删除"><Trash2 size={16}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          )}
        </div>
      )}

      {/* Tab 2: 告警关联 */}
      {activeTab === 'associations' && (
        <div className="flex-1 overflow-auto bg-white p-4 flex flex-col relative">
          <div className="flex justify-between items-center mb-4">
            <div className="flex gap-2">
              <button 
                onClick={() => openAssocModal()}
                className="bg-blue-500 text-white px-3 py-1.5 rounded text-xs font-medium hover:bg-blue-600 transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Plus size={14} /> 新增关联
              </button>
            </div>
            <div className="flex items-center border border-gray-200 rounded overflow-hidden h-[30px] w-64 focus-within:border-blue-500 transition-colors">
              <Search size={14} className="text-gray-400 ml-2" />
              <input type="text" placeholder="搜索关联规则..." className="text-xs px-2 w-full h-full focus:outline-none placeholder:text-gray-400" />
            </div>
          </div>
          
          {associations.length === 0 ? (
              <div className="flex-1 flex items-center justify-center text-gray-400 text-sm">暂无关联数据</div>
          ) : (
          <table className="w-full text-left text-[13px] border-collapse">
            <thead>
              <tr className="border-b border-gray-100 text-gray-500 bg-gray-50/50">
                <th className="py-3 px-4 font-bold text-gray-700 w-1/5">规则名称</th>
                <th className="py-3 px-4 font-bold text-gray-700 w-1/5">匹配条件</th>
                <th className="py-3 px-4 font-bold text-gray-700 w-1/4">绑定的脚本</th>
                <th className="py-3 px-4 font-bold text-gray-700 text-center">模式 / 间隔</th>
                <th className="py-3 px-4 font-bold text-gray-700 text-center">状态</th>
                <th className="py-3 px-4 font-bold text-gray-700 text-right pr-6">操作</th>
              </tr>
            </thead>
            <tbody>
              {associations.map(assoc => (
                <tr key={assoc.id} className="border-b border-gray-50 hover:bg-blue-50/30 transition-colors group">
                  <td className="py-4 px-4 font-medium text-gray-800 truncate" title={assoc.name}>{assoc.name}</td>
                  <td className="py-4 px-4 text-xs text-gray-600 bg-gray-50 rounded italic whitespace-pre-wrap">{assoc.conditions.split(' & ').join('\n')}</td>
                  <td className="py-4 px-4 text-xs">
                    <div className="flex flex-col gap-1.5 items-start">
                    {assoc.scripts.map((script, idx) => (
                      <div key={idx} className="flex items-center gap-1 text-blue-600 border border-blue-100 bg-blue-50 px-2 py-0.5 rounded">
                        <FileText size={12} /> {script}
                      </div>
                    ))}
                    </div>
                  </td>
                  <td className="py-4 px-4 text-center">
                    <div className="flex flex-col items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${assoc.mode === '立即执行' ? 'bg-orange-100 text-orange-700 border border-orange-200' : 'bg-gray-100 text-gray-600 border border-gray-200'}`}>
                        {assoc.mode}
                        </span>
                        <span className="text-[11px] text-gray-400 flex items-center gap-1">
                            <Clock size={10}/> {assoc.interval}防抖
                        </span>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-center">
                     <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold border ${assoc.status ? 'bg-green-50 text-green-600 border-green-200' : 'bg-gray-50 text-gray-500 border-gray-200'}`}>
                        {assoc.status ? <span className="w-1.5 h-1.5 rounded-full bg-green-500 mr-1"></span> : null}
                        {assoc.status ? '启用中' : '已停用'}
                     </span>
                  </td>
                  <td className="py-4 px-4 text-right pr-6 space-x-2 whitespace-nowrap">
                    <button 
                      onClick={() => handleTestExecution(assoc)} 
                      className="text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-2 py-1 rounded text-xs transition inline-flex items-center gap-1 font-medium border border-blue-200" 
                      title="仿真测试自愈脚本触发"
                    >
                      <Zap size={13}/> 测试执行
                    </button>
                    <button onClick={() => toggleAssocStatus(assoc.id)} className={`${assoc.status ? 'text-orange-500 hover:text-orange-700 hover:bg-orange-50' : 'text-green-500 hover:text-green-700 hover:bg-green-50'} p-1 rounded transition-colors inline-block`} title={assoc.status ? '停用' : '启用'}>
                      {assoc.status ? <StopCircle size={16}/> : <Play size={16}/>}
                    </button>
                    <button onClick={() => openAssocModal(assoc)} className="text-blue-500 hover:text-blue-700 p-1 rounded hover:bg-blue-50 transition-colors inline-block" title="修改"><Edit size={16}/></button>
                    <button onClick={() => handleDeleteAssoc(assoc.id)} className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition-colors inline-block" title="删除"><Trash2 size={16}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          )}
        </div>
      )}

      {/* Tab 3: 自动执行记录 */}
      {activeTab === 'records' && (
        <div className="flex-1 overflow-auto bg-white p-4 flex flex-col">
          <div className="flex justify-end mb-4">
            <div className="flex gap-2 items-center">
              <select className="border border-gray-200 rounded px-2 h-[30px] text-xs focus:outline-none focus:border-blue-500 bg-white">
                 <option value="">按脚本名称筛选</option>
                 <option value="清理">清理 /data 磁盘空间</option>
                 <option value="死锁">杀掉长时间死锁会话</option>
              </select>
              <select className="border border-gray-200 rounded px-2 h-[30px] text-xs focus:outline-none focus:border-blue-500 bg-white">
                 <option value="">按凭证名称筛选</option>
                 <option value="凭证1">凭证1</option>
                 <option value="凭证2">凭证2</option>
                 <option value="凭证3">凭证3</option>
              </select>
            </div>
          </div>
          <table className="w-full text-left text-[13px] border-collapse mt-2">
            <thead>
              <tr className="border-b border-gray-100 text-gray-500 bg-gray-50/50">
                <th className="py-3 px-4 font-bold text-gray-700 w-1/4">脚本名称</th>
                <th className="py-3 px-4 font-bold text-gray-700">所属凭据</th>
                <th className="py-3 px-4 font-bold text-gray-700">开始时间</th>
                <th className="py-3 px-4 font-bold text-gray-700">结束时间</th>
                <th className="py-3 px-4 font-bold text-gray-700 text-center">执行结果</th>
                <th className="py-3 px-4 font-bold text-gray-700 text-right">操作</th>
              </tr>
            </thead>
            <tbody>
              {records.map(r => (
                <tr key={r.id} className="border-b border-gray-50 hover:bg-blue-50/30 transition-colors">
                  <td className="py-4 px-4 font-medium text-gray-800 flex items-center gap-1.5"><Terminal size={14} className="text-gray-400"/> {r.scriptName}</td>
                  <td className="py-4 px-4 text-gray-700">{r.credentialName}</td>
                  <td className="py-4 px-4 text-gray-500 font-mono text-xs">{r.start}</td>
                  <td className="py-4 px-4 text-gray-500 font-mono text-xs">{r.end}</td>
                  <td className="py-4 px-4 text-center">
                    {r.status === 'success' 
                      ? <span className="text-green-600 bg-green-50 px-2 py-0.5 rounded text-[11px] border border-green-200">成功</span>
                      : <span className="text-red-600 bg-red-50 px-2 py-0.5 rounded text-[11px] border border-red-200">失败</span>
                    }
                  </td>
                  <td className="py-4 px-4 text-right">
                    <button onClick={() => setLogModalShow(true)} className="text-blue-600 hover:underline text-xs font-medium">查看日志</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ===================== Modals ===================== */}

      {/* 日志弹框 */}
      {logModalShow && (
          <div className="fixed inset-0 bg-black/40 z-[60] flex items-center justify-center p-6">
              <div className="bg-white rounded-lg shadow-2xl w-[700px] flex flex-col overflow-hidden">
                  <div className="px-5 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 shrink-0">
                      <h3 className="font-bold text-gray-800 text-sm">执行日志</h3>
                      <button onClick={() => setLogModalShow(false)} className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-200 rounded transition-colors"><X size={16} /></button>
                  </div>
                  <div className="p-4 bg-gray-900 overflow-x-auto">
                      <pre className="text-xs font-mono text-gray-300 whitespace-pre">
{`[2026-05-20 17:39:17] Last login: Wed May 20 17:35:09 2026 from 172.16.72.175

[admin@productpool_tst01 ~]$ cd /data/
[admin@productpool_tst01 data]$ rm -rf access_log.2024-10-14.log
rm: cannot remove ‘access_log.2024-10-14.log’: Permission denied
[admin@productpool_tst01 data]$ ls
access_log.2024-10-13.log  application	arthas-boot.jar  logs	web
access_log.2024-10-14.log  applogs	docker_nginx	 shell	zyc
[admin@productpool_tst01 data]$ 
脚本执行完成`}
                      </pre>
                  </div>
              </div>
          </div>
      )}

      {/* 测试执行仿真结果弹窗 */}
      {testExecModal.show && (
          <div className="fixed inset-0 bg-black/40 z-[60] flex items-center justify-center p-6">
              <div className="bg-white rounded-lg shadow-2xl w-[640px] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-5 py-3.5 border-b border-gray-100 flex justify-between items-center bg-gray-50 shrink-0">
                      <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                        <Zap size={16} className="text-blue-600" />
                        告警自愈规则测试执行
                      </h3>
                      <button onClick={() => setTestExecModal({...testExecModal, show: false})} className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-200 rounded transition-colors"><X size={16} /></button>
                  </div>

                  <div className="p-5 flex flex-col gap-3.5 text-xs">
                      <div className="grid grid-cols-2 gap-3 bg-blue-50/50 p-3 rounded border border-blue-100">
                          <div><span className="text-gray-500">关联规则：</span><strong className="text-gray-800">{testExecModal.assocName}</strong></div>
                          <div><span className="text-gray-500">执行脚本：</span><strong className="text-blue-700">{testExecModal.scriptName}</strong></div>
                          <div><span className="text-gray-500">目标凭据：</span><strong className="text-gray-700">{testExecModal.targetCred}</strong></div>
                          <div>
                            <span className="text-gray-500">执行状态：</span>
                            {testExecModal.running ? (
                              <span className="text-amber-600 font-bold inline-flex items-center gap-1">
                                <RefreshCw size={12} className="animate-spin" /> 正在下发测试指令...
                              </span>
                            ) : (
                              <span className="text-green-600 font-bold inline-flex items-center gap-1">
                                <CheckCircle2 size={12} /> 测试成功 (返回码: 0)
                              </span>
                            )}
                          </div>
                      </div>

                      <div>
                        <div className="font-bold text-gray-700 mb-1.5 flex justify-between items-center">
                          <span>实时直连终端日志输出：</span>
                          {testExecModal.result && <span className="font-mono text-gray-400 font-normal">{testExecModal.result.time}</span>}
                        </div>
                        <div className="bg-gray-950 p-3.5 rounded border border-gray-800 font-mono text-[11px] text-emerald-400 min-h-[140px] whitespace-pre-wrap leading-relaxed overflow-x-auto">
                          {testExecModal.running ? (
                            <div className="text-gray-400 flex items-center gap-2 py-4 justify-center">
                              <RefreshCw size={14} className="animate-spin text-blue-400" /> 正在通过内网专线直连服务器建立执行通道...
                            </div>
                          ) : (
                            testExecModal.result?.output
                          )}
                        </div>
                      </div>
                  </div>

                  <div className="px-5 py-3 border-t border-gray-200 bg-gray-50 flex justify-end gap-2.5 shrink-0">
                    <button 
                      onClick={() => setTestExecModal({...testExecModal, show: false})} 
                      className="px-4 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 text-xs font-medium"
                    >
                      完成测试
                    </button>
                  </div>
              </div>
          </div>
      )}

      {/* 新增/修改脚本 模态框 */}
      {scriptModal.show && (
          <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center">
            <div className="bg-white rounded-lg shadow-xl w-[900px] flex flex-col overflow-hidden max-h-[90vh]">
              <div className="px-5 py-3 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                 <h3 className="font-bold text-gray-800">{scriptModal.editing ? '修改脚本' : '新建脚本'}</h3>
                 <button onClick={() => setScriptModal({show: false, editing: null})} className="text-gray-400 hover:text-gray-600"><X size={18} /></button>
              </div>
              <div className="flex overflow-hidden h-[500px]">
                  {/* 左侧：脚本表单 */}
                  <div className="w-1/2 flex flex-col p-6 gap-4 border-r border-gray-100 overflow-y-auto">
                      <div className="flex flex-col gap-1.5">
                          <label className="font-bold text-gray-700 text-[13px]">脚本名称 <span className="text-red-500">*</span></label>
                          <input 
                            type="text" value={scriptForm.name} 
                            onChange={(e) => setScriptForm({...scriptForm, name: e.target.value})}
                            placeholder="如：清理临时文件" 
                            className="border border-gray-300 rounded px-3 py-2 text-[13px] focus:outline-none focus:border-blue-500" 
                          />
                      </div>
                      <div className="flex flex-col gap-1.5">
                          <label className="font-bold text-gray-700 text-[13px]">脚本类型</label>
                          <div className="flex gap-4 mt-1 text-[13px]">
                              <label className="flex items-center gap-1.5 cursor-pointer">
                                  <input type="radio" checked={scriptForm.type === 'shell'} onChange={() => setScriptForm({...scriptForm, type: 'shell'})} /> Shell
                              </label>
                              <label className="flex items-center gap-1.5 cursor-pointer">
                                  <input type="radio" checked={scriptForm.type === 'sql'} onChange={() => setScriptForm({...scriptForm, type: 'sql'})} /> SQL
                              </label>
                          </div>
                      </div>
                      <div className="flex flex-col gap-1.5 flex-1">
                          <label className="font-bold text-gray-700 text-[13px]">脚本语句 <span className="text-red-500">*</span></label>
                          <textarea 
                              value={scriptForm.content}
                              onChange={(e) => setScriptForm({...scriptForm, content: e.target.value})}
                              placeholder={scriptForm.type === 'shell' ? '#!/bin/bash\n...' : 'SELECT * FROM ...'}
                              className="border border-gray-300 rounded px-3 py-2 text-[13px] font-mono focus:outline-none focus:border-blue-500 flex-1 resize-none"
                          ></textarea>
                      </div>
                  </div>
                  
                  {/* 右侧：示例 */}
                  <div className="w-1/2 flex flex-col p-6 bg-gray-50 overflow-y-auto">
                      <div className="font-bold text-gray-700 text-[13px] mb-3 flex items-center gap-1.5 text-blue-700">
                         <FileText size={14} /> 
                         {scriptForm.type === 'shell' ? 'Shell 脚本示例' : 'SQL 语句示例'}
                      </div>
                      <div className="flex-1 bg-[#1e1e1e] rounded text-gray-300 p-4 text-xs font-mono overflow-auto whitespace-pre">
{scriptForm.type === 'shell' ? `#!/bin/bash

# 定义日志目录和保留天数
LOG_DIR1="/root/logs/rocketmqlogs/"
LOG_DIR2="/root/logs/csp/"
DAYS_TO_KEEP=30

# 删除指定目录下超过保留天数的.log文件
find "$LOG_DIR1" -name "*.log*" -mtime +$DAYS_TO_KEEP -exec rm -rf {} \\;

# 删除指定目录下超过保留天数的所有文件
find "$LOG_DIR2"  -mtime +$DAYS_TO_KEEP -exec rm -rf {} \\;` : `-- 语句分隔符为 ;
-- 删除日志数据
TRUNCATE TABLE tab_info_log ;
TRUNCATE TABLE tab_user_log ;`}
                      </div>
                  </div>
              </div>
              <div className="px-5 py-4 border-t border-gray-200 bg-gray-50 flex justify-end gap-3 shrink-0">
                  <button onClick={() => setScriptModal({show: false, editing: null})} className="px-4 py-1.5 text-gray-600 text-[13px] font-medium hover:bg-gray-200 rounded">取消</button>
                  <button onClick={handleSaveScript} disabled={!scriptForm.name.trim() || !scriptForm.content.trim()} className="px-5 py-1.5 bg-blue-600 text-white text-[13px] font-medium rounded hover:bg-blue-700 disabled:opacity-50 transition-colors">保存脚本</button>
              </div>
            </div>
          </div>
      )}

      {/* 新增/修改凭证 模态框 */}
      {credModal.show && (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center">
            <div className="bg-white rounded-lg shadow-xl w-[560px] flex flex-col overflow-hidden max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
              <div className="px-5 py-3.5 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                 <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                    <Lock size={16} className="text-blue-600" />
                    {credModal.editing ? '修改执行目标凭证' : '新建执行目标凭证'}
                 </h3>
                 <button onClick={() => setCredModal({show: false, editing: null})} className="text-gray-400 hover:text-gray-600"><X size={18} /></button>
              </div>

              <div className="flex flex-col p-5 gap-3.5 overflow-y-auto text-[13px]">
                  
                  {/* 凭证来源选择 */}
                  <div>
                    <label className="font-bold text-gray-700 block mb-1.5">凭证来源配置方式 <span className="text-red-500">*</span></label>
                    <div className="grid grid-cols-2 gap-2.5">
                      <button 
                        type="button"
                        onClick={() => {
                          const asset = BASTION_AUTHORIZED_ASSETS[0];
                          setCredForm({
                            ...credForm,
                            source: '堡垒机授权同步',
                            bastionAssetId: asset.id,
                            name: `${asset.name} (堡垒机已开通)`,
                            targetType: asset.type,
                            ip: asset.ip,
                            port: asset.port,
                            account: asset.account,
                            dbName: asset.dbName || '',
                            connectMode: '直连服务器 (推荐)'
                          });
                        }}
                        className={`p-2.5 rounded-lg border text-left transition ${
                          credForm.source === '堡垒机授权同步'
                            ? 'border-blue-500 bg-blue-50/60 ring-1 ring-blue-500'
                            : 'border-gray-200 hover:border-gray-300 bg-white'
                        }`}
                      >
                        <div className="font-bold text-gray-800 text-xs flex items-center gap-1.5">
                          <ShieldCheck size={14} className="text-emerald-600" />
                          从堡垒机已开通资产导入 (推荐)
                        </div>
                      </button>

                      <button 
                        type="button"
                        onClick={() => {
                          setCredForm({
                            ...credForm,
                            source: '自定义连接',
                            bastionAssetId: '',
                            name: '',
                            ip: '',
                            port: '22',
                            account: '',
                            password: ''
                          });
                        }}
                        className={`p-2.5 rounded-lg border text-left transition ${
                          credForm.source === '自定义连接'
                            ? 'border-blue-500 bg-blue-50/60 ring-1 ring-blue-500'
                            : 'border-gray-200 hover:border-gray-300 bg-white'
                        }`}
                      >
                        <div className="font-bold text-gray-800 text-xs flex items-center gap-1.5">
                          <Terminal size={14} className="text-blue-600" />
                          自定义手动连接录入
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* 堡垒机资产选取 */}
                  {credForm.source === '堡垒机授权同步' && (
                    <div className="bg-emerald-50/50 border border-emerald-200 rounded-lg p-3 space-y-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-emerald-900 flex items-center gap-1">
                          <CheckCircle2 size={13} className="text-emerald-600" />
                          选择您在堡垒机已授权的账号配置：
                        </span>
                        <span className="text-[11px] text-emerald-700">当前员工: 雷秋子(250992)</span>
                      </div>
                      
                      <select 
                        value={credForm.bastionAssetId} 
                        onChange={(e) => {
                          const asset = BASTION_AUTHORIZED_ASSETS.find(a => a.id === e.target.value);
                          if (asset) {
                            setCredForm({
                              ...credForm,
                              bastionAssetId: asset.id,
                              name: `${asset.name} (已授权)`,
                              targetType: asset.type,
                              ip: asset.ip,
                              port: asset.port,
                              account: asset.account,
                              dbName: asset.dbName || '',
                              password: '***'
                            });
                          }
                        }}
                        className="w-full border border-emerald-300 rounded px-3 py-1.5 text-xs bg-white focus:outline-none focus:border-emerald-500 font-mono"
                      >
                        {BASTION_AUTHORIZED_ASSETS.map(asset => (
                          <option key={asset.id} value={asset.id}>
                            [{asset.type}] {asset.name} - {asset.ip}:{asset.port} (账号: {asset.account})
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div className="flex flex-col gap-1">
                      <label className="font-bold text-gray-700">凭证名称 <span className="text-red-500">*</span></label>
                      <input 
                        type="text" value={credForm.name} 
                        onChange={(e) => setCredForm({...credForm, name: e.target.value})}
                        placeholder="如：大数据集群节点01" 
                        className="border border-gray-300 rounded px-3 py-1.5 focus:outline-none focus:border-blue-500" 
                      />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                      <div className="flex flex-col gap-1">
                          <label className="font-bold text-gray-700">
                            目标 IP / 数据源地址 <span className="text-red-500">*</span>
                            {credForm.source === '堡垒机授权同步' && <span className="text-gray-400 font-normal text-[11px] ml-1">(堡垒机已锁定)</span>}
                          </label>
                          <input 
                            type="text" value={credForm.ip} 
                            disabled={credForm.source === '堡垒机授权同步'}
                            onChange={(e) => setCredForm({...credForm, ip: e.target.value})}
                            placeholder="如：192.168.1.100" 
                            className={`border rounded px-3 py-1.5 font-mono focus:outline-none ${
                              credForm.source === '堡垒机授权同步' 
                                ? 'bg-gray-100 text-gray-500 cursor-not-allowed border-gray-200' 
                                : 'border-gray-300 focus:border-blue-500'
                            }`} 
                          />
                      </div>
                      <div className="flex flex-col gap-1">
                          <label className="font-bold text-gray-700">
                            端口 <span className="text-red-500">*</span>
                            {credForm.source === '堡垒机授权同步' && <span className="text-gray-400 font-normal text-[11px] ml-1">(堡垒机已锁定)</span>}
                          </label>
                          <input 
                            type="text" value={credForm.port} 
                            disabled={credForm.source === '堡垒机授权同步'}
                            onChange={(e) => setCredForm({...credForm, port: e.target.value})}
                            placeholder="如：22 或 3306" 
                            className={`border rounded px-3 py-1.5 font-mono focus:outline-none ${
                              credForm.source === '堡垒机授权同步' 
                                ? 'bg-gray-100 text-gray-500 cursor-not-allowed border-gray-200' 
                                : 'border-gray-300 focus:border-blue-500'
                            }`} 
                          />
                      </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                      <div className="flex flex-col gap-1">
                          <label className="font-bold text-gray-700">
                            执行账号 <span className="text-red-500">*</span>
                            {credForm.source === '堡垒机授权同步' && <span className="text-gray-400 font-normal text-[11px] ml-1">(堡垒机已锁定)</span>}
                          </label>
                          <input 
                            type="text" value={credForm.account} 
                            disabled={credForm.source === '堡垒机授权同步'}
                            onChange={e => setCredForm({...credForm, account: e.target.value})} 
                            placeholder="例如：root" 
                            className={`border rounded px-3 py-1.5 font-mono focus:outline-none ${
                              credForm.source === '堡垒机授权同步' 
                                ? 'bg-gray-100 text-gray-500 cursor-not-allowed border-gray-200' 
                                : 'border-gray-300 focus:border-blue-500'
                            }`} 
                          />
                      </div>
                      {/* 堡垒机授权账号免密直连，删除执行密码 */}
                      {credForm.source !== '堡垒机授权同步' && (
                        <div className="flex flex-col gap-1">
                            <label className="font-bold text-gray-700">执行密码 / 密钥 (KMS加密存储)</label>
                            <input type="password" value={credForm.password} onChange={e => setCredForm({...credForm, password: e.target.value})} placeholder="••••••••" className="border border-gray-300 rounded px-3 py-1.5 font-mono focus:outline-none focus:border-blue-500" />
                        </div>
                      )}
                  </div>
                  
                  <div className="border-t border-gray-100 mt-1 pt-3 flex justify-between items-center">
                    <button 
                      type="button"
                      onClick={handleTestConnection}
                      disabled={testStatus === 'testing'}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs transition-all border
                        ${testStatus === 'none' ? 'bg-white border-blue-500 text-blue-600 hover:bg-blue-50' : ''}
                        ${testStatus === 'testing' ? 'bg-gray-100 border-gray-300 text-gray-500 cursor-not-allowed opacity-80' : ''}
                        ${testStatus === 'success' ? 'bg-green-50 border-green-500 text-green-600' : ''}
                      `}
                    >
                      {testStatus === 'none' && <><Wifi size={14}/> 直连连通性测试</>}
                      {testStatus === 'testing' && <><RefreshCw size={14} className="animate-spin" /> 直连握手探测中...</>}
                      {testStatus === 'success' && <><CheckCircle2 size={14} /> 直连成功 (延迟 2ms)</>}
                    </button>
                    {testStatus === 'success' && <div className="text-[11px] text-green-600 font-medium">直连目标服务器验证通过，免堡垒机转发</div>}
                  </div>

              </div>
              <div className="px-5 py-3 border-t border-gray-200 bg-gray-50 flex justify-end gap-2.5 shrink-0">
                  <button onClick={() => setCredModal({show: false, editing: null})} className="px-3.5 py-1.5 text-gray-600 text-xs hover:bg-gray-200 rounded">取消</button>
                  <button onClick={handleSaveCred} disabled={!credForm.name.trim() || !credForm.ip.trim()} className="px-4 py-1.5 bg-blue-600 text-white text-xs font-medium rounded hover:bg-blue-700 disabled:opacity-50 transition-colors">保存凭证</button>
              </div>
            </div>
          </div>
      )}

      {/* 新增/修改关联 模态框 */}
      {assocModal.show && (
        <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center">
           <div className="bg-white rounded-lg shadow-xl w-[600px] flex flex-col overflow-hidden max-h-[90vh]">
              {/* Header */}
              <div className="px-5 py-3 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                 <h3 className="font-bold text-gray-800 flex items-center gap-2">
                    <Link size={16} className="text-blue-500" /> {assocModal.editing ? '修改告警关联规则' : '新建告警关联规则'}
                 </h3>
                 <button onClick={() => setAssocModal({show: false, editing: null})} className="text-gray-400 hover:text-gray-600">
                    <X size={18} />
                 </button>
              </div>

              {/* Form Body */}
              <div className="p-6 overflow-y-auto flex flex-col gap-5 text-[13px]">
                  
                  {/* 基础配置 */}
                  <div className="flex flex-col gap-1.5">
                      <label className="font-bold text-gray-700">规则名称 <span className="text-red-500">*</span></label>
                      <input 
                        type="text" placeholder="例如：磁盘告警清理规则" 
                        value={assocForm.name} onChange={e => setAssocForm({...assocForm, name: e.target.value})}
                        className="border border-gray-300 rounded px-3 py-2 w-full focus:outline-none focus:border-blue-500" 
                      />
                  </div>

                  {/* 匹配条件 */}
                  <div className="flex flex-col bg-blue-50/50 p-4 rounded border border-blue-100 gap-3">
                      <div className="font-bold text-blue-800 flex items-center gap-1.5 border-b border-blue-100 pb-2"><Filter size={14}/> 告警匹配条件</div>
                      <div className="grid grid-cols-2 gap-4">
                          <div className="flex flex-col gap-1.5 col-span-2 relative">
                              <label className="text-gray-600 text-xs">监控对象</label>
                              <div 
                                  className="border border-gray-300 rounded px-2.5 py-1.5 min-h-[34px] flex flex-wrap gap-1.5 items-center cursor-pointer bg-white relative"
                                  onClick={() => setMonitorObjectsDropdownOpen(!monitorObjectsDropdownOpen)}
                              >
                                  {(assocForm.monitorObjects || []).length === 0 ? (
                                      <span className="text-gray-400 text-xs">请选择监控对象...</span>
                                  ) : (
                                      (assocForm.monitorObjects || []).map(obj => (
                                          <span key={obj} className="flex items-center gap-1 px-1.5 py-0.5 bg-blue-50 border border-blue-100 rounded text-xs text-blue-700">
                                              {obj}
                                              <button 
                                                  onClick={(e) => {
                                                      e.stopPropagation();
                                                      setAssocForm({...assocForm, monitorObjects: assocForm.monitorObjects.filter(o => o !== obj)});
                                                  }} 
                                                  className="hover:text-red-500 font-bold"
                                              >
                                                  <X size={10} />
                                              </button>
                                          </span>
                                      ))
                                  )}
                              </div>
                              {monitorObjectsDropdownOpen && (
                                  <div className="absolute top-full left-0 w-full mt-1 bg-white border border-gray-200 shadow-xl z-50 rounded overflow-hidden" onMouseLeave={() => setMonitorObjectsDropdownOpen(false)}>
                                      {['xx1', 'xx2', 'xx3', 'xx4'].map(option => (
                                          <div 
                                              key={option} 
                                              className="px-3 py-2 text-xs hover:bg-blue-50 cursor-pointer flex items-center justify-between"
                                              onClick={() => {
                                                  const current = assocForm.monitorObjects || [];
                                                  if (current.includes(option)) {
                                                      setAssocForm({...assocForm, monitorObjects: current.filter(o => o !== option)});
                                                  } else {
                                                      setAssocForm({...assocForm, monitorObjects: [...current, option]});
                                                  }
                                              }}
                                          >
                                              <span className="text-gray-800">{option}</span>
                                              {(assocForm.monitorObjects || []).includes(option) && <CheckCircle2 size={14} className="text-blue-500" />}
                                          </div>
                                      ))}
                                  </div>
                              )}
                          </div>
                      
                          <div className="flex flex-col gap-1.5 col-span-2">
                              <label className="text-gray-600 text-xs">绑定标签 (如：alertname / defineid 等)</label>
                              
                              <div className="flex flex-col gap-2 relative">
                                  {assocForm.tags.map((t, idx) => (
                                      <div key={idx} className="flex items-center gap-2 relative">
                                          <input 
                                              type="text" 
                                              placeholder="标签名 (如 111)" 
                                              value={t.tag} 
                                              onChange={e => {
                                                  const newTags = [...assocForm.tags];
                                                  newTags[idx].tag = e.target.value;
                                                  setAssocForm({...assocForm, tags: newTags});
                                              }} 
                                              onFocus={() => setFocusedTagRow(idx)}
                                              onBlur={() => setTimeout(() => setFocusedTagRow(null), 200)}
                                              className="border border-gray-300 rounded px-2 py-1.5 text-xs focus:outline-none focus:border-blue-500 bg-white w-[180px]" 
                                          />
                                          <span className="text-gray-500">:</span>
                                          <input 
                                              type="text" 
                                              placeholder="ID / 内容" 
                                              value={t.id} 
                                              onChange={e => {
                                                  const newTags = [...assocForm.tags];
                                                  newTags[idx].id = e.target.value;
                                                  setAssocForm({...assocForm, tags: newTags});
                                              }} 
                                              className="border border-gray-300 rounded px-2 py-1.5 text-xs focus:outline-none focus:border-blue-500 bg-white flex-1" 
                                          />
                                          
                                          {focusedTagRow === idx && t.tag && (
                                              <div className="absolute top-[100%] left-0 w-full mt-1 bg-white border border-gray-200 shadow-xl z-50 rounded max-h-40 overflow-y-auto">
                                                  {[
                                                      {tag: '111', id: 'aaa'}, {tag: '222', id: 'bbb'}, {tag: '333', id: 'ddd'}, {tag: '123', id: 'eddds'}
                                                  ].filter(m => m.tag.includes(t.tag) || (t.id && m.id.includes(t.id))).map((m, mIdx) => (
                                                      <div 
                                                          key={mIdx} 
                                                          className="px-3 py-2 text-xs hover:bg-blue-50 cursor-pointer flex justify-between"
                                                          onClick={() => {
                                                              const newTags = [...assocForm.tags];
                                                              newTags[idx] = { tag: m.tag, id: m.id };
                                                              setAssocForm({...assocForm, tags: newTags});
                                                          }}
                                                      >
                                                          <span className="font-medium text-gray-800">{m.tag}</span>
                                                          <span className="text-gray-400 font-mono">{m.id}</span>
                                                      </div>
                                                  ))}
                                              </div>
                                          )}

                                          <div className="flex items-center gap-1 w-[60px]">
                                              {assocForm.tags.length > 1 && (
                                              <button 
                                                  onClick={() => setAssocForm({...assocForm, tags: assocForm.tags.filter((_, i) => i !== idx)})} 
                                                  className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                                              >
                                                  <X size={14} />
                                              </button>
                                              )}
                                              {idx === assocForm.tags.length - 1 && (
                                              <button 
                                                  onClick={() => setAssocForm({...assocForm, tags: [...assocForm.tags, {tag: '', id: ''}]})} 
                                                  className="p-1.5 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white rounded transition-colors"
                                              >
                                                  <Plus size={14} />
                                              </button>
                                              )}
                                          </div>
                                      </div>
                                  ))}
                              </div>
                          </div>
                          <div className="flex flex-col gap-1.5">
                              <label className="text-gray-600 text-xs">告警级别</label>
                              <select value={assocForm.level} onChange={e => setAssocForm({...assocForm, level: e.target.value})} className="border border-gray-200 rounded px-2.5 py-1.5 focus:outline-none focus:border-blue-500 bg-white">
                                <option value="全部">全部</option>
                                <option value="警告">警告</option>
                                <option value="严重">严重</option>
                                <option value="紧急">紧急</option>
                              </select>
                          </div>
                      </div>
                  </div>

                  {/* 执行设置 */}
                  <div className="grid grid-cols-2 gap-4 border-t border-gray-100 pt-5">
                      <div className="flex flex-col gap-1.5">
                          <label className="font-bold text-gray-700">关联自动脚本 <span className="text-red-500">*</span></label>
                          <select 
                            value={assocForm.scriptId} 
                            onChange={e => setAssocForm({...assocForm, scriptId: e.target.value})} 
                            className="border border-gray-300 rounded px-3 py-2 w-full focus:outline-none focus:border-blue-500 bg-white"
                          >
                              <option value="">- 请选择脚本 -</option>
                              {scripts.map(s => (
                                  <option key={s.id} value={s.name}>{s.name} ({s.type})</option>
                              ))}
                          </select>
                      </div>
                      <div className="flex flex-col gap-1.5">
                          <label className="font-bold text-gray-700">执行模式</label>
                          <select value={assocForm.mode} onChange={e => setAssocForm({...assocForm, mode: e.target.value})} className="border border-gray-300 rounded px-3 py-2 w-full focus:outline-none focus:border-blue-500 bg-white">
                            <option>立即执行 (自动触发)</option>
                            <option>手动执行 (需人工确认)</option>
                          </select>
                      </div>
                  </div>

                  {/* 执行凭证与环境 */}
                  <div className="flex flex-col border border-gray-200 p-4 rounded gap-3 bg-gray-50/50">
                      <div className="font-bold text-gray-700 flex items-center gap-1.5 border-b border-gray-200 pb-2"><Server size={14}/> 目标凭证匹配</div>
                      <div className="flex flex-col gap-1.5">
                          <label className="text-gray-600 text-xs">选择执行目标凭证</label>
                          <select 
                            value={assocForm.credentialId} 
                            onChange={e => setAssocForm({...assocForm, credentialId: e.target.value})} 
                            className="border border-gray-300 rounded px-2.5 py-1.5 w-full focus:outline-none focus:border-blue-500 bg-white"
                          >
                              <option value="">- 请选择目标凭证 -</option>
                              {credentials.map(c => (
                                  <option key={c.id} value={c.id.toString()}>{c.name} ({c.ip})</option>
                              ))}
                          </select>
                      </div>
                  </div>

                  {/* 最短执行间隔 */}
                  <div className="flex flex-col gap-1.5">
                      <label className="font-bold text-gray-700 text-[13px] flex items-center gap-1"><AlertCircle size={14} className="text-orange-500"/> 最短执行间隔</label>
                      <select value={assocForm.interval} onChange={e => setAssocForm({...assocForm, interval: e.target.value})} className="border border-gray-300 rounded px-3 py-2 w-full focus:outline-none focus:border-blue-500 bg-white">
                        <option>5分钟</option>
                        <option>30分钟</option>
                        <option>1小时</option>
                        <option>24小时</option>
                      </select>
                  </div>

                  {/* 状态 */}
                  <div className="flex flex-col gap-1.5">
                      <label className="font-bold text-gray-700 text-[13px]">状态</label>
                      <select value={assocForm.status} onChange={e => setAssocForm({...assocForm, status: e.target.value})} className="border border-gray-300 rounded px-3 py-2 w-full focus:outline-none focus:border-blue-500 bg-white">
                        <option value="启动中">启动中</option>
                        <option value="启用">启用</option>
                        <option value="停用">停用</option>
                      </select>
                  </div>

              </div>

              {/* Footer */}
              <div className="px-5 py-4 border-t border-gray-200 bg-gray-50 flex justify-end gap-3 shrink-0">
                  <button onClick={() => setAssocModal({show: false, editing: null})} className="px-4 py-1.5 rounded text-gray-600 text-sm font-medium hover:bg-gray-200 transition-colors">
                     取消
                  </button>
                  <button onClick={handleSaveAssoc} disabled={!assocForm.name.trim() || !assocForm.scriptId} className="px-5 py-1.5 rounded bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 shadow-sm transition-colors disabled:opacity-50 cursor-pointer">
                     保存关联
                  </button>
              </div>
           </div>
        </div>
      )}

    </div>
  );
}
