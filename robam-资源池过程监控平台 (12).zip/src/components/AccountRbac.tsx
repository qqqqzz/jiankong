import React, { useState } from 'react';
import { 
  Users, Shield, KeyRound, Lock, Plus, Edit, Trash2, 
  Search, CheckCircle2, AlertTriangle, AlertCircle, ShieldAlert,
  UserCheck, Eye, EyeOff, Layers, Check, X, ShieldCheck,
  Database, User, ShieldCheck as AdminShield, CheckSquare, Square,
  Settings2, Bot, Megaphone, Terminal, FileText, Monitor, Gauge,
  LayoutDashboard, BellDot, Filter, MessageSquare, Briefcase, ChevronRight
} from 'lucide-react';

interface Employee {
  empId: string;
  name: string;
  phone: string;
  email: string;
  roleSuggestion: string;
}

interface UserAccount {
  id: number;
  empId: string;
  username: string;
  password: string;
  name: string;
  role: string;
  domains: string[];
  phone: string;
  email: string;
  status: '正常' | '锁定' | '禁用';
  passwordValidity: string; // 固定为 30天
  source: string;
}

interface DomainItem {
  id: string;
  name: string;
  leaders: string[];
  defaultHandler: string;
  desc: string;
}

// 细分子Tab定义
interface SubTabDef {
  id: string;
  name: string;
  desc?: string;
}

// 菜单权限定义：已存在的页面才展示，有子Tab的具体到Tab
interface MenuDef {
  id: string;
  name: string;
  icon: React.ElementType;
  isSinglePage?: boolean;
  isDomainScoped?: boolean; // 是否属于按业务域划分的模块 (共11个核心业务模块)
  desc?: string;
  tabs?: SubTabDef[];
}

export default function AccountRbac() {
  const [activeTab, setActiveTab] = useState<'users' | 'permissions' | 'domains'>('users');

  /* ------------------- 员工池底座 ------------------- */
  const EMPLOYEE_POOL: Employee[] = [
    { empId: '250992', name: '雷秋子', phone: '13800138001', email: 'leiqz@robam.com', roleSuggestion: '超级管理员' },
    { empId: '250993', name: '穆工', phone: '13900139002', email: 'mug@robam.com', roleSuggestion: '调度平台负责人' },
    { empId: '250995', name: '赵工', phone: '13711114444', email: 'zhaog@robam.com', roleSuggestion: '调度平台运维工程师' },
    { empId: '250994', name: '章工', phone: '13811112222', email: 'zhangg@robam.com', roleSuggestion: '资源池平台负责人' },
    { empId: '250996', name: '李工', phone: '13611115555', email: 'lig@robam.com', roleSuggestion: '资源池平台运维工程师' },
    { empId: '250997', name: '陈工', phone: '13511116666', email: 'cheng@robam.com', roleSuggestion: '运维平台负责人' },
    { empId: '250998', name: '王工', phone: '13411117777', email: 'wangg@robam.com', roleSuggestion: '运维平台告警处理人' },
  ];

  /* ------------------- 业务域列表 (调度平台、资源池平台、运维平台) ------------------- */
  const [domains, setDomains] = useState<DomainItem[]>([
    {
      id: 'domain-scheduler',
      name: '调度平台',
      leaders: ['穆工', '赵工'],
      defaultHandler: '穆工',
      desc: '负责DolphinScheduler调度集群、DAG任务流水线编排、大数据离线与实时作业监控'
    },
    {
      id: 'domain-resource',
      name: '资源池平台',
      leaders: ['章工', '李工'],
      defaultHandler: '章工',
      desc: '负责物理母机集群、K8s生产容器资源池、网络计算节点与硬件基础设施全量纳管'
    },
    {
      id: 'domain-ops',
      name: '运维平台',
      leaders: ['陈工', '王工'],
      defaultHandler: '陈工',
      desc: '负责自动化巡检采集、全链路自愈探针、Bastion堡垒机加密凭据与自愈脚本执行机'
    }
  ]);

  /* ------------------- 账号列表 ------------------- */
  const [users, setUsers] = useState<UserAccount[]>([
    {
      id: 1,
      empId: '250992',
      username: 'leiqz',
      password: 'Robam@User2026',
      name: '雷秋子',
      role: '超级管理员',
      domains: ['全部业务域 (全局)'],
      phone: '13800138001',
      email: 'leiqz@robam.com',
      status: '正常',
      passwordValidity: '30天',
      source: '员工池同步'
    },
    {
      id: 2,
      empId: '250993',
      username: 'mug',
      password: 'Robam@Mug2026',
      name: '穆工',
      role: '调度平台负责人',
      domains: ['调度平台'],
      phone: '13900139002',
      email: 'mug@robam.com',
      status: '正常',
      passwordValidity: '30天',
      source: '员工池同步'
    },
    {
      id: 3,
      empId: '250995',
      username: 'zhaog',
      password: 'Robam@Zhao2026',
      name: '赵工',
      role: '调度平台运维工程师',
      domains: ['调度平台'],
      phone: '13711114444',
      email: 'zhaog@robam.com',
      status: '正常',
      passwordValidity: '30天',
      source: '员工池同步'
    },
    {
      id: 4,
      empId: '250994',
      username: 'zhangg',
      password: 'Robam@Zhang2026',
      name: '章工',
      role: '资源池平台负责人',
      domains: ['资源池平台'],
      phone: '13811112222',
      email: 'zhangg@robam.com',
      status: '锁定',
      passwordValidity: '30天',
      source: '员工池同步'
    },
    {
      id: 5,
      empId: '250996',
      username: 'lig',
      password: 'Robam@Li2026',
      name: '李工',
      role: '资源池平台运维工程师',
      domains: ['资源池平台'],
      phone: '13611115555',
      email: 'lig@robam.com',
      status: '正常',
      passwordValidity: '30天',
      source: '员工池同步'
    },
    {
      id: 6,
      empId: '250997',
      username: 'cheng',
      password: 'Robam@Cheng2026',
      name: '陈工',
      role: '运维平台负责人',
      domains: ['运维平台'],
      phone: '13511116666',
      email: 'cheng@robam.com',
      status: '正常',
      passwordValidity: '30天',
      source: '员工池同步'
    },
    {
      id: 7,
      empId: '250998',
      username: 'wangg',
      password: 'Robam@Wang2026',
      name: '王工',
      role: '运维平台告警处理人',
      domains: ['运维平台'],
      phone: '13411117777',
      email: 'wangg@robam.com',
      status: '禁用',
      passwordValidity: '30天',
      source: '员工池同步'
    }
  ]);

  const [userSearchText, setUserSearchText] = useState('');
  const [filterDomain, setFilterDomain] = useState('全部');
  const [filterStatus, setFilterStatus] = useState('全部');
  const [showPasswordMap, setShowPasswordMap] = useState<Record<number, boolean>>({});

  // 账号弹窗
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [showModalPassword, setShowModalPassword] = useState(false);
  const [userForm, setUserForm] = useState({
    empId: '',
    username: '',
    password: '',
    name: '',
    role: '调度平台运维工程师',
    domains: ['调度平台'],
    phone: '',
    email: '',
    status: '正常' as '正常' | '锁定' | '禁用',
    passwordValidity: '30天',
    source: '员工池同步'
  });

  // 业务域弹窗 (创建与修改通用)
  const [domainModalOpen, setDomainModalOpen] = useState(false);
  const [editingDomain, setEditingDomain] = useState<DomainItem | null>(null);
  const [domainForm, setDomainForm] = useState({
    name: '',
    leaders: ['雷秋子'] as string[],
    defaultHandler: '雷秋子',
    desc: ''
  });

  /* ------------------- 菜单与Tab权限架构设计 (11个业务域专属模块 + 3个公共模块) ------------------- */
  const SYSTEM_MENUS: MenuDef[] = [
    // === 业务域专属模块 (11个) - 均按照平台看板设计，绑定业务域进行勾选 ===
    {
      id: 'secondary-dashboard',
      name: '平台看板',
      icon: LayoutDashboard,
      isDomainScoped: true,
      desc: '按业务域隔离展示平台运行指标、状态看板与各域明细流',
      tabs: [
        { id: 'board-code', name: '代码平台', desc: 'Git仓库、代码流与CI流水线状态' },
        { id: 'board-scheduler', name: '调度平台', desc: '调度DAG作业、计算任务监控' },
        { id: 'board-api', name: '接口平台', desc: 'API网关健康度与调用吞吐' },
        { id: 'board-metrics', name: '指标平台', desc: 'Prometheus全局指标看板' }
      ]
    },
    {
      id: 'monitor-center',
      name: '监控中心',
      icon: Monitor,
      isDomainScoped: true,
      desc: '绑定业务域进行服务器、容器指标监控看板与视图模板的权限控制',
      tabs: [
        { id: 'monitor-scheduler', name: '调度平台', desc: 'DolphinScheduler任务调度与计算指标监控' },
        { id: 'monitor-resource', name: '资源池平台', desc: '生产K8s容器组、宿主物理母机、计算存储硬件资源监控' },
        { id: 'monitor-ops', name: '运维平台', desc: '全链路自愈探针采集节点、网络连通性与Bastion机器状态' },
        { id: 'monitor-dashboard', name: '监控看板', desc: '业务域实时性能指标监测视图' },
        { id: 'monitor-custom', name: '自定义看板', desc: '业务个性化多维指标卡片配置' },
        { id: 'monitor-template', name: '监控模板', desc: '系统级预置监控视图模板库' }
      ]
    },
    {
      id: 'alert-threshold',
      name: '阈值规则',
      icon: Database,
      isDomainScoped: true,
      desc: '绑定业务域进行各服务指标阈值、多级触发条件与生效策略的权限控制',
      tabs: [
        { id: 'threshold-scheduler', name: '调度平台', desc: '调度作业执行超时、DAG失败率、队列积压阈值指标规则' },
        { id: 'threshold-resource', name: '资源池平台', desc: '宿主机CPU/内存/磁盘IO高负载阈值、网络丢包率阈值' },
        { id: 'threshold-ops', name: '运维平台', desc: '探针心跳超时阈值、自愈执行机端口存活率与响应时延' }
      ]
    },
    {
      id: 'alert-convergence',
      name: '分组收敛',
      icon: Filter,
      isDomainScoped: true,
      desc: '绑定业务域进行多维标签与拓扑规则收敛聚合、降噪去重的权限控制',
      tabs: [
        { id: 'convergence-scheduler', name: '调度平台', desc: '同一DAG依赖链下游级联任务报警按调度作业流分组收敛' },
        { id: 'convergence-resource', name: '资源池平台', desc: '同机架/交换机物理宿主机及Pod集群多维指标规则收敛' },
        { id: 'convergence-ops', name: '运维平台', desc: '巡检探针与堡垒机直连网络抖动同源告警动态降噪收敛' }
      ]
    },
    {
      id: 'alert-suppression',
      name: '告警抑制',
      icon: Layers,
      isDomainScoped: true,
      desc: '绑定业务域进行上游根因故障自动抑制下游衍生告警策略的权限控制',
      tabs: [
        { id: 'suppression-scheduler', name: '调度平台', desc: '调度上游核心节点故障时自动抑制下游派生任务报错' },
        { id: 'suppression-resource', name: '资源池平台', desc: '核心物理母机宕机时自动抑制宿主容器Pod漂移警告' },
        { id: 'suppression-ops', name: '运维平台', desc: 'Bastion跳板机网络异常时自动抑制下游直连执行失败报警' }
      ]
    },
    {
      id: 'alert-silence',
      name: '告警静默',
      icon: Lock,
      isDomainScoped: true,
      desc: '绑定业务域进行系统割接与例行维护期告警静默窗口的权限控制',
      tabs: [
        { id: 'silence-scheduler', name: '调度平台', desc: '大数据离线计算重跑与DolphinScheduler割接期静默' },
        { id: 'silence-resource', name: '资源池平台', desc: '硬件扩容、内核升级与容器集群例行维护静默窗口' },
        { id: 'silence-ops', name: '运维平台', desc: '自愈脚本批量发布与系统升级割接期告警静默窗口' }
      ]
    },
    {
      id: 'alert-center',
      name: '告警中心',
      icon: BellDot,
      isDomainScoped: true,
      desc: '绑定业务域进行实时未恢复告警列表查阅与处置流转工单的权限控制',
      tabs: [
        { id: 'alertcenter-scheduler', name: '调度平台', desc: '调度平台实时未恢复故障工单、认领流转与处置追踪' },
        { id: 'alertcenter-resource', name: '资源池平台', desc: '资源池硬件与容器告警处置看板、升级工单与事件溯源' },
        { id: 'alertcenter-ops', name: '运维平台', desc: '运维自愈中台工单、堡垒机直连异常排查与事件闭环' }
      ]
    },
    {
      id: 'auto-script',
      name: '自动处理脚本',
      icon: Bot,
      isDomainScoped: true,
      desc: '绑定业务域进行自愈脚本、堡垒机加密凭证、告警路由与执行记录的权限控制',
      tabs: [
        { id: 'script-scheduler', name: '调度平台', desc: '调度平台专属自愈脚本（DAG重试/清理）、执行目标凭证与审计' },
        { id: 'script-resource', name: '资源池平台', desc: '容器与母机自愈脚本（Pod重启/释放缓存）、执行凭证与审计' },
        { id: 'script-ops', name: '运维平台', desc: '自动化巡检与堡垒机直连自愈脚本（探针重启/日志归档）与审计' },
        { id: 'script-list', name: '自动脚本', desc: '自愈Shell/Python脚本库管理与维护功能' },
        { id: 'script-credentials', name: '执行目标凭证', desc: '堡垒机授权账号与直连加密凭据管理功能' },
        { id: 'script-association', name: '告警关联', desc: '告警规则触发脚本自愈路由与测试执行功能' },
        { id: 'script-records', name: '自动执行记录', desc: '自愈执行历史、凭据审计与输出日志功能' }
      ]
    },
    {
      id: 'handler-config',
      name: '系统处理人',
      icon: UserCheck,
      isDomainScoped: true,
      desc: '绑定业务域进行主备告警处理人配置、轮值排班与超时升级的权限控制',
      tabs: [
        { id: 'handler-scheduler', name: '调度平台', desc: '调度平台专属值班工程师排班、主备处理人配置与升级策略' },
        { id: 'handler-resource', name: '资源池平台', desc: '硬件基础设施与容器运维人员排班、主备处理人配置' },
        { id: 'handler-ops', name: '运维平台', desc: '自动化与自愈响应处置人员排班、主备处理人配置' }
      ]
    },
    {
      id: 'alert-notifications',
      name: '消息通知',
      icon: Megaphone,
      isDomainScoped: true,
      desc: '绑定业务域进行钉钉群/短信/邮件多通道推送策略与群组的权限控制',
      tabs: [
        { id: 'notifications-scheduler', name: '调度平台', desc: '调度平台告警推送至专属钉钉群、值班人短信与邮件通知' },
        { id: 'notifications-resource', name: '资源池平台', desc: '基础设施告警推送至硬件保障钉钉群、关键故障电话外呼' },
        { id: 'notifications-ops', name: '运维平台', desc: '运维自愈执行结果与探针异常推送至运维值班群及通道' }
      ]
    },
    {
      id: 'adv-tags',
      name: '标签管理',
      icon: Settings2,
      isDomainScoped: true,
      desc: '绑定业务域进行实体资产标签、告警维度字典与环境标治理的权限控制',
      tabs: [
        { id: 'tags-scheduler', name: '调度平台', desc: '调度作业流标签、DAG优先级标签与业务线多维属性治理' },
        { id: 'tags-resource', name: '资源池平台', desc: '机房机架环境标签、Pod分组标签与硬件资产维度治理' },
        { id: 'tags-ops', name: '运维平台', desc: '巡检服务类型标签、自愈策略等级标签与运维维度治理' }
      ]
    },

    // === 系统公共与全局管理模块 (3个) ===
    {
      id: 'dashboard',
      name: '概览仪表盘 (大屏)',
      icon: Gauge,
      isDomainScoped: false,
      isSinglePage: true,
      desc: '系统级综合监控态势大屏，支持全局跨域联动穿透'
    },
    {
      id: 'dingtalk-integration',
      name: '钉钉消息接入',
      icon: MessageSquare,
      isDomainScoped: false,
      desc: '企业级钉钉自定义机器人消息推送接入与全量日志审计',
      tabs: [
        { id: 'dingtalk-method', name: '消息接入的方法', desc: '自定义机器人Webhook配置向导与安全签名' },
        { id: 'dingtalk-records', name: '消息列表与推送审计', desc: '各业务系统推送日志、发送耗时与投递状态' }
      ]
    },
    {
      id: 'account-rbac',
      name: '账号与权限管理',
      icon: ShieldCheck,
      isDomainScoped: false,
      desc: '企业账号、三权分立权限管理与业务域数据隔离架构',
      tabs: [
        { id: 'rbac-users', name: '账号与员工管理', desc: '系统运维账号增删改查与密码状态控制' },
        { id: 'rbac-permissions', name: '权限管理', desc: '按业务域细分人员菜单与Tab访问控制' },
        { id: 'rbac-domains', name: '业务域与数据隔离架构', desc: '业务域资产划分、负责人与默认处理人联动' }
      ]
    }
  ];

  // 为每个具体人员维护精细化Tab/业务域权限字典 [userId -> { [permId]: boolean }]
  const [userPermissions, setUserPermissions] = useState<Record<number, Record<string, boolean>>>({
    1: { // 雷秋子 - 超级管理员 (全开)
      'dashboard': true,
      // 11个业务域模块全开
      'board-code': true, 'board-scheduler': true, 'board-api': true, 'board-metrics': true,
      'monitor-scheduler': true, 'monitor-resource': true, 'monitor-ops': true,
      'monitor-dashboard': true, 'monitor-custom': true, 'monitor-template': true,
      'threshold-scheduler': true, 'threshold-resource': true, 'threshold-ops': true,
      'convergence-scheduler': true, 'convergence-resource': true, 'convergence-ops': true,
      'suppression-scheduler': true, 'suppression-resource': true, 'suppression-ops': true,
      'silence-scheduler': true, 'silence-resource': true, 'silence-ops': true,
      'alertcenter-scheduler': true, 'alertcenter-resource': true, 'alertcenter-ops': true,
      'script-scheduler': true, 'script-resource': true, 'script-ops': true,
      'script-list': true, 'script-credentials': true, 'script-association': true, 'script-records': true,
      'handler-scheduler': true, 'handler-resource': true, 'handler-ops': true,
      'notifications-scheduler': true, 'notifications-resource': true, 'notifications-ops': true,
      'tags-scheduler': true, 'tags-resource': true, 'tags-ops': true,
      // 系统模块
      'dingtalk-method': true, 'dingtalk-records': true,
      'rbac-users': true, 'rbac-permissions': true, 'rbac-domains': true
    },
    2: { // 穆工 - 调度平台负责人 (绑定调度平台域)
      'dashboard': true,
      // 平台看板
      'board-code': true, 'board-scheduler': true, 'board-api': true, 'board-metrics': false,
      // 绑定调度平台业务域
      'monitor-scheduler': true, 'monitor-resource': false, 'monitor-ops': false,
      'monitor-dashboard': true, 'monitor-custom': true, 'monitor-template': false,
      'threshold-scheduler': true, 'threshold-resource': false, 'threshold-ops': false,
      'convergence-scheduler': true, 'convergence-resource': false, 'convergence-ops': false,
      'suppression-scheduler': true, 'suppression-resource': false, 'suppression-ops': false,
      'silence-scheduler': true, 'silence-resource': false, 'silence-ops': false,
      'alertcenter-scheduler': true, 'alertcenter-resource': false, 'alertcenter-ops': false,
      'script-scheduler': true, 'script-resource': false, 'script-ops': false,
      'script-list': true, 'script-credentials': true, 'script-association': true, 'script-records': true,
      'handler-scheduler': true, 'handler-resource': false, 'handler-ops': false,
      'notifications-scheduler': true, 'notifications-resource': false, 'notifications-ops': false,
      'tags-scheduler': true, 'tags-resource': false, 'tags-ops': false,
      // 系统模块
      'dingtalk-method': true, 'dingtalk-records': true,
      'rbac-users': false, 'rbac-permissions': false, 'rbac-domains': false
    },
    3: { // 赵工 - 调度平台运维工程师 (绑定调度平台运维权限)
      'dashboard': true,
      'board-code': false, 'board-scheduler': true, 'board-api': false, 'board-metrics': false,
      'monitor-scheduler': true, 'monitor-resource': false, 'monitor-ops': false,
      'monitor-dashboard': true, 'monitor-custom': false, 'monitor-template': false,
      'threshold-scheduler': true, 'threshold-resource': false, 'threshold-ops': false,
      'convergence-scheduler': false, 'convergence-resource': false, 'convergence-ops': false,
      'suppression-scheduler': false, 'suppression-resource': false, 'suppression-ops': false,
      'silence-scheduler': false, 'silence-resource': false, 'silence-ops': false,
      'alertcenter-scheduler': true, 'alertcenter-resource': false, 'alertcenter-ops': false,
      'script-scheduler': true, 'script-resource': false, 'script-ops': false,
      'script-list': true, 'script-credentials': false, 'script-association': false, 'script-records': true,
      'handler-scheduler': false, 'handler-resource': false, 'handler-ops': false,
      'notifications-scheduler': true, 'notifications-resource': false, 'notifications-ops': false,
      'tags-scheduler': false, 'tags-resource': false, 'tags-ops': false,
      // 系统模块
      'dingtalk-method': false, 'dingtalk-records': true,
      'rbac-users': false, 'rbac-permissions': false, 'rbac-domains': false
    },
    4: { // 章工 - 资源池平台负责人 (绑定资源池平台域)
      'dashboard': true,
      'board-code': false, 'board-scheduler': false, 'board-api': false, 'board-metrics': true,
      'monitor-scheduler': false, 'monitor-resource': true, 'monitor-ops': false,
      'monitor-dashboard': true, 'monitor-custom': true, 'monitor-template': true,
      'threshold-scheduler': false, 'threshold-resource': true, 'threshold-ops': false,
      'convergence-scheduler': false, 'convergence-resource': true, 'convergence-ops': false,
      'suppression-scheduler': false, 'suppression-resource': true, 'suppression-ops': false,
      'silence-scheduler': false, 'silence-resource': true, 'silence-ops': false,
      'alertcenter-scheduler': false, 'alertcenter-resource': true, 'alertcenter-ops': false,
      'script-scheduler': false, 'script-resource': true, 'script-ops': false,
      'script-list': true, 'script-credentials': true, 'script-association': true, 'script-records': true,
      'handler-scheduler': false, 'handler-resource': true, 'handler-ops': false,
      'notifications-scheduler': false, 'notifications-resource': true, 'notifications-ops': false,
      'tags-scheduler': false, 'tags-resource': true, 'tags-ops': false,
      // 系统模块
      'dingtalk-method': false, 'dingtalk-records': true,
      'rbac-users': false, 'rbac-permissions': false, 'rbac-domains': false
    },
    5: { // 李工 - 资源池平台运维工程师
      'dashboard': true,
      'board-code': false, 'board-scheduler': false, 'board-api': false, 'board-metrics': true,
      'monitor-scheduler': false, 'monitor-resource': true, 'monitor-ops': false,
      'monitor-dashboard': true, 'monitor-custom': false, 'monitor-template': false,
      'threshold-scheduler': false, 'threshold-resource': true, 'threshold-ops': false,
      'convergence-scheduler': false, 'convergence-resource': false, 'convergence-ops': false,
      'suppression-scheduler': false, 'suppression-resource': false, 'suppression-ops': false,
      'silence-scheduler': false, 'silence-resource': true, 'silence-ops': false,
      'alertcenter-scheduler': false, 'alertcenter-resource': true, 'alertcenter-ops': false,
      'script-scheduler': false, 'script-resource': true, 'script-ops': false,
      'script-list': false, 'script-credentials': false, 'script-association': false, 'script-records': true,
      'handler-scheduler': false, 'handler-resource': false, 'handler-ops': false,
      'notifications-scheduler': false, 'notifications-resource': false, 'notifications-ops': false,
      'tags-scheduler': false, 'tags-resource': true, 'tags-ops': false,
      // 系统模块
      'dingtalk-method': false, 'dingtalk-records': true,
      'rbac-users': false, 'rbac-permissions': false, 'rbac-domains': false
    },
    6: { // 陈工 - 运维平台负责人 (绑定运维平台域)
      'dashboard': true,
      'board-code': true, 'board-scheduler': true, 'board-api': true, 'board-metrics': true,
      'monitor-scheduler': false, 'monitor-resource': false, 'monitor-ops': true,
      'monitor-dashboard': true, 'monitor-custom': true, 'monitor-template': true,
      'threshold-scheduler': false, 'threshold-resource': false, 'threshold-ops': true,
      'convergence-scheduler': false, 'convergence-resource': false, 'convergence-ops': true,
      'suppression-scheduler': false, 'suppression-resource': false, 'suppression-ops': true,
      'silence-scheduler': false, 'silence-resource': false, 'silence-ops': true,
      'alertcenter-scheduler': false, 'alertcenter-resource': false, 'alertcenter-ops': true,
      'script-scheduler': false, 'script-resource': false, 'script-ops': true,
      'script-list': true, 'script-credentials': true, 'script-association': true, 'script-records': true,
      'handler-scheduler': false, 'handler-resource': false, 'handler-ops': true,
      'notifications-scheduler': false, 'notifications-resource': false, 'notifications-ops': true,
      'tags-scheduler': false, 'tags-resource': false, 'tags-ops': true,
      // 系统模块
      'dingtalk-method': true, 'dingtalk-records': true,
      'rbac-users': true, 'rbac-permissions': false, 'rbac-domains': false
    },
    7: { // 王工 - 运维平台告警处理人
      'dashboard': true,
      'board-code': false, 'board-scheduler': false, 'board-api': false, 'board-metrics': false,
      'monitor-scheduler': false, 'monitor-resource': false, 'monitor-ops': false,
      'monitor-dashboard': false, 'monitor-custom': false, 'monitor-template': false,
      'threshold-scheduler': false, 'threshold-resource': false, 'threshold-ops': false,
      'convergence-scheduler': false, 'convergence-resource': false, 'convergence-ops': true,
      'suppression-scheduler': false, 'suppression-resource': false, 'suppression-ops': false,
      'silence-scheduler': false, 'silence-resource': false, 'silence-ops': false,
      'alertcenter-scheduler': false, 'alertcenter-resource': false, 'alertcenter-ops': true,
      'script-scheduler': false, 'script-resource': false, 'script-ops': true,
      'script-list': true, 'script-credentials': false, 'script-association': false, 'script-records': true,
      'handler-scheduler': false, 'handler-resource': false, 'handler-ops': true,
      'notifications-scheduler': false, 'notifications-resource': false, 'notifications-ops': true,
      'tags-scheduler': false, 'tags-resource': false, 'tags-ops': false,
      // 系统模块
      'dingtalk-method': false, 'dingtalk-records': true,
      'rbac-users': false, 'rbac-permissions': false, 'rbac-domains': false
    }
  });

  // 权限管理中当前选中的人员 (默认穆工方便查看业务域权限)
  const [selectedUserId, setSelectedUserId] = useState<number>(2);
  const [permissionSavedNotice, setPermissionSavedNotice] = useState(false);
  const [moduleFilterType, setModuleFilterType] = useState<'all' | 'domain' | 'global'>('domain');

  const selectedUser = users.find(u => u.id === selectedUserId) || users[0];

  /* ------------------- 用户操作 ------------------- */
  const handleOpenUserModal = (user: UserAccount | null = null) => {
    if (user) {
      setEditingUser(user);
      setUserForm({
        empId: user.empId,
        username: user.username,
        password: user.password,
        name: user.name,
        role: user.role,
        domains: [...user.domains],
        phone: user.phone,
        email: user.email,
        status: user.status,
        passwordValidity: '30天',
        source: user.source
      });
    } else {
      setEditingUser(null);
      setUserForm({
        empId: '',
        username: '',
        password: 'Robam@User2026',
        name: '',
        role: '调度平台运维工程师',
        domains: ['调度平台'],
        phone: '',
        email: '',
        status: '正常',
        passwordValidity: '30天',
        source: '手动创建'
      });
    }
    setShowModalPassword(false);
    setUserModalOpen(true);
  };

  const handleSaveUser = () => {
    if (!userForm.name.trim() || !userForm.username.trim()) {
      alert('请填写完整姓名与登录用户名');
      return;
    }
    if (!userForm.password.trim()) {
      alert('请设置登录密码');
      return;
    }

    if (editingUser) {
      setUsers(users.map(u => u.id === editingUser.id ? {
        ...u,
        empId: userForm.empId,
        username: userForm.username,
        password: userForm.password,
        name: userForm.name,
        role: userForm.role,
        domains: userForm.domains,
        phone: userForm.phone,
        email: userForm.email,
        status: userForm.status,
        passwordValidity: '30天'
      } : u));
    } else {
      const newId = Date.now();
      const newUser: UserAccount = {
        id: newId,
        empId: userForm.empId || `EMP${Math.floor(1000 + Math.random() * 9000)}`,
        username: userForm.username,
        password: userForm.password,
        name: userForm.name,
        role: userForm.role,
        domains: userForm.domains,
        phone: userForm.phone || '13800000000',
        email: userForm.email || `${userForm.username}@robam.com`,
        status: userForm.status,
        passwordValidity: '30天',
        source: userForm.source
      };
      setUsers([newUser, ...users]);

      // 初始化新用户的权限
      setUserPermissions(prev => ({
        ...prev,
        [newId]: {
          'dashboard': true,
          'alert-center': true,
          'script-list': true,
          'script-records': true
        }
      }));
    }
    setUserModalOpen(false);
  };

  const handleDeleteUser = (id: number) => {
    if (users.length <= 1) {
      alert('系统至少需保留一个超级管理员账号');
      return;
    }
    if (window.confirm('确定要删除该系统账号吗？删除后该用户将无法登录监控平台。')) {
      setUsers(users.filter(u => u.id !== id));
      if (selectedUserId === id) {
        setSelectedUserId(users.find(u => u.id !== id)?.id || 1);
      }
    }
  };

  const handleChangeStatus = (id: number, newStatus: '正常' | '锁定' | '禁用') => {
    setUsers(users.map(u => u.id === id ? { ...u, status: newStatus } : u));
  };

  const toggleShowPassword = (id: number) => {
    setShowPasswordMap(prev => ({ ...prev, [id]: !prev[id] }));
  };

  /* ------------------- 业务域操作 (新建与修改) ------------------- */
  const handleOpenDomainModal = (existingDomain: DomainItem | null = null) => {
    if (existingDomain) {
      setEditingDomain(existingDomain);
      setDomainForm({
        name: existingDomain.name,
        leaders: [...existingDomain.leaders],
        defaultHandler: existingDomain.defaultHandler,
        desc: existingDomain.desc
      });
    } else {
      setEditingDomain(null);
      const firstUser = users[0]?.name || '雷秋子';
      setDomainForm({
        name: '',
        leaders: [firstUser],
        defaultHandler: firstUser,
        desc: ''
      });
    }
    setDomainModalOpen(true);
  };

  // 勾选/取消勾选负责人，并与默认处理人保持联动（只能从已打勾的负责人里选择）
  const handleToggleLeader = (userName: string) => {
    const isChecked = domainForm.leaders.includes(userName);
    let nextLeaders: string[];
    if (isChecked) {
      if (domainForm.leaders.length === 1) {
        alert('业务域至少需要保留一位负责人');
        return;
      }
      nextLeaders = domainForm.leaders.filter(n => n !== userName);
    } else {
      nextLeaders = [...domainForm.leaders, userName];
    }

    const nextDefault = nextLeaders.includes(domainForm.defaultHandler) 
      ? domainForm.defaultHandler 
      : (nextLeaders[0] || '');

    setDomainForm({
      ...domainForm,
      leaders: nextLeaders,
      defaultHandler: nextDefault
    });
  };

  const handleSaveDomain = () => {
    if (!domainForm.name.trim()) {
      alert('请填写业务域名称');
      return;
    }
    if (domainForm.leaders.length === 0) {
      alert('请至少勾选一位业务域负责人');
      return;
    }
    if (!domainForm.defaultHandler) {
      alert('请从已选负责人中指定默认处理人');
      return;
    }

    if (editingDomain) {
      setDomains(domains.map(d => d.id === editingDomain.id ? {
        ...d,
        name: domainForm.name.trim(),
        leaders: domainForm.leaders,
        defaultHandler: domainForm.defaultHandler,
        desc: domainForm.desc.trim() || '暂无描述'
      } : d));
    } else {
      const newDomain: DomainItem = {
        id: `domain-${Date.now()}`,
        name: domainForm.name.trim(),
        leaders: domainForm.leaders,
        defaultHandler: domainForm.defaultHandler,
        desc: domainForm.desc.trim() || '暂无描述'
      };
      setDomains([...domains, newDomain]);
    }
    setDomainModalOpen(false);
  };

  const handleDeleteDomain = (id: string) => {
    if (domains.length <= 1) {
      alert('系统至少需保留一个业务域');
      return;
    }
    if (window.confirm('确定删除该业务域吗？删除后属于该域的资产与告警将需重新分配。')) {
      setDomains(domains.filter(d => d.id !== id));
    }
  };

  /* ------------------- 人员具体权限切换操作 ------------------- */
  const currentUserPerms = userPermissions[selectedUserId] || {};

  const handleToggleUserPermission = (permKey: string) => {
    setUserPermissions(prev => {
      const userObj = prev[selectedUserId] || {};
      return {
        ...prev,
        [selectedUserId]: {
          ...userObj,
          [permKey]: !userObj[permKey]
        }
      };
    });
  };

  const handleToggleMenuAllTabs = (menu: MenuDef, enableAll: boolean) => {
    setUserPermissions(prev => {
      const userObj = { ...(prev[selectedUserId] || {}) };
      if (menu.isSinglePage) {
        userObj[menu.id] = enableAll;
      } else if (menu.tabs) {
        menu.tabs.forEach(t => {
          userObj[t.id] = enableAll;
        });
      }
      return {
        ...prev,
        [selectedUserId]: userObj
      };
    });
  };

  const handleSetAllUserPerms = (enableAll: boolean) => {
    setUserPermissions(prev => {
      const newObj: Record<string, boolean> = {};
      SYSTEM_MENUS.forEach(menu => {
        if (menu.isSinglePage) {
          newObj[menu.id] = enableAll;
        } else if (menu.tabs) {
          menu.tabs.forEach(t => {
            newObj[t.id] = enableAll;
          });
        }
      });
      return {
        ...prev,
        [selectedUserId]: newObj
      };
    });
  };

  const handleSetDomainOnlyPerms = (enableAll: boolean) => {
    setUserPermissions(prev => {
      const userObj = { ...(prev[selectedUserId] || {}) };
      SYSTEM_MENUS.filter(m => m.isDomainScoped).forEach(menu => {
        if (menu.isSinglePage) {
          userObj[menu.id] = enableAll;
        } else if (menu.tabs) {
          menu.tabs.forEach(t => {
            userObj[t.id] = enableAll;
          });
        }
      });
      return {
        ...prev,
        [selectedUserId]: userObj
      };
    });
  };

  const handleSaveUserPermissions = () => {
    setPermissionSavedNotice(true);
    setTimeout(() => setPermissionSavedNotice(false), 2200);
  };

  /* ------------------- 过滤列表 ------------------- */
  const filteredUsers = users.filter(u => {
    const matchText = u.name.includes(userSearchText) || u.username.includes(userSearchText) || u.empId.includes(userSearchText);
    const matchDomain = filterDomain === '全部' || u.domains.includes(filterDomain) || u.domains.includes('全部业务域 (全局)');
    const matchStatus = filterStatus === '全部' || u.status === filterStatus;
    return matchText && matchDomain && matchStatus;
  });

  // 人员分组：除了超级管理员外，其他人员按照业务域分（调度平台、资源池平台、运维平台）
  const superAdminUsers = users.filter(u => u.role.includes('超级管理员'));
  const schedulerUsers = users.filter(u => !u.role.includes('超级管理员') && u.domains.includes('调度平台'));
  const resourceUsers = users.filter(u => !u.role.includes('超级管理员') && u.domains.includes('资源池平台'));
  const opsUsers = users.filter(u => !u.role.includes('超级管理员') && u.domains.includes('运维平台'));
  // 其他可能未分组的人员
  const otherUsers = users.filter(u => 
    !u.role.includes('超级管理员') && 
    !u.domains.includes('调度平台') && 
    !u.domains.includes('资源池平台') && 
    !u.domains.includes('运维平台')
  );

  return (
    <div className="w-full h-full flex flex-col bg-white overflow-hidden text-[13px]">
      
      {/* 顶部标题栏 */}
      <div className="px-6 py-4 border-b border-gray-100 bg-[#FAFAFA] shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-gray-800 text-sm font-bold">
            <ShieldCheck size={20} className="text-[#3b82f6]" />
            账号、权限与业务域管理
          </div>
        </div>

        {/* 三大功能 Tab: 账号与员工管理、权限管理(按业务域具体到人及Tab)、业务域与数据隔离架构 */}
        <div className="flex gap-8 border-b border-gray-200 mt-4">
          <button 
            onClick={() => setActiveTab('users')}
            className={`pb-2.5 px-1 font-medium transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'users' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Users size={15} /> 账号与员工管理
          </button>
          
          <button 
            onClick={() => setActiveTab('permissions')}
            className={`pb-2.5 px-1 font-medium transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'permissions' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <KeyRound size={15} /> 权限管理
          </button>

          <button 
            onClick={() => setActiveTab('domains')}
            className={`pb-2.5 px-1 font-medium transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'domains' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Layers size={15} /> 业务域与数据隔离架构
          </button>
        </div>
      </div>

      {/* ===================== Tab 1: 账号与员工管理 ===================== */}
      {activeTab === 'users' && (
        <div className="flex-1 overflow-auto bg-white p-5 flex flex-col">
          {/* 筛选与操作栏 */}
          <div className="flex justify-between items-center mb-4 flex-wrap gap-3">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => handleOpenUserModal()}
                className="bg-blue-600 text-white px-3.5 py-1.5 rounded text-xs font-medium hover:bg-blue-700 transition flex items-center gap-1.5 shadow-sm"
              >
                <Plus size={14} /> 新建系统账号
              </button>
            </div>

            <div className="flex items-center gap-2">
              <select 
                value={filterDomain} 
                onChange={e => setFilterDomain(e.target.value)}
                className="border border-gray-200 rounded px-2.5 h-[32px] text-xs focus:outline-none focus:border-blue-500 bg-white"
              >
                <option value="全部">全部业务域</option>
                {domains.map(d => (
                  <option key={d.id} value={d.name}>{d.name}</option>
                ))}
              </select>

              <select 
                value={filterStatus} 
                onChange={e => setFilterStatus(e.target.value)}
                className="border border-gray-200 rounded px-2.5 h-[32px] text-xs focus:outline-none focus:border-blue-500 bg-white"
              >
                <option value="全部">全部状态</option>
                <option value="正常">正常</option>
                <option value="锁定">锁定</option>
                <option value="禁用">禁用</option>
              </select>

              <div className="flex items-center border border-gray-200 rounded overflow-hidden h-[32px] w-64 focus-within:border-blue-500 transition-colors">
                <Search size={14} className="text-gray-400 ml-2.5 shrink-0" />
                <input 
                  type="text" 
                  value={userSearchText}
                  onChange={e => setUserSearchText(e.target.value)}
                  placeholder="搜索工号、姓名、登录账号..." 
                  className="text-xs px-2 w-full h-full focus:outline-none placeholder:text-gray-400" 
                />
              </div>
            </div>
          </div>

          {/* 用户列表表格 */}
          <div className="border border-gray-100 rounded-lg overflow-hidden shadow-sm">
            <table className="w-full text-left text-[13px] border-collapse">
              <thead>
                <tr className="border-b border-gray-200 text-gray-500 bg-gray-50/70">
                  <th className="py-3 px-4 font-bold text-gray-700">员工姓名 / 工号</th>
                  <th className="py-3 px-4 font-bold text-gray-700">登录账号 (用户名)</th>
                  <th className="py-3 px-4 font-bold text-gray-700">登录密码</th>
                  <th className="py-3 px-4 font-bold text-gray-700">密码有效期</th>
                  <th className="py-3 px-4 font-bold text-gray-700">系统角色</th>
                  <th className="py-3 px-4 font-bold text-gray-700">授权业务域</th>
                  <th className="py-3 px-4 font-bold text-gray-700">账号状态</th>
                  <th className="py-3 px-4 font-bold text-gray-700 text-right pr-5">操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map(user => {
                  const isPasswordVisible = showPasswordMap[user.id];
                  return (
                    <tr key={user.id} className="border-b border-gray-100 hover:bg-blue-50/30 transition-colors group">
                      {/* 员工姓名 / 工号 */}
                      <td className="py-3.5 px-4 font-medium text-gray-800">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            {user.name.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold flex items-center gap-1.5">
                              {user.name}
                              <span className="text-[10px] text-gray-400 font-mono font-normal">({user.empId})</span>
                            </div>
                            <div className="text-[11px] text-gray-400 font-mono">{user.phone}</div>
                          </div>
                        </div>
                      </td>

                      {/* 登录账号 */}
                      <td className="py-3.5 px-4">
                        <span className="font-mono text-gray-700 font-medium bg-gray-100 px-2 py-0.5 rounded text-xs">
                          {user.username}
                        </span>
                      </td>

                      {/* 登录密码 */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5 font-mono text-xs">
                          <span className="text-gray-800">
                            {isPasswordVisible ? user.password : '••••••••••••'}
                          </span>
                          <button 
                            onClick={() => toggleShowPassword(user.id)}
                            className="text-gray-400 hover:text-gray-600 transition p-0.5"
                            title={isPasswordVisible ? '隐藏密码' : '查看明文密码'}
                          >
                            {isPasswordVisible ? <EyeOff size={13} /> : <Eye size={13} />}
                          </button>
                        </div>
                      </td>

                      {/* 密码有效期 */}
                      <td className="py-3.5 px-4">
                        <span className="inline-flex items-center gap-1 text-xs text-gray-600 bg-gray-50 border border-gray-200 px-2 py-0.5 rounded font-mono">
                          <Lock size={11} className="text-gray-400" />
                          30天
                        </span>
                      </td>

                      {/* 系统角色 */}
                      <td className="py-3.5 px-4">
                        <span className="font-medium text-gray-700 text-xs">
                          {user.role}
                        </span>
                      </td>

                      {/* 数据授权业务域 */}
                      <td className="py-3.5 px-4">
                        <div className="flex flex-wrap gap-1">
                          {user.domains.map((dom, i) => (
                            <span 
                              key={i} 
                              className={`text-[11px] px-2 py-0.5 rounded font-medium border ${
                                dom.includes('调度') ? 'bg-amber-50 text-amber-700 border-amber-200' :
                                dom.includes('资源池') ? 'bg-blue-50 text-blue-700 border-blue-200' :
                                dom.includes('运维') ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                                'bg-purple-50 text-purple-700 border-purple-200'
                              }`}
                            >
                              {dom}
                            </span>
                          ))}
                        </div>
                      </td>

                      {/* 账号状态：下拉框形式 */}
                      <td className="py-3.5 px-4">
                        <select 
                          value={user.status}
                          onChange={(e) => handleChangeStatus(user.id, e.target.value as '正常' | '锁定' | '禁用')}
                          className={`text-xs font-medium rounded px-2 py-1 border transition-colors cursor-pointer focus:outline-none ${
                            user.status === '正常' ? 'bg-green-50 text-green-700 border-green-300' :
                            user.status === '锁定' ? 'bg-red-50 text-red-700 border-red-300' :
                            'bg-gray-100 text-gray-700 border-gray-300'
                          }`}
                        >
                          <option value="正常">正常</option>
                          <option value="锁定">锁定</option>
                          <option value="禁用">禁用</option>
                        </select>
                      </td>

                      {/* 操作列：保留编辑和删除 */}
                      <td className="py-3.5 px-4 text-right pr-5 space-x-2 whitespace-nowrap">
                        <button 
                          onClick={() => handleOpenUserModal(user)}
                          className="text-blue-500 hover:text-blue-700 p-1 rounded hover:bg-blue-50 transition" 
                          title="编辑"
                        >
                          <Edit size={15} />
                        </button>
                        <button 
                          onClick={() => handleDeleteUser(user.id)}
                          className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition" 
                          title="删除"
                        >
                          <Trash2 size={15} />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="flex justify-between items-center mt-3 text-xs text-gray-500 px-2">
            <div>共计 <strong>{filteredUsers.length}</strong> 个系统运维与处置账号</div>
            <div className="text-gray-400">
              提示：可直接在表格「账号状态」列下拉切换账号状态（正常、锁定、禁用）。
            </div>
          </div>
        </div>
      )}

      {/* ===================== Tab 2: 权限管理 (除超管外按业务域分人员，具体到人及细分子Tab) ===================== */}
      {activeTab === 'permissions' && (
        <div className="flex-1 overflow-hidden flex bg-gray-50/50">
          
          {/* 左侧人员列表：按业务域分组 (调度平台、资源池平台、运维平台 + 超级管理员) */}
          <div className="w-[320px] bg-white border-r border-gray-200 flex flex-col shrink-0">
            <div className="p-4 border-b border-gray-100 bg-gray-50/50">
              <h4 className="font-bold text-gray-800 text-sm flex items-center gap-1.5">
                <Users size={16} className="text-blue-600" />
                人员权限列表
              </h4>
              <p className="text-xs text-gray-400 mt-1">
                除超级管理员外，其他人员按【调度平台、资源池平台、运维平台】划分，点击人员配置独立权限。
              </p>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-4">
              
              {/* 分组 1: 超级管理员 */}
              <div>
                <div className="text-[11px] font-bold text-purple-700 uppercase tracking-wider mb-1.5 px-2 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Shield size={12} className="text-purple-600" /> 超级管理员
                  </span>
                  <span className="text-gray-400 text-[10px] font-mono">{superAdminUsers.length} 人</span>
                </div>
                <div className="space-y-1">
                  {superAdminUsers.map(user => {
                    const isSelected = user.id === selectedUserId;
                    return (
                      <div 
                        key={user.id}
                        onClick={() => setSelectedUserId(user.id)}
                        className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                          isSelected 
                            ? 'border-purple-500 bg-purple-50/60 ring-1 ring-purple-400 shadow-sm' 
                            : 'border-gray-200 bg-white hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <div className="w-7 h-7 rounded-full bg-purple-100 text-purple-700 font-bold text-xs flex items-center justify-center shrink-0">
                            {user.name.charAt(0)}
                          </div>
                          <div className="truncate">
                            <div className="font-bold text-gray-800 text-xs flex items-center gap-1">
                              {user.name}
                              <span className="text-[10px] text-gray-400 font-mono font-normal">({user.empId})</span>
                            </div>
                            <div className="text-[10px] text-purple-600 truncate">{user.role}</div>
                          </div>
                        </div>
                        <ChevronRight size={14} className={isSelected ? 'text-purple-600' : 'text-gray-300'} />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 分组 2: 调度平台 */}
              <div>
                <div className="text-[11px] font-bold text-amber-700 uppercase tracking-wider mb-1.5 px-2 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Database size={12} className="text-amber-600" /> 调度平台
                  </span>
                  <span className="text-gray-400 text-[10px] font-mono">{schedulerUsers.length} 人</span>
                </div>
                <div className="space-y-1">
                  {schedulerUsers.map(user => {
                    const isSelected = user.id === selectedUserId;
                    return (
                      <div 
                        key={user.id}
                        onClick={() => setSelectedUserId(user.id)}
                        className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                          isSelected 
                            ? 'border-amber-500 bg-amber-50/60 ring-1 ring-amber-400 shadow-sm' 
                            : 'border-gray-200 bg-white hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <div className="w-7 h-7 rounded-full bg-amber-100 text-amber-700 font-bold text-xs flex items-center justify-center shrink-0">
                            {user.name.charAt(0)}
                          </div>
                          <div className="truncate">
                            <div className="font-bold text-gray-800 text-xs flex items-center gap-1">
                              {user.name}
                              <span className="text-[10px] text-gray-400 font-mono font-normal">({user.empId})</span>
                            </div>
                            <div className="text-[10px] text-amber-700 truncate">{user.role}</div>
                          </div>
                        </div>
                        <ChevronRight size={14} className={isSelected ? 'text-amber-600' : 'text-gray-300'} />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 分组 3: 资源池平台 */}
              <div>
                <div className="text-[11px] font-bold text-blue-700 uppercase tracking-wider mb-1.5 px-2 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Layers size={12} className="text-blue-600" /> 资源池平台
                  </span>
                  <span className="text-gray-400 text-[10px] font-mono">{resourceUsers.length} 人</span>
                </div>
                <div className="space-y-1">
                  {resourceUsers.map(user => {
                    const isSelected = user.id === selectedUserId;
                    return (
                      <div 
                        key={user.id}
                        onClick={() => setSelectedUserId(user.id)}
                        className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                          isSelected 
                            ? 'border-blue-500 bg-blue-50/60 ring-1 ring-blue-400 shadow-sm' 
                            : 'border-gray-200 bg-white hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center shrink-0">
                            {user.name.charAt(0)}
                          </div>
                          <div className="truncate">
                            <div className="font-bold text-gray-800 text-xs flex items-center gap-1">
                              {user.name}
                              <span className="text-[10px] text-gray-400 font-mono font-normal">({user.empId})</span>
                            </div>
                            <div className="text-[10px] text-blue-600 truncate">{user.role}</div>
                          </div>
                        </div>
                        <ChevronRight size={14} className={isSelected ? 'text-blue-600' : 'text-gray-300'} />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 分组 4: 运维平台 */}
              <div>
                <div className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider mb-1.5 px-2 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Briefcase size={12} className="text-emerald-600" /> 运维平台
                  </span>
                  <span className="text-gray-400 text-[10px] font-mono">{opsUsers.length} 人</span>
                </div>
                <div className="space-y-1">
                  {opsUsers.map(user => {
                    const isSelected = user.id === selectedUserId;
                    return (
                      <div 
                        key={user.id}
                        onClick={() => setSelectedUserId(user.id)}
                        className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                          isSelected 
                            ? 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-400 shadow-sm' 
                            : 'border-gray-200 bg-white hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center shrink-0">
                            {user.name.charAt(0)}
                          </div>
                          <div className="truncate">
                            <div className="font-bold text-gray-800 text-xs flex items-center gap-1">
                              {user.name}
                              <span className="text-[10px] text-gray-400 font-mono font-normal">({user.empId})</span>
                            </div>
                            <div className="text-[10px] text-emerald-700 truncate">{user.role}</div>
                          </div>
                        </div>
                        <ChevronRight size={14} className={isSelected ? 'text-emerald-600' : 'text-gray-300'} />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 其他人员 */}
              {otherUsers.length > 0 && (
                <div>
                  <div className="text-[11px] font-bold text-gray-600 uppercase tracking-wider mb-1.5 px-2">
                    其他人员 ({otherUsers.length})
                  </div>
                  <div className="space-y-1">
                    {otherUsers.map(user => {
                      const isSelected = user.id === selectedUserId;
                      return (
                        <div 
                          key={user.id}
                          onClick={() => setSelectedUserId(user.id)}
                          className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                            isSelected 
                              ? 'border-blue-500 bg-blue-50/60 ring-1 ring-blue-400 shadow-sm' 
                              : 'border-gray-200 bg-white hover:border-gray-300'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <div className="w-7 h-7 rounded-full bg-gray-100 text-gray-700 font-bold text-xs flex items-center justify-center shrink-0">
                              {user.name.charAt(0)}
                            </div>
                            <div className="truncate">
                              <div className="font-bold text-gray-800 text-xs flex items-center gap-1">
                                {user.name}
                                <span className="text-[10px] text-gray-400 font-mono font-normal">({user.empId})</span>
                              </div>
                              <div className="text-[10px] text-gray-500 truncate">{user.role}</div>
                            </div>
                          </div>
                          <ChevronRight size={14} className={isSelected ? 'text-blue-600' : 'text-gray-300'} />
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

            </div>
          </div>

          {/* 右侧：具体人员的细分Tab菜单权限矩阵 */}
          <div className="flex-1 overflow-y-auto p-6 flex flex-col bg-white">
            <div className="flex justify-between items-start mb-4 pb-4 border-b border-gray-100 flex-wrap gap-4">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-bold text-gray-800 text-base flex items-center gap-2">
                    <User size={18} className="text-blue-600" />
                    【{selectedUser.name} ({selectedUser.empId})】权限配置
                  </h3>
                  <span className={`text-xs px-2.5 py-0.5 rounded font-medium border ${
                    selectedUser.role.includes('超级管理员') 
                      ? 'bg-purple-50 text-purple-700 border-purple-200' 
                      : selectedUser.domains.includes('调度平台')
                      ? 'bg-amber-50 text-amber-700 border-amber-200'
                      : selectedUser.domains.includes('资源池平台')
                      ? 'bg-blue-50 text-blue-700 border-blue-200'
                      : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  }`}>
                    {selectedUser.domains.join(', ')} · {selectedUser.role}
                  </span>
                  <span className={`text-[11px] px-2 py-0.5 rounded border ${
                    selectedUser.status === '正常' ? 'bg-green-50 text-green-700 border-green-200' :
                    selectedUser.status === '锁定' ? 'bg-red-50 text-red-700 border-red-200' :
                    'bg-gray-100 text-gray-600 border-gray-200'
                  }`}>
                    状态: {selectedUser.status}
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  按业务域精细化授权。除超级管理员外，业务域人员权限严格作用于本业务域内数据与资产。
                </p>
              </div>

              {/* 快捷批量操作按钮 */}
              <div className="flex items-center gap-2 flex-wrap">
                <button 
                  onClick={() => handleSetDomainOnlyPerms(true)}
                  className="px-2.5 py-1.5 text-xs bg-amber-50 border border-amber-300 text-amber-800 rounded hover:bg-amber-100 font-medium transition flex items-center gap-1 shadow-xs"
                  title="为当前人员一键开通全部11个业务域隔离模块"
                >
                  <ShieldCheck size={13} className="text-amber-600" />
                  一键授权11个业务域模块
                </button>
                <button 
                  onClick={() => handleSetAllUserPerms(true)}
                  className="px-2.5 py-1.5 text-xs border border-gray-300 rounded hover:bg-gray-50 text-gray-700 transition"
                >
                  全选所有权限
                </button>
                <button 
                  onClick={() => handleSetAllUserPerms(false)}
                  className="px-2.5 py-1.5 text-xs border border-gray-300 rounded hover:bg-gray-50 text-gray-500 transition"
                >
                  一键清空
                </button>

                {permissionSavedNotice && (
                  <span className="text-xs text-green-700 bg-green-50 px-2.5 py-1 rounded border border-green-200 font-medium flex items-center gap-1 animate-in fade-in">
                    <CheckCircle2 size={13} /> 权限已成功应用生效
                  </span>
                )}
                <button 
                  onClick={handleSaveUserPermissions}
                  className="bg-blue-600 text-white px-4 py-1.5 rounded hover:bg-blue-700 transition flex items-center gap-1.5 text-xs font-medium shadow-sm ml-1"
                >
                  <Check size={14} /> 保存人员权限配置
                </button>
              </div>
            </div>

            {/* 模块分类筛选选项卡 */}
            <div className="flex items-center justify-between border-b border-gray-200 pb-2 mb-4 flex-wrap gap-2">
              <div className="flex items-center gap-1.5 text-xs">
                <button
                  onClick={() => setModuleFilterType('domain')}
                  className={`px-3 py-1.5 rounded font-medium transition flex items-center gap-1.5 ${
                    moduleFilterType === 'domain'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <ShieldCheck size={13} />
                  业务域划分模块 (11个)
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    moduleFilterType === 'domain' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {SYSTEM_MENUS.filter(m => m.isDomainScoped).length}
                  </span>
                </button>

                <button
                  onClick={() => setModuleFilterType('all')}
                  className={`px-3 py-1.5 rounded font-medium transition flex items-center gap-1.5 ${
                    moduleFilterType === 'all'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  全部权限模块 (14个)
                </button>

                <button
                  onClick={() => setModuleFilterType('global')}
                  className={`px-3 py-1.5 rounded font-medium transition flex items-center gap-1.5 ${
                    moduleFilterType === 'global'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  系统全局管理模块 (3个)
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    moduleFilterType === 'global' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {SYSTEM_MENUS.filter(m => !m.isDomainScoped).length}
                  </span>
                </button>
              </div>

              <div className="text-[11px] text-gray-400">
                各业务域模块支持绑定业务域并进行勾选授权
              </div>
            </div>

            {/* 权限目录树 - 11个业务域模块均按照平台看板设计，绑定业务域进行勾选 */}
            <div className="space-y-4">
              {SYSTEM_MENUS
                .filter(menu => {
                  if (moduleFilterType === 'domain') return menu.isDomainScoped;
                  if (moduleFilterType === 'global') return !menu.isDomainScoped;
                  return true;
                })
                .map((menu) => {
                  const MenuIcon = menu.icon;

                  // 单页面全局系统模块 (如概览仪表盘大屏)
                  if (menu.isSinglePage) {
                    const isEnabled = !!currentUserPerms[menu.id];
                    return (
                      <div 
                        key={menu.id} 
                        className="border border-gray-200 rounded-lg overflow-hidden bg-white shadow-xs transition-all"
                      >
                        <div className="p-3.5 flex items-center justify-between hover:bg-gray-50/60 transition flex-wrap gap-2">
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-lg ${
                              isEnabled ? 'bg-purple-50 text-purple-600' : 'bg-gray-100 text-gray-400'
                            }`}>
                              <MenuIcon size={18} />
                            </div>
                            <div>
                              <div className="font-bold text-gray-800 text-xs flex items-center gap-2 flex-wrap">
                                <span>{menu.name}</span>
                                <span className="text-[10px] text-gray-400 font-normal font-mono">({menu.id})</span>
                                <span className="text-[10px] px-2 py-0.5 rounded bg-gray-100 text-gray-600 border border-gray-200">
                                  系统公共模块
                                </span>
                              </div>
                              <div className="text-[11px] text-gray-500 mt-1">
                                {menu.desc || '独立工作页面，开通后该员工可直接访问'}
                              </div>
                            </div>
                          </div>

                          <label className="flex items-center gap-2 cursor-pointer text-xs font-medium bg-gray-50/80 px-3 py-1.5 rounded-md border border-gray-200 hover:bg-gray-100 transition">
                            <input 
                              type="checkbox"
                              checked={isEnabled}
                              onChange={() => handleToggleUserPermission(menu.id)}
                              className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                            />
                            <span className={isEnabled ? 'text-blue-700 font-semibold' : 'text-gray-400'}>
                              {isEnabled ? '已授权访问' : '未开通'}
                            </span>
                          </label>
                        </div>
                      </div>
                    );
                  }

                  // 业务域划分模块 (全部按照平台看板形式设计，绑定业务域进行勾选) 及系统多Tab模块
                  const tabs = menu.tabs || [];
                  const activeCount = tabs.filter(t => !!currentUserPerms[t.id]).length;

                  return (
                    <div 
                      key={menu.id} 
                      className={`border rounded-lg overflow-hidden bg-white shadow-xs ${
                        menu.isDomainScoped ? 'border-blue-200' : 'border-gray-200'
                      }`}
                    >
                      {/* 菜单目录头部 */}
                      <div className="bg-gray-50/90 px-4 py-2.5 border-b border-gray-200 flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <div className={`p-1 rounded ${activeCount > 0 ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'}`}>
                            <MenuIcon size={16} />
                          </div>
                          <span className="font-bold text-gray-800 text-xs">
                            {menu.name}
                          </span>
                          
                          {menu.isDomainScoped ? (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 font-medium">
                              ★ 业务域划分模块
                            </span>
                          ) : (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-gray-100 text-gray-600 border border-gray-200">
                              系统公共模块
                            </span>
                          )}

                          <span className="text-gray-400 text-xs font-mono">
                            ({activeCount}/{tabs.length} 个{menu.isDomainScoped ? '业务域' : 'Tab'}已勾选)
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-xs">
                          <button 
                            onClick={() => handleToggleMenuAllTabs(menu, true)}
                            className="text-blue-600 hover:underline font-medium"
                          >
                            全选{menu.isDomainScoped ? '业务域' : 'Tab'}
                          </button>
                          <span className="text-gray-300">|</span>
                          <button 
                            onClick={() => handleToggleMenuAllTabs(menu, false)}
                            className="text-gray-500 hover:underline"
                          >
                            清空
                          </button>
                        </div>
                      </div>

                      {/* 模块描述信息 */}
                      {menu.desc && (
                        <div className="px-4 py-1.5 bg-blue-50/20 text-[11px] text-gray-500 border-b border-gray-100">
                          {menu.desc}
                        </div>
                      )}

                      {/* 按照平台看板一样的设计：绑定业务域，进行勾选 */}
                      <div className={`p-3.5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-${tabs.length > 3 ? '4' : '3'} gap-3 bg-white`}>
                        {tabs.map((tab) => {
                          const isTabEnabled = !!currentUserPerms[tab.id];
                          return (
                            <label 
                              key={tab.id}
                              className={`flex items-start gap-2.5 p-2.5 rounded border cursor-pointer transition text-xs ${
                                isTabEnabled 
                                  ? 'bg-blue-50/60 border-blue-300 text-blue-900 font-medium shadow-2xs' 
                                  : 'bg-gray-50/40 border-gray-200 text-gray-500 hover:bg-gray-100'
                              }`}
                            >
                              <input 
                                type="checkbox"
                                checked={isTabEnabled}
                                onChange={() => handleToggleUserPermission(tab.id)}
                                className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
                              />
                              <div className="flex-1 truncate">
                                <div className="font-bold truncate text-gray-800 flex items-center gap-1">
                                  {tab.name}
                                </div>
                                {tab.desc && (
                                  <div className="text-[10px] text-gray-400 mt-0.5 line-clamp-1">
                                    {tab.desc}
                                  </div>
                                )}
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}

      {/* ===================== Tab 3: 业务域与数据隔离架构 (已配置业务域支持修改按钮) ===================== */}
      {activeTab === 'domains' && (
        <div className="flex-1 overflow-auto bg-gray-50/50 p-6 flex flex-col space-y-5">
          
          {/* 业务域配置列表 */}
          <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm">
            <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
              <div>
                <h4 className="font-bold text-gray-800 text-sm">已配置业务域与数据隔离架构</h4>
                <p className="text-xs text-gray-400 mt-0.5">
                  支持在线新建与修改业务域。负责人与默认处理人均来自当前平台账号，并实施联动约束。
                </p>
              </div>
              <button 
                onClick={() => handleOpenDomainModal(null)}
                className="bg-blue-600 text-white px-3.5 py-1.5 rounded text-xs font-medium hover:bg-blue-700 flex items-center gap-1.5 shadow-sm transition"
              >
                <Plus size={14} /> 新建业务域
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {domains.map(d => (
                <div key={d.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-all bg-white relative shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                          <Database size={16} />
                        </div>
                        <div>
                          <div className="font-bold text-gray-800 text-sm flex items-center gap-2">
                            {d.name}
                          </div>
                          {/* 负责人：不区分协同管理，把所有的负责人列在上面即可 */}
                          <div className="text-[11px] text-gray-500 mt-0.5">
                            负责人: <strong className="text-gray-700">{d.leaders.join(', ')}</strong>
                          </div>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-gray-600 mb-3 line-clamp-2">{d.desc}</p>

                    <div className="bg-gray-50 rounded p-2.5 space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-500">默认处理人：</span>
                        <span className="font-medium text-gray-800 bg-white px-2 py-0.5 rounded border border-gray-200">
                          {d.defaultHandler}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 底部操作区：新增「修改」按钮，并保留删除 */}
                  <div className="mt-4 pt-2.5 border-t border-gray-100 flex justify-end items-center gap-2 text-xs">
                    <button 
                      onClick={() => handleOpenDomainModal(d)}
                      className="text-blue-600 hover:text-blue-800 px-2 py-1 rounded hover:bg-blue-50 transition flex items-center gap-1 font-medium border border-blue-200"
                      title="修改业务域配置"
                    >
                      <Edit size={13} /> 修改
                    </button>
                    <button 
                      onClick={() => handleDeleteDomain(d.id)}
                      className="text-gray-400 hover:text-red-600 p-1 transition rounded hover:bg-red-50"
                      title="删除业务域"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ====================== 模态弹窗区 ====================== */}

      {/* 1. 用户编辑/新建弹窗 */}
      {userModalOpen && (
        <div className="fixed inset-0 bg-black/40 z-[120] flex items-center justify-center">
          <div className="bg-white rounded-lg shadow-2xl w-[520px] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-3.5 border-b border-gray-100 flex justify-between items-center bg-gray-50">
              <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                <Users size={16} className="text-blue-600" />
                {editingUser ? '编辑用户账号' : '新建系统运维账号'}
              </h3>
              <button onClick={() => setUserModalOpen(false)} className="text-gray-400 hover:text-gray-600"><X size={18} /></button>
            </div>

            <div className="p-5 flex flex-col gap-3.5 text-xs overflow-y-auto max-h-[75vh]">
              {!editingUser && (
                <div className="bg-blue-50/70 border border-blue-200 rounded p-2.5 flex items-center justify-between">
                  <span className="text-blue-800 font-medium">从员工池快速选取填入基础信息：</span>
                  <select 
                    onChange={(e) => {
                      const emp = EMPLOYEE_POOL.find(p => p.empId === e.target.value);
                      if (emp) {
                        setUserForm({
                          ...userForm,
                          empId: emp.empId,
                          name: emp.name,
                          username: emp.email.split('@')[0],
                          phone: emp.phone,
                          email: emp.email,
                          role: emp.roleSuggestion
                        });
                      }
                    }}
                    className="border border-blue-300 rounded px-2 py-1 text-xs bg-white text-gray-700"
                  >
                    <option value="">-- 选择员工 --</option>
                    {EMPLOYEE_POOL.map(emp => (
                      <option key={emp.empId} value={emp.empId}>{emp.name} ({emp.empId})</option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-gray-700 block mb-1">员工姓名 <span className="text-red-500">*</span></label>
                  <input 
                    type="text" 
                    value={userForm.name} 
                    onChange={e => setUserForm({...userForm, name: e.target.value})} 
                    placeholder="如：穆工" 
                    className="w-full border border-gray-300 rounded px-3 py-1.5 focus:outline-none focus:border-blue-500" 
                  />
                </div>
                <div>
                  <label className="font-bold text-gray-700 block mb-1">员工工号 <span className="text-red-500">*</span></label>
                  <input 
                    type="text" 
                    value={userForm.empId} 
                    onChange={e => setUserForm({...userForm, empId: e.target.value})} 
                    placeholder="如：250993" 
                    className="w-full border border-gray-300 rounded px-3 py-1.5 font-mono focus:outline-none focus:border-blue-500" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-gray-700 block mb-1">系统登录用户名 <span className="text-red-500">*</span></label>
                  <input 
                    type="text" 
                    value={userForm.username} 
                    onChange={e => setUserForm({...userForm, username: e.target.value})} 
                    placeholder="如：mug" 
                    className="w-full border border-gray-300 rounded px-3 py-1.5 font-mono focus:outline-none focus:border-blue-500" 
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">系统角色</label>
                  <input 
                    type="text" 
                    value={userForm.role} 
                    onChange={e => setUserForm({...userForm, role: e.target.value})} 
                    placeholder="如：调度平台负责人" 
                    className="w-full border border-gray-300 rounded px-3 py-1.5 focus:outline-none focus:border-blue-500" 
                  />
                </div>
              </div>

              {/* 登录密码 & 密码有效期 */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-gray-700 block mb-1">登录密码 <span className="text-red-500">*</span></label>
                  <div className="relative">
                    <input 
                      type={showModalPassword ? 'text' : 'password'} 
                      value={userForm.password} 
                      onChange={e => setUserForm({...userForm, password: e.target.value})} 
                      placeholder="设置登录密码" 
                      className="w-full border border-gray-300 rounded px-3 py-1.5 pr-8 font-mono focus:outline-none focus:border-blue-500" 
                    />
                    <button 
                      type="button" 
                      onClick={() => setShowModalPassword(!showModalPassword)}
                      className="absolute right-2 top-2 text-gray-400 hover:text-gray-600"
                    >
                      {showModalPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">密码有效期 (固定)</label>
                  <div className="w-full border border-gray-200 bg-gray-100 rounded px-3 py-1.5 text-gray-700 font-medium">
                    30天 (平台强制策略)
                  </div>
                </div>
              </div>

              {/* 账号状态 */}
              <div>
                <label className="font-bold text-gray-700 block mb-1">账号状态</label>
                <div className="flex gap-4">
                  {(['正常', '锁定', '禁用'] as const).map(st => (
                    <label key={st} className="flex items-center gap-1.5 cursor-pointer">
                      <input 
                        type="radio" 
                        name="accountStatus"
                        value={st}
                        checked={userForm.status === st}
                        onChange={() => setUserForm({...userForm, status: st})}
                        className="text-blue-600 focus:ring-blue-500"
                      />
                      <span>{st}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-gray-700 block mb-1">手机号 (用于短信/钉钉)</label>
                  <input 
                    type="text" 
                    value={userForm.phone} 
                    onChange={e => setUserForm({...userForm, phone: e.target.value})} 
                    placeholder="13800000000" 
                    className="w-full border border-gray-300 rounded px-3 py-1.5 font-mono focus:outline-none focus:border-blue-500" 
                  />
                </div>
                <div>
                  <label className="font-bold text-gray-700 block mb-1">企业邮箱</label>
                  <input 
                    type="text" 
                    value={userForm.email} 
                    onChange={e => setUserForm({...userForm, email: e.target.value})} 
                    placeholder="user@robam.com" 
                    className="w-full border border-gray-300 rounded px-3 py-1.5 font-mono focus:outline-none focus:border-blue-500" 
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-gray-700 block mb-1.5">授权关联的业务域</label>
                <div className="grid grid-cols-3 gap-2 border border-gray-200 p-2.5 rounded bg-gray-50/50">
                  {domains.map(dom => {
                    const isChecked = userForm.domains.includes(dom.name) || userForm.domains.includes('全部业务域 (全局)');
                    return (
                      <label key={dom.id} className="flex items-center gap-2 cursor-pointer text-gray-700">
                        <input 
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setUserForm({...userForm, domains: [...userForm.domains.filter(d => d !== '全部业务域 (全局)'), dom.name]});
                            } else {
                              setUserForm({...userForm, domains: userForm.domains.filter(d => d !== dom.name && d !== '全部业务域 (全局)')});
                            }
                          }}
                          className="rounded text-blue-600 focus:ring-blue-500"
                        />
                        <span>{dom.name}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="px-5 py-3 border-t border-gray-200 bg-gray-50 flex justify-end gap-2.5 shrink-0">
              <button onClick={() => setUserModalOpen(false)} className="px-3.5 py-1.5 text-gray-600 hover:bg-gray-200 rounded">取消</button>
              <button onClick={handleSaveUser} className="px-4 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium">确认保存</button>
            </div>
          </div>
        </div>
      )}

      {/* 2. 业务域新建/修改弹窗 (从当前平台账号里选择负责人，默认处理人联动只能从已勾选负责人中选择，不设置标签) */}
      {domainModalOpen && (
        <div className="fixed inset-0 bg-black/40 z-[120] flex items-center justify-center">
          <div className="bg-white rounded-lg shadow-2xl w-[560px] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-3.5 border-b border-gray-100 flex justify-between items-center bg-gray-50">
              <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                <Layers size={16} className="text-blue-600" />
                {editingDomain ? '修改业务域配置' : '新建业务域'}
              </h3>
              <button onClick={() => setDomainModalOpen(false)} className="text-gray-400 hover:text-gray-600"><X size={18} /></button>
            </div>

            <div className="p-5 flex flex-col gap-4 text-xs overflow-y-auto max-h-[75vh]">
              {/* 业务域名称 */}
              <div>
                <label className="font-bold text-gray-700 block mb-1">
                  业务域名称 <span className="text-red-500">*</span>
                </label>
                <input 
                  type="text" 
                  value={domainForm.name} 
                  onChange={e => setDomainForm({...domainForm, name: e.target.value})} 
                  placeholder="如：调度平台 / 资源池平台 / 运维平台" 
                  className="w-full border border-gray-300 rounded px-3 py-1.5 focus:outline-none focus:border-blue-500" 
                />
              </div>

              {/* 负责人：从当前平台账号列表里选择 */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="font-bold text-gray-700">
                    负责人 (从当前平台账号中直接勾选，可多选) <span className="text-red-500">*</span>
                  </label>
                  <span className="text-[11px] text-blue-600 font-medium">
                    已选 {domainForm.leaders.length} 位
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 border border-gray-200 p-2.5 rounded bg-gray-50/50 max-h-44 overflow-y-auto">
                  {users.map(u => {
                    const isChecked = domainForm.leaders.includes(u.name);
                    return (
                      <label 
                        key={u.id} 
                        onClick={() => handleToggleLeader(u.name)}
                        className={`flex items-center gap-2 p-2 rounded border cursor-pointer transition ${
                          isChecked 
                            ? 'bg-blue-50/70 border-blue-400 text-blue-900 font-medium' 
                            : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <input 
                          type="checkbox" 
                          checked={isChecked}
                          onChange={() => {}} // 由外部 label 点击处理
                          className="rounded text-blue-600 focus:ring-blue-500"
                        />
                        <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-[10px] shrink-0">
                          {u.name.charAt(0)}
                        </div>
                        <div className="flex-1 truncate">
                          <span className="font-medium text-xs">{u.name}</span>
                          <span className="text-[10px] text-gray-400 font-mono ml-1">({u.username})</span>
                          <div className="text-[10px] text-gray-400 truncate">{u.role}</div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* 默认处理人：与负责人严格联动，只能从已打勾的负责人里选择 */}
              <div>
                <label className="font-bold text-gray-700 block mb-1">
                  默认处理人 (只能从已打勾的负责人里选择) <span className="text-red-500">*</span>
                </label>
                <select 
                  value={domainForm.defaultHandler}
                  onChange={e => setDomainForm({...domainForm, defaultHandler: e.target.value})}
                  className="w-full border border-gray-300 rounded px-3 py-1.5 bg-white text-gray-700 focus:outline-none focus:border-blue-500"
                >
                  {domainForm.leaders.length === 0 ? (
                    <option value="">请先在上方勾选负责人</option>
                  ) : (
                    domainForm.leaders.map(name => {
                      const userObj = users.find(u => u.name === name);
                      return (
                        <option key={name} value={name}>
                          {name} {userObj ? `(${userObj.username} - ${userObj.role})` : ''}
                        </option>
                      );
                    })
                  )}
                </select>
                <p className="text-[11px] text-gray-400 mt-1">
                  提示：若上方负责人勾选变更，默认处理人将自动联动更新。
                </p>
              </div>

              {/* 业务域描述 */}
              <div>
                <label className="font-bold text-gray-700 block mb-1">业务域描述</label>
                <textarea 
                  rows={2} 
                  value={domainForm.desc} 
                  onChange={e => setDomainForm({...domainForm, desc: e.target.value})} 
                  placeholder="请输入该业务域所负责的业务系统、技术链路与资产范围说明..." 
                  className="w-full border border-gray-300 rounded px-3 py-1.5 focus:outline-none focus:border-blue-500" 
                />
              </div>
            </div>

            <div className="px-5 py-3 border-t border-gray-200 bg-gray-50 flex justify-end gap-2.5 shrink-0">
              <button onClick={() => setDomainModalOpen(false)} className="px-3.5 py-1.5 text-gray-600 hover:bg-gray-200 rounded">取消</button>
              <button onClick={handleSaveDomain} className="px-4 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium">
                {editingDomain ? '保存修改' : '确认创建'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
