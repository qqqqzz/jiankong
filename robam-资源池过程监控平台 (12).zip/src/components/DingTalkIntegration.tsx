import React, { useState } from 'react';
import { 
  Send, CheckCircle2, AlertCircle, RefreshCw, Smartphone, 
  Settings2, Copy, Check, ShieldAlert, Filter, 
  Search, Terminal, Layers, ArrowRight, BellRing, Bot, MessageSquare, Info
} from 'lucide-react';

interface DingTalkMessage {
  id: string;
  sourceSystem: string;
  level: '紧急' | '严重' | '警告' | '通知';
  title: string;
  content: string;
  targetChat: string;
  sendTime: string;
  status: '成功' | '失败';
  httpCode: number;
  errorMessage?: string;
  durationMs: number;
}

export default function DingTalkIntegration() {
  const [activeTab, setActiveTab] = useState<'config' | 'list'>('config');
  const [copied, setCopied] = useState(false);
  const [testSending, setTestSending] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  // 简化的接入配置 (群机器人 + 个人工作通知)
  const [webhookConfig, setWebhookConfig] = useState({
    webhookUrl: 'https://oapi.dingtalk.com/robot/send?access_token=66a88b99c011e4288b89...',
    secret: 'SEC5f9a2b890c231145698bc213897103215891...',
    botName: '老板电器告警机器人',
    targetGroup: 'ROBAM-生产监控应急群'
  });

  const [appConfig, setAppConfig] = useState({
    appKey: 'dingabc123456789xyz',
    appSecret: 'appsec_99812401823901238910',
    agentId: '298371109'
  });

  // 测试消息表单
  const [testSource, setTestSource] = useState('调度平台');
  const [testMessageText, setTestMessageText] = useState('【连通性测试】这是一条来自过程监控平台的钉钉通道连通性测试消息。');

  // 消息列表数据 (原系统、消息内容、发送时间、是否成功等)
  const [messages, setMessages] = useState<DingTalkMessage[]>([
    {
      id: 'MSG-001',
      sourceSystem: '调度平台',
      level: '严重',
      title: '数仓凌晨增量ETL调度任务等待超时',
      content: '任务 [ods_kitchen_iot_device_status_di] 运行超时，阻塞已超 45 分钟。',
      targetChat: 'ROBAM-生产监控应急群',
      sendTime: '2026-06-12 10:50:22',
      status: '成功',
      httpCode: 200,
      durationMs: 82
    },
    {
      id: 'MSG-002',
      sourceSystem: '资源池平台',
      level: '紧急',
      title: 'Doris FE 生产节点心跳超时',
      content: '集群 DORIS_FE_172.18.11.105 心跳超时超 120 秒，已触发 @章工。',
      targetChat: 'ROBAM-生产监控应急群',
      sendTime: '2026-06-12 09:35:10',
      status: '成功',
      httpCode: 200,
      durationMs: 95
    },
    {
      id: 'MSG-003',
      sourceSystem: '运维平台',
      level: '警告',
      title: '接口网关 P99 响应延迟超 500ms',
      content: '/api/v1/kitchen/report 接口近5分钟响应延迟达到 580ms。',
      targetChat: 'ROBAM-生产监控应急群',
      sendTime: '2026-06-12 09:12:05',
      status: '成功',
      httpCode: 200,
      durationMs: 76
    },
    {
      id: 'MSG-004',
      sourceSystem: '调度平台',
      level: '严重',
      title: '工控网关连接中断',
      content: 'PLC工控机 10.20.14.88 超过3次心跳无响应。',
      targetChat: 'ROBAM-生产监控应急群',
      sendTime: '2026-06-11 23:15:40',
      status: '失败',
      httpCode: 40015,
      errorMessage: '加签校验不匹配或机器人已被群主移除',
      durationMs: 310
    }
  ]);

  const [filterSource, setFilterSource] = useState('全部');
  const [filterStatus, setFilterStatus] = useState('全部');
  const [searchText, setSearchText] = useState('');
  const [selectedMessage, setSelectedMessage] = useState<DingTalkMessage | null>(null);

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(webhookConfig.webhookUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendTestMessage = () => {
    setTestSending(true);
    setTestResult(null);
    setTimeout(() => {
      setTestSending(false);
      setTestResult('测试消息已成功送达钉钉群「ROBAM-生产监控应急群」，耗时 72ms');
      
      const newMsg: DingTalkMessage = {
        id: `MSG-${Date.now().toString().slice(-4)}`,
        sourceSystem: testSource,
        level: '警告',
        title: `【连通性测试】${testSource}告警通道验证`,
        content: testMessageText,
        targetChat: webhookConfig.targetGroup,
        sendTime: new Date().toLocaleString(),
        status: '成功',
        httpCode: 200,
        durationMs: 72
      };
      setMessages([newMsg, ...messages]);
    }, 700);
  };

  const filteredMessages = messages.filter(m => {
    const matchSource = filterSource === '全部' || m.sourceSystem === filterSource;
    const matchStatus = filterStatus === '全部' || m.status === filterStatus;
    const matchText = m.title.includes(searchText) || m.content.includes(searchText) || m.sourceSystem.includes(searchText);
    return matchSource && matchStatus && matchText;
  });

  return (
    <div className="w-full h-full flex flex-col bg-white overflow-hidden text-[13px]">
      
      {/* 顶部标题栏 */}
      <div className="px-6 py-4 border-b border-gray-100 bg-[#FAFAFA] shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-gray-800 text-sm font-bold">
            <MessageSquare size={18} className="text-[#3b82f6]" />
            钉钉消息接入
          </div>

          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-green-50 border border-green-200 text-green-700 text-xs font-medium">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            钉钉消息网关在线
          </span>
        </div>

        {/* 简洁导航选项卡 */}
        <div className="flex gap-8 border-b border-gray-200 mt-3">
          <button 
            onClick={() => setActiveTab('config')}
            className={`pb-2.5 px-1 font-medium transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'config' ? 'border-blue-500 text-blue-600 font-bold' : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Settings2 size={15} /> 1. 接入配置
          </button>
          <button 
            onClick={() => setActiveTab('list')}
            className={`pb-2.5 px-1 font-medium transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'list' ? 'border-blue-500 text-blue-600 font-bold' : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <BellRing size={15} /> 2. 消息列表 ({messages.length})
          </button>
        </div>
      </div>

      {/* 界面 1: 简化的接入配置 */}
      {activeTab === 'config' && (
        <div className="flex-1 overflow-auto bg-gray-50/50 p-6 space-y-5">
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* 卡片 1: 钉钉群自定义机器人 (Webhook) */}
            <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-xs">
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-gray-100">
                <div className="flex items-center gap-2 font-bold text-gray-800 text-sm">
                  <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                    <Bot size={16} />
                  </div>
                  群自定义机器人 (Webhook 推送)
                </div>
                <span className="text-[11px] bg-green-50 text-green-700 px-2 py-0.5 rounded border border-green-200 font-medium">
                  已启用
                </span>
              </div>

              <div className="space-y-3.5 text-xs">
                <div>
                  <label className="font-bold text-gray-700 block mb-1">Webhook 地址</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={webhookConfig.webhookUrl}
                      onChange={e => setWebhookConfig({...webhookConfig, webhookUrl: e.target.value})}
                      className="flex-1 border border-gray-300 rounded px-3 py-1.5 font-mono text-xs focus:outline-none focus:border-blue-500 bg-gray-50/30"
                    />
                    <button 
                      onClick={handleCopyUrl}
                      className="px-3 py-1.5 border border-gray-300 rounded bg-gray-50 hover:bg-gray-100 text-gray-700 flex items-center gap-1 shrink-0"
                    >
                      {copied ? <Check size={13} className="text-green-600" /> : <Copy size={13} />}
                      <span>{copied ? '已复制' : '复制'}</span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">加签 Secret</label>
                  <input 
                    type="password" 
                    value={webhookConfig.secret}
                    onChange={e => setWebhookConfig({...webhookConfig, secret: e.target.value})}
                    className="w-full border border-gray-300 rounded px-3 py-1.5 font-mono text-xs focus:outline-none focus:border-blue-500" 
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-gray-700 block mb-1">机器人名称</label>
                    <input 
                      type="text" 
                      value={webhookConfig.botName}
                      onChange={e => setWebhookConfig({...webhookConfig, botName: e.target.value})}
                      className="w-full border border-gray-300 rounded px-3 py-1.5 focus:outline-none focus:border-blue-500" 
                    />
                  </div>
                  <div>
                    <label className="font-bold text-gray-700 block mb-1">接收钉钉群</label>
                    <input 
                      type="text" 
                      value={webhookConfig.targetGroup}
                      onChange={e => setWebhookConfig({...webhookConfig, targetGroup: e.target.value})}
                      className="w-full border border-gray-300 rounded px-3 py-1.5 focus:outline-none focus:border-blue-500" 
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 卡片 2: 企业内部应用 (钉钉个人工作通知) */}
            <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-xs">
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-gray-100">
                <div className="flex items-center gap-2 font-bold text-gray-800 text-sm">
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                    <Smartphone size={16} />
                  </div>
                  企业内部应用凭证 (个人工作通知)
                </div>
                <span className="text-[11px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200 font-medium">
                  用于个人推送
                </span>
              </div>

              <div className="space-y-3.5 text-xs">
                <div>
                  <label className="font-bold text-gray-700 block mb-1">AppKey (Client ID)</label>
                  <input 
                    type="text" 
                    value={appConfig.appKey}
                    onChange={e => setAppConfig({...appConfig, appKey: e.target.value})}
                    className="w-full border border-gray-300 rounded px-3 py-1.5 font-mono text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">AppSecret</label>
                  <input 
                    type="password" 
                    value={appConfig.appSecret}
                    onChange={e => setAppConfig({...appConfig, appSecret: e.target.value})}
                    className="w-full border border-gray-300 rounded px-3 py-1.5 font-mono text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">AgentId (应用微应用ID)</label>
                  <input 
                    type="text" 
                    value={appConfig.agentId}
                    onChange={e => setAppConfig({...appConfig, agentId: e.target.value})}
                    className="w-full border border-gray-300 rounded px-3 py-1.5 font-mono text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 简易测试发送控制台 */}
          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-xs">
            <h4 className="font-bold text-gray-800 text-sm mb-3 flex items-center gap-2">
              <Send size={15} className="text-blue-600" />
              快捷连通性测试
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs mb-3">
              <div>
                <label className="font-bold text-gray-700 block mb-1">原系统</label>
                <select 
                  value={testSource} 
                  onChange={e => setTestSource(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-1.5 bg-white focus:outline-none focus:border-blue-500"
                >
                  <option value="调度平台">调度平台</option>
                  <option value="资源池平台">资源池平台</option>
                  <option value="运维平台">运维平台</option>
                  <option value="指标平台">指标平台</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="font-bold text-gray-700 block mb-1">测试内容</label>
                <input 
                  type="text" 
                  value={testMessageText}
                  onChange={e => setTestMessageText(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-1.5 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-gray-100 flex-wrap gap-2">
              <div className="text-xs text-gray-500">
                点击右侧按钮将向钉钉群发送测试报文，可在「消息列表」实时查阅发送日志。
              </div>

              <div className="flex items-center gap-3">
                {testResult && (
                  <span className="text-xs text-green-700 font-medium flex items-center gap-1 bg-green-50 px-2.5 py-1 rounded border border-green-200">
                    <CheckCircle2 size={13} /> {testResult}
                  </span>
                )}
                <button 
                  onClick={handleSendTestMessage}
                  disabled={testSending}
                  className="bg-blue-600 text-white px-4 py-1.5 rounded hover:bg-blue-700 transition flex items-center gap-1.5 shadow-sm text-xs font-medium disabled:opacity-50"
                >
                  {testSending ? <RefreshCw size={14} className="animate-spin" /> : <Send size={14} />}
                  <span>{testSending ? '发送中...' : '发送测试消息'}</span>
                </button>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* 界面 2: 消息列表 (原系统、消息内容、发送时间、是否成功) */}
      {activeTab === 'list' && (
        <div className="flex-1 overflow-auto bg-white p-5 flex flex-col">
          {/* 筛选与搜索 */}
          <div className="flex justify-between items-center mb-4 flex-wrap gap-3">
            <div className="flex items-center gap-2">
              <select 
                value={filterSource} 
                onChange={e => setFilterSource(e.target.value)}
                className="border border-gray-200 rounded px-2.5 h-[32px] text-xs focus:outline-none focus:border-blue-500 bg-white"
              >
                <option value="全部">全部原系统</option>
                <option value="调度平台">调度平台</option>
                <option value="资源池平台">资源池平台</option>
                <option value="运维平台">运维平台</option>
                <option value="指标平台">指标平台</option>
              </select>

              <select 
                value={filterStatus} 
                onChange={e => setFilterStatus(e.target.value)}
                className="border border-gray-200 rounded px-2.5 h-[32px] text-xs focus:outline-none focus:border-blue-500 bg-white"
              >
                <option value="全部">全部状态</option>
                <option value="成功">发送成功</option>
                <option value="失败">发送失败</option>
              </select>
            </div>

            <div className="flex items-center border border-gray-200 rounded overflow-hidden h-[32px] w-72 focus-within:border-blue-500 transition-colors">
              <Search size={14} className="text-gray-400 ml-2.5 shrink-0" />
              <input 
                type="text" 
                value={searchText}
                onChange={e => setSearchText(e.target.value)}
                placeholder="搜索原系统、消息内容..." 
                className="text-xs px-2 w-full h-full focus:outline-none placeholder:text-gray-400" 
              />
            </div>
          </div>

          {/* 消息表格 */}
          <div className="border border-gray-100 rounded-lg overflow-hidden shadow-sm flex-1">
            <table className="w-full text-left text-[13px] border-collapse">
              <thead>
                <tr className="border-b border-gray-200 text-gray-500 bg-gray-50/70">
                  <th className="py-3 px-4 font-bold text-gray-700 w-32">原系统</th>
                  <th className="py-3 px-4 font-bold text-gray-700">消息内容与标题</th>
                  <th className="py-3 px-4 font-bold text-gray-700 w-44">发送时间</th>
                  <th className="py-3 px-4 font-bold text-gray-700 text-center w-28">是否成功</th>
                  <th className="py-3 px-4 font-bold text-gray-700 text-right pr-6 w-24">操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredMessages.map(msg => (
                  <tr key={msg.id} className="border-b border-gray-100 hover:bg-blue-50/30 transition-colors">
                    {/* 原系统 */}
                    <td className="py-3.5 px-4 font-medium">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold border ${
                        msg.sourceSystem.includes('调度') ? 'bg-amber-50 text-amber-700 border-amber-200' :
                        msg.sourceSystem.includes('资源池') ? 'bg-blue-50 text-blue-700 border-blue-200' :
                        msg.sourceSystem.includes('运维') ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                        'bg-purple-50 text-purple-700 border-purple-200'
                      }`}>
                        {msg.sourceSystem}
                      </span>
                    </td>

                    {/* 消息内容与标题 */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-gray-800 text-xs mb-0.5">
                        {msg.title}
                      </div>
                      <div className="text-[12px] text-gray-500 line-clamp-1">
                        {msg.content}
                      </div>
                    </td>

                    {/* 发送时间 */}
                    <td className="py-3.5 px-4 font-mono text-xs text-gray-500">
                      {msg.sendTime}
                    </td>

                    {/* 是否成功 */}
                    <td className="py-3.5 px-4 text-center">
                      {msg.status === '成功' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-green-50 text-green-700 border border-green-200">
                          <CheckCircle2 size={12} /> 成功 ({msg.durationMs}ms)
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-red-50 text-red-700 border border-red-200" title={msg.errorMessage}>
                          <AlertCircle size={12} /> 失败
                        </span>
                      )}
                    </td>

                    {/* 操作 */}
                    <td className="py-3.5 px-4 text-right pr-6 whitespace-nowrap">
                      <button 
                        onClick={() => setSelectedMessage(msg)}
                        className="text-blue-600 hover:text-blue-800 text-xs font-medium px-2 py-1 rounded hover:bg-blue-50 transition"
                      >
                        详情
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-between items-center mt-3 text-xs text-gray-500 px-2">
            <div>共计 <strong>{filteredMessages.length}</strong> 条钉钉消息推送审计记录</div>
            <div className="text-gray-400">
              数据自动每 30 秒轮询刷新
            </div>
          </div>
        </div>
      )}

      {/* 消息详情模态框 */}
      {selectedMessage && (
        <div className="fixed inset-0 bg-black/40 z-[120] flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl w-[480px] flex flex-col overflow-hidden animate-in fade-in duration-150">
            <div className="px-5 py-3 border-b border-gray-100 flex justify-between items-center bg-gray-50">
              <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                <MessageSquare size={16} className="text-blue-600" />
                钉钉推送详情
              </h3>
              <button onClick={() => setSelectedMessage(null)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>

            <div className="p-5 flex flex-col gap-3 text-xs">
              <div className="flex justify-between border-b pb-2">
                <span className="text-gray-500">原系统：</span>
                <span className="font-bold text-gray-800">{selectedMessage.sourceSystem}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-gray-500">发送时间：</span>
                <span className="font-mono text-gray-700">{selectedMessage.sendTime}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-gray-500">推送状态：</span>
                <span className={selectedMessage.status === '成功' ? 'text-green-600 font-bold' : 'text-red-600 font-bold'}>
                  {selectedMessage.status} (耗时: {selectedMessage.durationMs}ms)
                </span>
              </div>
              <div>
                <span className="text-gray-500 block mb-1">推送标题：</span>
                <div className="bg-gray-50 p-2 rounded border border-gray-200 font-medium text-gray-800">
                  {selectedMessage.title}
                </div>
              </div>
              <div>
                <span className="text-gray-500 block mb-1">消息内容：</span>
                <div className="bg-gray-50 p-2.5 rounded border border-gray-200 text-gray-700 leading-relaxed">
                  {selectedMessage.content}
                </div>
              </div>
              {selectedMessage.errorMessage && (
                <div>
                  <span className="text-red-500 block mb-1 font-bold">错误响应信息：</span>
                  <div className="bg-red-50 p-2 rounded border border-red-200 text-red-700 font-mono text-[11px]">
                    {selectedMessage.errorMessage}
                  </div>
                </div>
              )}
            </div>

            <div className="px-5 py-3 border-t border-gray-200 bg-gray-50 flex justify-end">
              <button 
                onClick={() => setSelectedMessage(null)}
                className="px-4 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 text-xs font-medium"
              >
                关闭
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
