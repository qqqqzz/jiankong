import React, { useState } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, BarChart, Bar, Cell } from 'recharts';
import { Server, Database, Box, Terminal, RefreshCw, XCircle, MinusCircle, CheckCircle2, Search, Info, LayoutTemplate, AlertTriangle, AlertCircle, Clock, ChevronDown, History, BarChart2, Check, CircleDot, Activity } from 'lucide-react';

export default function SecondaryDashboard({ initialPlatform }: { initialPlatform?: string; key?: any }) {
  const [platform, setPlatform] = useState(initialPlatform || '全部');
  const [trendTime, setTrendTime] = useState('24小时');
  const [barTime, setBarTime] = useState('24小时');

  const getLineChartData = (time: string) => {
    if (time === '30天内') return [
      { time: 'Week 1', alert: 3800, recovery: 3750 },
      { time: 'Week 2', alert: 4900, recovery: 4800 },
      { time: 'Week 3', alert: 3200, recovery: 3100 },
      { time: 'Week 4', alert: 5200, recovery: 5100 },
    ];
    if (time === '7天内') return [
      { time: 'Mon', alert: 500, recovery: 480 },
      { time: 'Tue', alert: 600, recovery: 550 },
      { time: 'Wed', alert: 700, recovery: 680 },
      { time: 'Thu', alert: 550, recovery: 500 },
      { time: 'Fri', alert: 800, recovery: 780 },
      { time: 'Sat', alert: 400, recovery: 400 },
      { time: 'Sun', alert: 450, recovery: 430 },
    ];
    return [
      { time: '00:00', alert: 120, recovery: 130 },
      { time: '04:00', alert: 150, recovery: 140 },
      { time: '08:00', alert: 320, recovery: 260 },
      { time: '12:00', alert: 280, recovery: 240 },
      { time: '16:00', alert: 450, recovery: 400 },
      { time: '20:00', alert: 220, recovery: 210 },
      { time: '24:00', alert: 180, recovery: 170 },
    ];
  };

  const getBarChartData = (time: string) => {
    let m = 1;
    if (time === '7天内') m = 7;
    if (time === '30天内') m = 30;
    return [
      { name: '警告告警', pending: 60 * m, processing: 0, resolved: 30 * m, ignored: 10 * m },
      { name: '严重告警', pending: 80 * m, processing: 0, resolved: 20 * m, ignored: 10 * m },
      { name: '紧急告警', pending: 20 * m, processing: 10 * m, resolved: 10 * m, ignored: 0 },
    ];
  };

  const lineChartData = getLineChartData(trendTime);
  const barChartData = getBarChartData(barTime);

  const statCards = [
    { title: '应用程序', icon: LayoutTemplate, total: 5, normal: 5, down: 0, pause: 0, borderClass: 'border-blue-100', iconClass: 'text-blue-500', bgClass: 'text-blue-50', bgFill: 'bg-blue-50/30' },
    { title: '数据库', icon: Database, total: 1, normal: 1, down: 0, pause: 0, borderClass: 'border-emerald-100', iconClass: 'text-emerald-500', bgClass: 'text-emerald-50', bgFill: 'bg-emerald-50/30' },
    { title: '缓存', icon: Box, total: 3, normal: 3, down: 0, pause: 0, borderClass: 'border-amber-100', iconClass: 'text-amber-500', bgClass: 'text-amber-50', bgFill: 'bg-amber-50/30' },
    { title: '>_操作系统', icon: Terminal, total: 0, normal: 0, down: 0, pause: 0, borderClass: 'border-rose-100', iconClass: 'text-rose-500', bgClass: 'text-rose-50', bgFill: 'bg-rose-50/30' },
  ];

  const alarms = [
    { time: '2026-04-23 06:57:35', level: '严重告警', msg: '挂载点: /data，可用量: 19854.0 (MB)', type: 'warning', bg: 'bg-[#fefce8]', border: 'border-[#fef08a]', iconColor: 'text-amber-500', badgeObj: 'bg-amber-100 text-amber-700' },
    { time: '2026-04-22 06:57:35', level: '紧急告警', msg: 'doris数据库无法连接', type: 'error', bg: 'bg-[#fef2f2]', border: 'border-[#fecaca]', iconColor: 'text-rose-500', badgeObj: 'bg-rose-100 text-rose-700' },
    { time: '2026-04-21 08:57:35', level: '紧急告警', msg: '172.18.99.12服务器443端口无法访问', type: 'error', bg: 'bg-[#fef2f2]', border: 'border-[#fecaca]', iconColor: 'text-rose-500', badgeObj: 'bg-rose-100 text-rose-700' },
  ];

  const alarmStats = [
    { label: '未处理', icon: AlertCircle, val: 10, color: 'text-amber-600', bg: 'bg-[#fef9c3]/50', borderColor: 'border-amber-200' },
    { label: '处理中', icon: RefreshCw, val: 15, color: 'text-blue-600', bg: 'bg-[#eff6ff]/50', borderColor: 'border-blue-200' },
    { label: '已处理', icon: CheckCircle2, val: 10, color: 'text-emerald-600', bg: 'bg-[#ecfdf5]/50', borderColor: 'border-emerald-200' },
    { label: '已忽略', icon: MinusCircle, val: 20, color: 'text-slate-600', bg: 'bg-[#f8fafc]', borderColor: 'border-slate-200' }
  ];

  const activities = [
    {
       action: '>_ 执行自动脚本 [测试端口1的summary失败告警]',
       result: '告警问题已恢复',
       resultType: 'success',
       time: '2026-05-06 12:01:00'
    },
    {
       action: '>_ 执行自动脚本 [测试端口1的summary失败告警]',
       result: '脚本执行成功',
       resultType: 'success',
       time: '2026-05-06 12:00:02'
    },
    {
       action: '>_ 触发告警推送 [测试端口1的summary失败告警]',
       result: '首次告警生成',
       resultType: 'info',
       time: '2026-05-06 12:00:00'
    }
  ];

  return (
    <div className="flex-1 w-full bg-[#f8f9fa] text-slate-800 -m-6 p-6 overflow-y-auto">
      <style>{`
        @keyframes scrollUp {
          0% { transform: translateY(0); }
          100% { transform: translateY(-50%); }
        }
        .animate-scroll {
          animation: scrollUp 15s linear infinite;
        }
        .animate-scroll:hover {
          animation-play-state: paused;
        }
      `}</style>
      
      {/* Platform Filter */}
      <div className="flex items-center gap-2 mb-5">
        <div className="relative border border-slate-200 rounded-md bg-white shadow-sm hover:border-blue-400 transition-colors">
           <select 
              value={platform} 
              onChange={e => setPlatform(e.target.value)} 
              className="appearance-none bg-transparent outline-none text-sm text-slate-700 py-1.5 pl-3 pr-8 cursor-pointer z-10 relative"
           >
              <option value="全部">全部</option>
              <option value="调度平台">调度平台</option>
              <option value="指标平台">指标平台</option>
              <option value="接口平台">接口平台</option>
              <option value="代码平台">代码平台</option>
              <option value="资源池平台">资源池平台</option>
           </select>
           <ChevronDown size={14} className="text-slate-400 absolute right-2.5 top-[8px] z-0 pointer-events-none" />
        </div>
      </div>

      {/* Header Stat Cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {statCards.map((card, idx) => (
          <div key={idx} className={`bg-white rounded-xl shadow-sm border ${card.borderClass} p-5 flex flex-col justify-between relative overflow-hidden h-[150px]`}>
            {/* Background design */}
            <div className={`absolute left-[-15px] top-4 opacity-50 ${card.bgClass} pointer-events-none`}>
              <card.icon size={110} strokeWidth={1} />
            </div>
            
            <div className="flex items-center justify-between z-10 w-full h-full relative">
               <div className="flex flex-col gap-2">
                 <div className="font-bold text-5xl text-slate-800 tracking-tight ml-2">{card.total}</div>
                 <div className="flex items-center gap-1.5 text-[15px] font-bold text-slate-700 tracking-wide mt-1 ml-2">
                    <card.icon size={18} className={card.iconClass} /> {card.title}
                 </div>
               </div>
               
               <div className="flex flex-col gap-3 text-[15px] font-medium text-slate-600 mr-2 bg-white/80 p-3 rounded-lg backdrop-blur shadow-sm">
                   <div className="flex items-center justify-between gap-6"><div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>正常</div> <span className="font-mono text-slate-800 font-bold">{card.normal}</span></div>
                   <div className="flex items-center justify-between gap-6"><div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>宕机</div> <span className="font-mono text-slate-800 font-bold">{card.down}</span></div>
                   <div className="flex items-center justify-between gap-6"><div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>暂停</div> <span className="font-mono text-slate-800 font-bold">{card.pause}</span></div>
               </div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Grid: 3 columns */}
      <div className="grid grid-cols-3 gap-6 mb-6">
          {/* Alarms List */}
          <div className="bg-white border border-slate-200/60 rounded-xl shadow-sm overflow-hidden flex flex-col h-[360px]">
             <div className="px-5 py-4 flex justify-between items-center bg-white">
               <h3 className="font-bold text-slate-800 text-[15px] flex items-center gap-2">
                 <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                 告警列表
               </h3>
               <span className="text-xs text-slate-400">告警中(默认告警中)</span>
             </div>
             <div className="px-4 pb-4 overflow-hidden flex-1 flex flex-col relative w-full">
                <div className="flex flex-col gap-3 animate-scroll pt-2 h-max w-full">
                  {[...alarms, ...alarms].map((al, idx) => (
                    <div key={idx} className={`${al.bg} border ${al.border} rounded-lg p-3 flex flex-col gap-2 shadow-sm w-full`}>
                       <div className="flex items-center gap-2">
                          {al.type === 'warning' ? <AlertTriangle size={15} className={al.iconColor} /> : <AlertCircle size={15} className={al.iconColor} />}
                          <span className="text-slate-500 font-mono text-[12px]">{al.time}</span>
                          <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded ${al.badgeObj}`}>{al.level}</span>
                       </div>
                       <div className="text-slate-700 leading-relaxed font-medium text-[13px] pl-6">{al.msg}</div>
                    </div>
                  ))}
                </div>
             </div>
          </div>

          {/* Alarm Stats */}
          <div className="bg-white border border-slate-200/60 rounded-xl shadow-sm overflow-hidden h-[360px] flex flex-col">
             <div className="px-5 py-4 flex justify-between items-center bg-white">
               <h3 className="font-bold text-slate-800 text-[15px] flex items-center gap-2">
                 <Activity size={18} className="text-blue-500" />
                 告警 (最近7天)
               </h3>
             </div>
             <div className="px-5 pb-5 flex-1 flex flex-col justify-around">
                {alarmStats.map(s => (
                  <div key={s.label} className={`flex justify-between items-center border rounded-lg px-6 py-4 ${s.bg} ${s.borderColor}`}>
                     <div className={`flex items-center gap-2 font-bold text-[16px] tracking-wider ${s.color}`}>
                         <s.icon size={22} className={s.color} />
                         {s.label}
                     </div>
                     <span className="font-bold text-3xl text-slate-800 font-mono">{s.val}</span>
                  </div>
                ))}
             </div>
          </div>

          {/* Activity Logs */}
          <div className="bg-white border border-slate-200/60 rounded-xl shadow-sm overflow-hidden h-[360px] flex flex-col">
             <div className="px-5 py-4 flex justify-between items-center bg-white">
               <h3 className="font-bold text-slate-800 text-[15px] flex items-center gap-2">
                 <History size={18} className="text-emerald-500" />
                 最新动态 (最近50条)
               </h3>
             </div>
             <div className="px-5 pb-4 overflow-hidden flex-1 relative">
                <div className="relative ml-3 h-full">
                   <div className="absolute left-0 top-0 bottom-0 border-l border-slate-100 z-0"></div>
                   <div className="flex flex-col gap-6 animate-scroll z-10 pt-2 h-max">
                      {[...activities, ...activities].map((act, idx) => (
                         <div key={idx} className="relative pl-6">
                            <div className={`absolute -left-[6px] top-1 w-3 h-3 rounded-full border-2 border-white box-content shadow-sm flex items-center justify-center bg-white`}>
                               <CircleDot size={12} className={act.resultType === 'success' ? 'text-emerald-400' : 'text-blue-400'} fill="currentColor" strokeWidth={1} />
                            </div>
                            <div className="text-[13px] font-medium text-slate-600 mb-1 leading-tight flex items-center gap-1">
                               {act.action}
                            </div>
                            <div className="flex justify-between items-center mt-1.5">
                               <span className={`text-[12px] flex items-center gap-1 ${act.resultType === 'success' ? 'text-emerald-500' : 'text-slate-400'}`}>
                                   {act.resultType === 'success' && <CheckCircle2 size={13} />}
                                   {act.result}
                               </span>
                               <span className="text-[11px] text-slate-400 font-mono tracking-wide">{act.time}</span>
                            </div>
                         </div>
                      ))}
                   </div>
                </div>
             </div>
          </div>
      </div>

      {/* Bottom Grid: 2 columns */}
      <div className="grid grid-cols-2 gap-6 pb-6">
         {/* Trend Chart */}
         <div className="bg-white border border-slate-200/60 rounded-xl shadow-sm p-5 h-[350px] flex flex-col">
             <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-slate-800 text-[15px] flex items-center gap-2">
                   <Activity size={18} className="text-blue-500" />
                   告警与自愈趋势
                </h3>
                <div className="flex items-center gap-2">
                  <div className="border border-slate-200 rounded px-2 w-[85px] flex items-center h-[28px] relative hover:border-blue-400 transition-colors">
                     <select value={trendTime} onChange={e => setTrendTime(e.target.value)} className="bg-transparent text-[13px] text-slate-600 outline-none w-full appearance-none cursor-pointer relative z-10">
                        <option value="24小时">24小时</option>
                        <option value="7天内">7天内</option>
                        <option value="30天内">30天内</option>
                     </select>
                     <ChevronDown size={14} className="text-slate-400 absolute right-1.5 top-[6px] z-0 pointer-events-none" />
                  </div>
                </div>
             </div>
             <div className="flex-1 w-full min-h-0 -ml-4">
                <ResponsiveContainer width="100%" height="100%">
                   <AreaChart data={lineChartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                     <defs>
                        <linearGradient id="colorAlert" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.2}/>
                          <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="colorRecovery" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                     <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                     <XAxis dataKey="time" stroke="#94a3b8" tick={{fontSize: 11}} tickLine={false} axisLine={false} />
                     <YAxis stroke="#94a3b8" tick={{fontSize: 11}} tickLine={false} axisLine={false} />
                     <Tooltip 
                        contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '8px', color: '#1e293b', fontSize: '12px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                        itemStyle={{ color: '#334155' }}
                     />
                     <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', color: '#334155', paddingTop: '10px' }} />
                     <Area type="monotone" name="监控告警量" dataKey="alert" stroke="#f59e0b" strokeWidth={2} fillOpacity={1} fill="url(#colorAlert)" activeDot={{ r: 5 }} />
                     <Area type="monotone" name="自动恢复量" dataKey="recovery" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#colorRecovery)" activeDot={{ r: 5 }} />
                   </AreaChart>
                </ResponsiveContainer>
             </div>
         </div>

         {/* Stacked Bar Chart */}
         <div className="bg-white border border-slate-200/60 rounded-xl shadow-sm p-5 h-[350px] flex flex-col relative">
             <div className="flex justify-between items-center mb-6 z-10 relative">
                <h3 className="font-bold text-slate-800 text-[15px] flex items-center gap-2">
                   <BarChart2 size={18} className="text-purple-500" />
                   告警问题故障等级分布
                </h3>
                <div className="flex items-center gap-2">
                  <div className="border border-slate-200 rounded px-2 w-[85px] flex items-center h-[28px] relative bg-white hover:border-purple-400 transition-colors">
                     <select value={barTime} onChange={e => setBarTime(e.target.value)} className="bg-transparent text-[13px] text-slate-600 outline-none w-full appearance-none cursor-pointer relative z-10">
                        <option value="24小时">24小时</option>
                        <option value="7天内">7天内</option>
                        <option value="30天内">30天内</option>
                     </select>
                     <ChevronDown size={14} className="text-slate-400 absolute right-1.5 top-[6px] z-0 pointer-events-none" />
                  </div>
                </div>
             </div>
             
             <div className="flex-1 w-full min-h-0 pl-2 mt-2">
                <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={barChartData} layout="vertical" margin={{ top: 0, right: 30, left: 15, bottom: 0 }}>
                     <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                     <XAxis type="number" stroke="#94a3b8" tick={{fontSize: 11}} tickLine={false} axisLine={false} />
                     <YAxis dataKey="name" type="category" stroke="#475569" tick={{fontSize: 12, fontWeight: 500}} tickLine={false} axisLine={false} width={65} />
                     <Tooltip 
                        cursor={{fill: 'transparent'}}
                        contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '8px', color: '#334155', fontSize: '12px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                     />
                     <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} iconType="circle" />
                     <Bar dataKey="pending" stackId="a" name="未处理" fill="#f59e0b" barSize={16} radius={[4, 0, 0, 4]} />
                     <Bar dataKey="processing" stackId="a" name="处理中" fill="#3b82f6" barSize={16} />
                     <Bar dataKey="resolved" stackId="a" name="已处理" fill="#10b981" barSize={16} />
                     <Bar dataKey="ignored" stackId="a" name="已忽略" fill="#cbd5e1" barSize={16} radius={[0, 4, 4, 0]} />
                   </BarChart>
                </ResponsiveContainer>
             </div>
         </div>
      </div>
    </div>
  );
}
