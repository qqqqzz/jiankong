import React, { useState } from 'react';
import {
  Gauge, Monitor, LayoutTemplate, SquareTerminal, Link,
  FileText, AlignJustify, Table, Filter,
  GitMerge, BellOff, BellDot, Megaphone, Compass, Smartphone,
  Network, Tags, Puzzle, Settings, Globe, Bot, UserCog, LayoutDashboard,
  ShieldCheck, ShieldAlert, KeyRound, Layers, MessageSquare
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import AlertCenter from './components/AlertCenter';
import AutoScript from './components/AutoScript';
import HandlerConfig from './components/HandlerConfig';
import SecondaryDashboard from './components/SecondaryDashboard';
import AccountRbac from './components/AccountRbac';
import AlertConvergence from './components/AlertConvergence';
import TagManagement from './components/TagManagement';
import DingTalkIntegration from './components/DingTalkIntegration';

const TOP_NAV_ITEMS = [
  '员工', '产品', '用户', '接口', '指标', 
  '任务调度', '代码管理', '过程监控', '安全中心'
];

type SidebarItem = {
  id: string;
  label: string;
  icon: React.ElementType;
};

type SidebarSection = {
  title: string;
  items: SidebarItem[];
};

const SIDEBAR_SECTIONS: SidebarSection[] = [
  {
    title: '主导航',
    items: [
      { id: 'dashboard', label: '概览仪表盘', icon: Gauge },
      { id: 'secondary-dashboard', label: '平台看板', icon: LayoutDashboard },
    ],
  },
  {
    title: '监控',
    items: [
      { id: 'monitor-center', label: '监控中心', icon: Monitor },
      { id: 'custom-board', label: '自定义看板', icon: LayoutTemplate },
      { id: 'monitor-template', label: '监控模板', icon: SquareTerminal },
    ],
  },
  {
    title: '日志',
    items: [
      { id: 'log-integrations', label: '集成接入', icon: Link },
      { id: 'log-flow', label: '日志流', icon: FileText },
      { id: 'log-management', label: '日志管理', icon: AlignJustify },
    ],
  },
  {
    title: '告警',
    items: [
      { id: 'alert-threshold', label: '阈值规则', icon: Table },
      { id: 'alert-integrations', label: '集成接入', icon: Link },
      { id: 'alert-convergence', label: '分组收敛', icon: Filter },
      { id: 'alert-suppression', label: '告警抑制', icon: GitMerge },
      { id: 'alert-silence', label: '告警静默', icon: BellOff },
      { id: 'alert-center', label: '告警中心', icon: BellDot },
      { id: 'auto-script', label: '自动处理脚本', icon: Bot },
      { id: 'handler-config', label: '系统处理人配置', icon: UserCog },
      { id: 'alert-notifications', label: '消息通知', icon: Megaphone },
      { id: 'dingtalk-integration', label: '钉钉消息接入', icon: MessageSquare },
    ],
  },
  {
    title: '权限与安全',
    items: [
      { id: 'account-rbac', label: '账号与权限管理', icon: ShieldCheck },
    ],
  },
  {
    title: '高级',
    items: [
      { id: 'adv-mcp', label: 'MCP服务器', icon: Compass },
      { id: 'adv-status', label: '状态页面', icon: Smartphone },
      { id: 'adv-cluster', label: '采集集群', icon: Network },
      { id: 'adv-tags', label: '标签管理', icon: Tags },
      { id: 'adv-plugins', label: '插件管理', icon: Puzzle },
    ],
  },
  {
    title: '更多',
    items: [
      { id: 'more-settings', label: '系统设置', icon: Settings },
      { id: 'more-help', label: '帮助中心', icon: Globe },
    ],
  }
];

export default function App() {
  const [activeTop, setActiveTop] = useState('过程监控');
  const [activeSidebar, setActiveSidebar] = useState('alert-center');
  const [viewMode, setViewMode] = useState<'dashboard' | 'app'>('dashboard');
  const [dashboardContext, setDashboardContext] = useState<any>(null);

  const navigateToAccountRbac = () => {
    setActiveTop('过程监控');
    setActiveSidebar('account-rbac');
    setViewMode('app');
  };

  return (
    <div className="h-screen w-full flex flex-col font-sans bg-[#F3F4F6] text-[14px]">
      
      {/* Top Navbar */}
      <header className="h-[52px] bg-[#3B82F6] flex shrink-0 items-center justify-between shadow-sm relative z-20">
        <div className="flex items-center h-full">
            {/* Logo Area */}
            <div className="flex items-center text-white px-5 border-r border-blue-400/50 h-full whitespace-nowrap overflow-hidden">
              <span className="font-bold text-[18px] italic tracking-widest mr-2" style={{ fontFamily: 'Georgia, serif' }}>
                ROBAM <span className="text-[14px] font-sans ml-1">老板</span>
              </span>
              <span className="mx-1.5 text-blue-300">|</span>
              <span className="text-[13px] tracking-wide ml-1">资源池平台</span>
            </div>
            
            {/* Top Navigation */}
            <nav className="flex h-full ml-1 overflow-x-auto no-scrollbar">
              {TOP_NAV_ITEMS.map(item => (
                <button 
                  key={item}
                  onClick={() => {
                    if (item === '安全中心' || item === '员工') {
                      navigateToAccountRbac();
                    } else {
                      setActiveTop(item);
                    }
                  }}
                  className={`
                    px-5 h-full text-[13px] text-white/90 hover:bg-[#2563EB]/40 transition duration-150 flex items-center whitespace-nowrap
                    ${activeTop === item ? 'bg-[#2563EB] font-medium text-white shadow-[inset_0_-2px_0_rgba(255,255,255,0.2)]' : ''}
                  `}
                >
                  {item}
                </button>
              ))}
            </nav>
        </div>
        
        {/* User Info - 点击直达账号与权限管理 */}
        <div 
          onClick={navigateToAccountRbac}
          className="text-white/90 text-[13px] pr-6 hover:text-white cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 group"
          title="点击进入账号与权限管理"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400 group-hover:scale-125 transition-transform"></span>
          <span>雷秋子(250992...)</span>
        </div>
      </header>

      {/* Main Body Area */}
      {viewMode === 'dashboard' ? (
        <div className="flex-1 overflow-hidden relative">
          <Dashboard 
            standalone 
            onEnterApp={() => setViewMode('app')} 
            onNavigate={(id, context) => { 
              setActiveSidebar(id); 
              setDashboardContext(context); 
              setViewMode('app'); 
              setActiveTop('过程监控'); 
            }} 
          />
        </div>
      ) : (
        <div className="flex-1 flex overflow-hidden">
          
          {/* Sidebar Navigation */}
          {activeTop === '过程监控' && (
            <aside 
              className="w-[200px] bg-white border-r border-[#E5E7EB] flex-shrink-0 flex flex-col overflow-y-auto relative z-10 custom-scrollbar"
              style={{ scrollbarWidth: 'thin', scrollbarColor: '#E5E7EB transparent' }}
            >
              <div className="py-4">
                {SIDEBAR_SECTIONS.map((section, idx) => (
                  <div key={idx} className="mb-2">
                    {section.title && (
                      <div className="px-6 pb-2 pt-1 text-[12px] font-medium text-gray-400/80">
                        {section.title}
                      </div>
                    )}
                    <ul className="flex flex-col space-y-[2px]">
                      {section.items.map(item => {
                        const isActive = activeSidebar === item.id;
                        const Icon = item.icon;
                        
                        return (
                          <li key={item.id} className="px-3">
                            <button 
                              onClick={() => {
                                if (item.id === 'dashboard') {
                                  setViewMode('dashboard');
                                } else {
                                  setActiveSidebar(item.id);
                                }
                              }}
                              className={`
                                group relative w-full flex items-center px-3 py-[9px] rounded-md transition-colors text-[13px]
                                ${isActive 
                                  ? 'bg-[#EEF2FF] text-[#3B82F6] font-[500]' 
                                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'}
                              `}
                            >
                              {/* Active border indicator */}
                              {isActive && (
                                <div className="absolute left-0 top-1.5 bottom-1.5 w-[3px] bg-[#3B82F6] rounded-r-md" />
                              )}
                              
                              <Icon 
                                size={16} 
                                strokeWidth={isActive ? 2.5 : 2} 
                                className={`mr-2.5 flex-shrink-0 transition-colors ${isActive ? 'text-[#3B82F6]' : 'text-gray-400 group-hover:text-gray-600'}`} 
                              />
                              <span>{item.label}</span>
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))}
              </div>
            </aside>
          )}

          {/* Dynamic Content Pane */}
          <main className="flex-1 p-[14px] flex flex-col overflow-hidden">
             <div className="bg-white border border-[#E5E7EB] flex-1 rounded-[4px] shadow-sm overflow-y-auto relative p-6">
               
               {activeTop === '过程监控' ? (
                   <>
                     {activeSidebar === 'dashboard' ? (
                       <div className="h-full flex flex-col justify-center items-center text-gray-400 gap-4">
                           <div className="w-20 h-20 bg-gray-50/80 rounded-full flex justify-center items-center border border-gray-100">
                              <Gauge size={32} className="text-gray-300" strokeWidth={1.5} />
                           </div>
                           <p className="text-[15px] font-medium text-gray-500">
                             点击大屏进行查看
                           </p>
                           <button onClick={() => setViewMode('dashboard')} className="px-4 py-2 bg-blue-600 text-white rounded shadow-sm hover:bg-blue-700 transition">返回大屏</button>
                       </div>
                     ) : activeSidebar === 'alert-center' ? (
                       <AlertCenter key={dashboardContext?.platform || 'alert-center-default'} initialDomain={dashboardContext?.platform} />
                     ) : activeSidebar === 'alert-convergence' ? (
                       <AlertConvergence />
                     ) : activeSidebar === 'adv-tags' ? (
                       <TagManagement />
                     ) : activeSidebar === 'secondary-dashboard' ? (
                       <SecondaryDashboard key={dashboardContext?.platform || 'default'} initialPlatform={dashboardContext?.platform} />
                     ) : activeSidebar === 'auto-script' ? (
                       <AutoScript />
                     ) : activeSidebar === 'handler-config' ? (
                       <HandlerConfig />
                     ) : activeSidebar === 'dingtalk-integration' ? (
                       <DingTalkIntegration />
                     ) : activeSidebar === 'account-rbac' ? (
                       <AccountRbac />
                     ) : (
                       <div className="h-full flex gap-4 flex-col justify-center items-center text-gray-400">
                           <div className="w-20 h-20 bg-gray-50/80 rounded-full flex justify-center items-center border border-gray-100">
                              {/* Use the currently active icon here */}
                              {(() => {
                                 const ActiveIcon = SIDEBAR_SECTIONS.flatMap(s => s.items).find(i => i.id === activeSidebar)?.icon;
                                 return ActiveIcon ? <ActiveIcon size={32} className="text-gray-300" strokeWidth={1.5} /> : null;
                              })()}
                           </div>
                           <p className="text-[15px] font-medium text-gray-500">
                             当前页面暂无内容
                           </p>
                       </div>
                     )}
                   </>
               ) : (
                   <div className="h-full flex flex-col justify-center items-center text-gray-400">
                       <p className="text-lg">请返回「过程监控」进行相关操作</p>
                   </div>
               )}
               
             </div>
          </main>

        </div>
      )}
    </div>
  );
}
